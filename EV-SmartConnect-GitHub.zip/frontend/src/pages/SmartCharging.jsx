import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { chargingAPI } from '../services/api';
import { Zap, AlertTriangle, CheckCircle, Navigation, Clock, Battery, ArrowRight } from 'lucide-react';

const SmartCharging = () => {
  const { vehicles, selectedVehicleId } = useAuth();
  const currentVehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  const [destination, setDestination] = useState('Nandi Hills Weekend Gateway');
  const [distanceKm, setDistanceKm] = useState(65.0);
  const [preferredSpeed, setPreferredSpeed] = useState(60.0);
  const [recommendation, setRecommendation] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (e) => {
    if (e) e.preventDefault();
    if (!currentVehicle) return;

    setLoading(true);
    try {
      const res = await chargingAPI.getRecommendation({
        vehicle_id: currentVehicle.id,
        destination_name: destination,
        destination_distance_km: parseFloat(distanceKm),
        preferred_speed_kw: parseFloat(preferredSpeed)
      });
      setRecommendation(res.data);
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.detail || 'Failed to generate recommendation');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Smart Charging Recommendation Engine</h1>
        <p className="text-slate-500 text-xs mt-1">
          Intelligent trip energy planner comparing AI-predicted range with destination topography and safety reserve
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Form: Trip Destination Input */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Zap className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">Trip Energy Planner</h3>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Destination</label>
              <input
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="e.g. Mysuru Heritage Tour"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Trip Distance (One-Way km)</label>
              <input
                type="number"
                min="5"
                max="800"
                step="1"
                required
                value={distanceKm}
                onChange={(e) => setDistanceKm(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Preferred Charger Power Output</label>
              <select
                value={preferredSpeed}
                onChange={(e) => setPreferredSpeed(parseFloat(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500"
              >
                <option value="22">22 kW (AC Type 2 Standard)</option>
                <option value="50">50 kW (DC Fast Charger)</option>
                <option value="60">60 kW (DC High Speed)</option>
                <option value="120">120 kW (DC Ultra Fast Hub)</option>
              </select>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2"
              >
                {loading ? 'Evaluating Energy Profile...' : 'Analyze Trip Readiness'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Quick preset trips */}
          <div className="pt-4 border-t border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Preset Test Routes
            </span>
            <div className="flex flex-wrap gap-2">
              {[
                { name: 'City Commute', dist: 25 },
                { name: 'Airport Express', dist: 45 },
                { name: 'Intercity Highway', dist: 140 },
                { name: 'Extended Roadtrip', dist: 320 }
              ].map((p) => (
                <button
                  key={p.name}
                  type="button"
                  onClick={() => {
                    setDestination(p.name);
                    setDistanceKm(p.dist);
                  }}
                  className="px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                >
                  {p.name} ({p.dist} km)
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Smart Recommendation Card */}
        <div className="lg:col-span-2 space-y-6">
          {recommendation ? (
            <>
              {/* Main Banner */}
              <div className={`p-6 rounded-2xl border shadow-sm ${
                recommendation.is_charging_needed
                  ? 'bg-amber-50/80 border-amber-300 text-amber-950'
                  : 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
              }`}>
                <div className="flex items-start gap-3">
                  {recommendation.is_charging_needed ? (
                    <AlertTriangle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
                  ) : (
                    <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-1" />
                  )}
                  <div>
                    <h3 className="font-bold text-base mb-1">
                      {recommendation.is_charging_needed ? 'Pre-Trip Charging Recommended' : 'Battery Range Sufficient'}
                    </h3>
                    <p className="text-xs leading-relaxed opacity-90">{recommendation.recommendation_text}</p>
                  </div>
                </div>

                {/* Key stats breakdown */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-black/10 text-xs">
                  <div>
                    <span className="opacity-70 block text-[11px]">Current Range</span>
                    <span className="font-bold text-sm">{recommendation.predicted_range_km} km</span>
                  </div>
                  <div>
                    <span className="opacity-70 block text-[11px]">Destination Distance</span>
                    <span className="font-bold text-sm">{recommendation.destination_distance_km} km</span>
                  </div>
                  <div>
                    <span className="opacity-70 block text-[11px]">Projected Shortfall</span>
                    <span className={`font-bold text-sm ${recommendation.shortfall_km > 0 ? 'text-red-700' : ''}`}>
                      {recommendation.shortfall_km} km
                    </span>
                  </div>
                  <div>
                    <span className="opacity-70 block text-[11px]">Est. Charge Time</span>
                    <span className="font-bold text-sm">{recommendation.estimated_charge_minutes} mins</span>
                  </div>
                </div>
              </div>

              {/* Recommended Stations List */}
              {recommendation.suggested_stations?.length > 0 && (
                <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                  <h4 className="font-bold text-slate-900 text-sm mb-3">Recommended Stations Near Your Route</h4>
                  <div className="space-y-3">
                    {recommendation.suggested_stations.map((s) => (
                      <div key={s.id} className="p-3.5 bg-slate-50 hover:bg-emerald-50/40 rounded-xl border border-slate-200 flex items-center justify-between transition-colors">
                        <div>
                          <div className="font-bold text-slate-800 text-xs">{s.name}</div>
                          <div className="text-[11px] text-slate-500">{s.address}</div>
                          <div className="text-[11px] text-emerald-700 font-semibold mt-0.5">
                            {s.charging_speed} kW • {s.connector_types} • {s.available_ports} ports available
                          </div>
                        </div>
                        <a
                          href={`https://www.google.com/maps/dir/?api=1&destination=${s.latitude},${s.longitude}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-sm"
                        >
                          <Navigation className="w-3 h-3" />
                          <span>Navigate</span>
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-white rounded-2xl p-12 border border-slate-200 shadow-sm text-center">
              <Zap className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base mb-1">Enter Trip Details to Analyze</h3>
              <p className="text-slate-500 text-xs max-w-sm mx-auto mb-4">
                The smart recommendation engine checks your current battery SOC, ML range projection, and destination distance to ensure zero range anxiety.
              </p>
              <button
                onClick={handleGenerate}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl"
              >
                Analyze Sample Commute
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SmartCharging;
