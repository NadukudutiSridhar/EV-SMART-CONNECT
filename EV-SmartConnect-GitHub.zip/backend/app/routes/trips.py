from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Optional

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.trip import TripRecord
from backend.app.schemas.trip import TripRecordCreate, TripRecordResponse
from backend.app.security.auth import get_current_user, verify_vehicle_ownership

router = APIRouter(prefix="/api/trips", tags=["Trip History & Analytics"])

@router.get("", response_model=List[TripRecordResponse])
def list_trips(
    vehicle_id: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(TripRecord)
    if vehicle_id:
        verify_vehicle_ownership(vehicle_id, current_user, db)
        query = query.filter(TripRecord.vehicle_id == vehicle_id)
    elif current_user.role != "admin":
        user_vehicle_ids = [v.id for v in current_user.vehicles]
        query = query.filter(TripRecord.vehicle_id.in_(user_vehicle_ids))

    trips = query.order_by(TripRecord.trip_date.desc(), TripRecord.created_at.desc()).all()
    resp = []
    for t in trips:
        r = TripRecordResponse.from_orm(t)
        if t.vehicle:
            r.vehicle_name = f"{t.vehicle.make} {t.vehicle.model}"
        resp.append(r)
    return resp

@router.post("", response_model=TripRecordResponse, status_code=status.HTTP_201_CREATED)
def record_trip(req: TripRecordCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    verify_vehicle_ownership(req.vehicle_id, current_user, db)

    # Compute efficiency: (energy_consumed / distance) * 100
    efficiency = req.efficiency
    if not efficiency and req.distance > 0:
        efficiency = round((req.energy_consumed / req.distance) * 100.0, 2)
    elif not efficiency:
        efficiency = 16.5

    trip = TripRecord(
        vehicle_id=req.vehicle_id,
        start_location=req.start_location.strip(),
        destination=req.destination.strip(),
        distance=req.distance,
        duration_minutes=req.duration_minutes,
        average_speed=req.average_speed,
        energy_consumed=req.energy_consumed,
        efficiency=efficiency,
        start_soc=req.start_soc,
        end_soc=req.end_soc,
        trip_date=req.trip_date or date.today()
    )
    db.add(trip)
    db.commit()
    db.refresh(trip)

    resp = TripRecordResponse.from_orm(trip)
    if trip.vehicle:
        resp.vehicle_name = f"{trip.vehicle.make} {trip.vehicle.model}"
    return resp
