import os
import sys
from dulwich import porcelain

REPO_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

def push_to_remote(remote_url: str):
    """
    Pushes the local Git repository to a GitHub remote URL.
    Supports:
      1. Personal Access Token URL: https://<TOKEN>@github.com/<USERNAME>/<REPO>.git
      2. Standard HTTPS: https://github.com/<USERNAME>/<REPO>.git
    """
    repo = porcelain.open_repo(REPO_PATH)
    print(f"Connecting to remote: {remote_url} ...")
    
    # Try pushing 'main' branch first
    try:
        print("Pushing 'main' branch to remote...")
        porcelain.push(repo, remote_url, "refs/heads/main:refs/heads/main")
        print("Successfully deployed to GitHub (branch: main)!")
        return
    except Exception as e1:
        print(f"Notice pushing refs/heads/main: {e1}")
        
    # Fallback to 'master' branch
    try:
        print("Attempting push to 'master' branch...")
        porcelain.push(repo, remote_url, "refs/heads/master:refs/heads/master")
        print("Successfully deployed to GitHub (branch: master)!")
        return
    except Exception as e2:
        print(f"Error pushing to remote: {e2}")
        print("\n[Troubleshooting Tips]")
        print("1. If authentication failed, use a GitHub Personal Access Token (classic with 'repo' scope):")
        print("   Format: https://ghp_YOUR_TOKEN@github.com/USERNAME/REPO_NAME.git")
        print("2. Ensure the remote repository has been created at https://github.com/new")
        raise e2

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python backend/push_to_github.py <GITHUB_REMOTE_URL>")
        print("Example: python backend/push_to_github.py https://ghp_xxx@github.com/myname/ev-smartconnect.git")
        sys.exit(1)
    remote_url = sys.argv[1]
    push_to_remote(remote_url)

