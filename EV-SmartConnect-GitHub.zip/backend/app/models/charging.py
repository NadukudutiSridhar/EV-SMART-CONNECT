from sqlalchemy import Column, Integer, Float, String, Boolean, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from backend.app.database import Base

class ChargingStation(Base):
    __tablename__ = "charging_stations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(160), nullable=False)
    operator = Column(String(120), default="Independent", nullable=False)
    address = Column(String(255), nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    connector_types = Column(String(120), nullable=False) # e.g. "CCS2, Type 2"
    charging_speed = Column(Float, nullable=False) # in kW (e.g. 50.0, 150.0)
    total_ports = Column(Integer, default=4, nullable=False)
    available_ports = Column(Integer, default=2, nullable=False)
    price_per_kwh = Column(Float, default=15.0, nullable=False)
    is_simulated_availability = Column(Boolean, default=True, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    sessions = relationship("ChargingSession", back_populates="station", cascade="all, delete-orphan")

class ChargingSession(Base):
    __tablename__ = "charging_sessions"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    station_id = Column(Integer, ForeignKey("charging_stations.id", ondelete="CASCADE"), nullable=False, index=True)
    start_time = Column(DateTime, server_default=func.now(), nullable=False)
    end_time = Column(DateTime, nullable=True)
    start_soc = Column(Float, nullable=False)
    end_soc = Column(Float, nullable=True)
    energy_consumed = Column(Float, default=0.0, nullable=False) # in kWh
    total_cost = Column(Float, default=0.0, nullable=False)
    status = Column(String(50), default="active", nullable=False) # 'active', 'completed', 'interrupted'

    vehicle = relationship("Vehicle", back_populates="charging_sessions")
    station = relationship("ChargingStation", back_populates="sessions")
