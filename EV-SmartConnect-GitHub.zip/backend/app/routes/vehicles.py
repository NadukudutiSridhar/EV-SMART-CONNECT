from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.vehicle import Vehicle
from backend.app.schemas.vehicle import VehicleCreateRequest, VehicleUpdateRequest, VehicleResponse
from backend.app.security.auth import get_current_user, verify_vehicle_ownership
from backend.app.security.middleware import audit_log

router = APIRouter(prefix="/api/vehicles", tags=["EV Vehicle Management"])

@router.get("", response_model=List[VehicleResponse])
def list_vehicles(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """List vehicles. Normal users see only their vehicles; admins see all."""
    if current_user.role == "admin":
        return db.query(Vehicle).all()
    return db.query(Vehicle).filter(Vehicle.user_id == current_user.id).all()

@router.post("", response_model=VehicleResponse, status_code=status.HTTP_201_CREATED)
def create_vehicle(req: VehicleCreateRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Check registration number uniqueness
    existing_reg = db.query(Vehicle).filter(Vehicle.registration_number == req.registration_number.upper().strip()).first()
    if existing_reg:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Vehicle with registration number {req.registration_number} already registered."
        )

    vehicle = Vehicle(
        user_id=current_user.id,
        model=req.model.strip(),
        make=req.make.strip(),
        registration_number=req.registration_number.upper().strip(),
        vin=req.vin.upper().strip() if req.vin else None,
        battery_capacity=req.battery_capacity,
        vehicle_type=req.vehicle_type,
        manufacturing_year=req.manufacturing_year,
        firmware_version=req.firmware_version or "v2.4.1",
        is_active=True
    )
    db.add(vehicle)
    db.commit()
    db.refresh(vehicle)
    audit_log("VEHICLE_CREATED", current_user.email, f"Reg: {vehicle.registration_number}")
    return vehicle

@router.get("/{vehicle_id}", response_model=VehicleResponse)
def get_vehicle(vehicle_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vehicle = verify_vehicle_ownership(vehicle_id, current_user, db)
    return vehicle

@router.put("/{vehicle_id}", response_model=VehicleResponse)
def update_vehicle(vehicle_id: int, req: VehicleUpdateRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vehicle = verify_vehicle_ownership(vehicle_id, current_user, db)
    
    if req.model is not None:
        vehicle.model = req.model.strip()
    if req.make is not None:
        vehicle.make = req.make.strip()
    if req.registration_number is not None:
        vehicle.registration_number = req.registration_number.upper().strip()
    if req.battery_capacity is not None:
        vehicle.battery_capacity = req.battery_capacity
    if req.vehicle_type is not None:
        vehicle.vehicle_type = req.vehicle_type
    if req.firmware_version is not None:
        vehicle.firmware_version = req.firmware_version
    if req.is_active is not None:
        vehicle.is_active = req.is_active

    db.commit()
    db.refresh(vehicle)
    audit_log("VEHICLE_UPDATED", current_user.email, f"ID: {vehicle.id}")
    return vehicle

@router.delete("/{vehicle_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_vehicle(vehicle_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vehicle = verify_vehicle_ownership(vehicle_id, current_user, db)
    db.delete(vehicle)
    db.commit()
    audit_log("VEHICLE_DELETED", current_user.email, f"ID: {vehicle_id}")
    return None
