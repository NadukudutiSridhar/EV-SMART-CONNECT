from sqlalchemy import Column, Integer, Float, String, Boolean, DateTime, ForeignKey, Text, func
from sqlalchemy.orm import relationship
from backend.app.database import Base

class MaintenanceAlert(Base):
    __tablename__ = "maintenance_alerts"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    alert_type = Column(String(100), nullable=False) # Temperature, Voltage, Current, SOH_Degradation, Consumption
    severity = Column(String(20), default="Medium", nullable=False) # 'Low', 'Medium', 'High'
    description = Column(Text, nullable=False)
    recommended_action = Column(Text, nullable=False)
    sensor_value = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    detection_method = Column(String(50), default="Threshold", nullable=False) # Threshold, IsolationForest, Heuristic
    is_resolved = Column(Boolean, default=False, nullable=False, index=True)
    resolved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    vehicle = relationship("Vehicle", back_populates="maintenance_alerts")
