from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class DailyAnalytics(BaseModel):
    date: str
    total_distance_km: float
    total_energy_kwh: float
    avg_efficiency: float
    trip_count: int

class EfficiencyPoint(BaseModel):
    speed_bracket: str
    avg_consumption_kwh_per_100km: float

class DegradationPoint(BaseModel):
    date: str
    soh: float
    estimated_remaining_capacity_kwh: float

class AnalyticsSummaryResponse(BaseModel):
    total_vehicles: int
    total_distance_km: float
    total_energy_consumed_kwh: float
    average_fleet_efficiency: float
    active_alerts_count: int
    total_charging_sessions: int
    daily_trends: List[DailyAnalytics]
    speed_vs_efficiency: List[EfficiencyPoint]
    battery_degradation_trend: List[DegradationPoint]
