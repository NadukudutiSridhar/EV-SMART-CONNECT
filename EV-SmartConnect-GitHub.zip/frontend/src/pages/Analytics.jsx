import React, { useState, useEffect } from 'react';
import { analyticsAPI } from '../services/api';
import { BarChart3, TrendingUp, Zap, Gauge, Download, Calendar, Layers } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Analytics = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true);
        const res = await analyticsAPI.getSummary();
        setData(res.data);
      } catch (err) {
        console.error("Failed to fetch analytics", err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  const dailyLabels = data?.daily_trends?.map(d => d.date) || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dailyDistances = data?.daily_trends?.map(d => d.total_distance_km) || [22, 38, 45, 12, 60, 85, 30];
  const dailyEnergy = data?.daily_trends?.map(d => d.total_energy_kwh) || [3.5, 6.2, 7.4, 2.0, 9.8, 14.1, 4.8];

  const dailyTrendsChartData = {
    labels: dailyLabels,
    datasets: [
      {
        type: 'bar',
        label: 'Distance (km)',
        data: dailyDistances,
        backgroundColor: '#10b981',
        borderRadius: 8,
        yAxisID: 'y'
      },
      {
        type: 'line',
        label: 'Energy Consumed (kWh)',
        data: dailyEnergy,
        borderColor: '#6366f1',
        tension: 0.3,
        yAxisID: 'y1'
      }
    ]
  };

  const speedLabels = data?.speed_vs_efficiency?.map(s => s.speed_bracket) || ['20-40', '40-60', '60-80', '80-100', '100-120', '120+'];
  const speedEfficiency = data?.speed_vs_efficiency?.map(s => s.avg_consumption_kwh_per_100km) || [13.2, 14.5, 16.8, 19.4, 23.1, 27.5];

  const speedChartData = {
    labels: speedLabels,
    datasets: [
      {
        label: 'Energy Consumption (kWh/100km)',
        data: speedEfficiency,
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        fill: true,
        tension: 0.3
      }
    ]
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Fleet Analytics & Energy Reports</h1>
          <p className="text-slate-500 text-xs mt-1">
            Aggregated operational metrics, aerodynamic efficiency curves, and battery lifespan models
          </p>
        </div>
        <button
          onClick={() => window.print()}
          className="flex items-center gap-1.5 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Summary Report</span>
        </button>
      </div>

      {/* Aggregate Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Total Distance</span>
          <div className="text-2xl font-extrabold text-slate-900">{data?.total_distance_km || 1240.5} km</div>
          <span className="text-xs text-slate-400 mt-1 block">Across monitored vehicles</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Energy Consumed</span>
          <div className="text-2xl font-extrabold text-slate-900">{data?.total_energy_consumed_kwh || 204.8} kWh</div>
          <span className="text-xs text-slate-400 mt-1 block">Total draw from grid</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Fleet Efficiency</span>
          <div className="text-2xl font-extrabold text-emerald-600">{data?.average_fleet_efficiency || 16.5}</div>
          <span className="text-xs text-slate-400 mt-1 block">kWh / 100km</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Charging Sessions</span>
          <div className="text-2xl font-extrabold text-slate-900">{data?.total_charging_sessions || 14}</div>
          <span className="text-xs text-slate-400 mt-1 block">Fast & AC sessions</span>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">7-Day Distance & Energy Trends</h3>
            <p className="text-xs text-slate-400 mb-4">Daily operational utilization</p>
          </div>
          <div className="h-64">
            <Bar
              data={dailyTrendsChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: { position: 'left', grid: { color: '#f1f5f9' } },
                  y1: { position: 'right', grid: { drawOnChartArea: false } }
                }
              }}
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">Speed vs Aerodynamic Energy Draw</h3>
            <p className="text-xs text-slate-400 mb-4">Shows energy consumption surging at highway speeds</p>
          </div>
          <div className="h-64">
            <Line
              data={speedChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: { min: 10, max: 32, grid: { color: '#f1f5f9' }, ticks: { callback: v => `${v} kWh` } }
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
