import os
import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.range_prediction import RangePrediction
from backend.app.schemas.range_prediction import RangePredictionRequest, RangePredictionResponse
from backend.app.security.auth import get_current_user, verify_vehicle_ownership
from backend.app.services.range_service import compute_and_save_prediction
from backend.app.config import settings

router = APIRouter(prefix="/api", tags=["AI Range Prediction"])

@router.post("/predict-range", response_model=RangePredictionResponse)
def predict_range(req: RangePredictionRequest, db: Session = Depends(get_db)):
    """Predict remaining driving range using trained Random Forest ML model."""
    try:
        prediction = compute_and_save_prediction(req, db)
        return prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@router.get("/predictions/{vehicle_id}", response_model=List[RangePredictionResponse])
def get_vehicle_prediction_history(vehicle_id: int, limit: int = 20, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    verify_vehicle_ownership(vehicle_id, current_user, db)
    preds = db.query(RangePrediction).filter(
        RangePrediction.vehicle_id == vehicle_id
    ).order_by(desc(RangePrediction.created_at)).limit(limit).all()

    return [
        RangePredictionResponse(
            id=p.id,
            vehicle_id=p.vehicle_id,
            predicted_range_km=p.predicted_range,
            confidence_score=p.confidence_score,
            model_version=p.model_version,
            features_used={
                "soc": p.battery_soc,
                "soh": p.battery_soh,
                "temperature": p.battery_temp,
                "avg_speed": p.avg_speed,
                "vehicle_load": p.vehicle_load,
                "energy_consumption": p.energy_consumption,
                "terrain": p.terrain_condition
            },
            disclaimer="AI estimate based on operational telemetry and trained models.",
            created_at=p.created_at
        ) for p in preds
    ]

@router.get("/ai/metrics")
def get_ml_metrics():
    """Returns actual trained machine learning metrics (MAE, RMSE, R²)."""
    metrics_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../ml/model_metrics.json"))
    if os.path.exists(metrics_path):
        with open(metrics_path, "r") as f:
            return json.load(f)
    return {
        "status": "pending_training",
        "message": "Run ml/train_model.py to generate live evaluation metrics."
    }
