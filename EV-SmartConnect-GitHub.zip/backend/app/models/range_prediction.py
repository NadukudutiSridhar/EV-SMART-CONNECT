from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from backend.app.database import Base

class RangePrediction(Base):
    __tablename__ = "range_predictions"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    predicted_range = Column(Float, nullable=False) # km
    battery_soc = Column(Float, nullable=False)
    battery_soh = Column(Float, nullable=False)
    battery_temp = Column(Float, nullable=False)
    avg_speed = Column(Float, nullable=False)
    vehicle_load = Column(Float, default=0.0, nullable=False) # kg
    energy_consumption = Column(Float, nullable=False) # kWh/100km
    terrain_condition = Column(String(50), default="flat", nullable=False)
    model_version = Column(String(50), default="RandomForest-v1.0", nullable=False)
    confidence_score = Column(Float, default=0.95, nullable=False)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    vehicle = relationship("Vehicle", back_populates="range_predictions")
