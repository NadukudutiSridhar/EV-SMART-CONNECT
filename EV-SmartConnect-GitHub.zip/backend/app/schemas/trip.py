from pydantic import BaseModel, Field
from typing import Optional
from datetime import date, datetime

class TripRecordCreate(BaseModel):
    vehicle_id: int
    start_location: str = Field(..., min_length=2)
    destination: str = Field(..., min_length=2)
    distance: float = Field(..., gt=0.0, description="km")
    duration_minutes: int = Field(..., gt=0)
    average_speed: float = Field(..., ge=0.0)
    energy_consumed: float = Field(..., gt=0.0, description="kWh")
    efficiency: Optional[float] = None # Calculated if not provided: (kWh/km)*100
    start_soc: float = Field(..., ge=0.0, le=100.0)
    end_soc: float = Field(..., ge=0.0, le=100.0)
    trip_date: Optional[date] = None

class TripRecordResponse(BaseModel):
    id: int
    vehicle_id: int
    start_location: str
    destination: str
    distance: float
    duration_minutes: int
    average_speed: float
    energy_consumed: float
    efficiency: float
    start_soc: float
    end_soc: float
    trip_date: date
    created_at: datetime
    vehicle_name: Optional[str] = None

    class Config:
        from_attributes = True
