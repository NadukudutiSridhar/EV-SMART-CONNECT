from backend.app.schemas.auth import UserRegisterRequest, UserLoginRequest, TokenResponse, UserResponse
from backend.app.schemas.vehicle import VehicleCreateRequest, VehicleUpdateRequest, VehicleResponse
from backend.app.schemas.battery import BatteryReadingCreate, BatteryReadingResponse, BatteryStatusOverview
from backend.app.schemas.range_prediction import RangePredictionRequest, RangePredictionResponse
from backend.app.schemas.charging import (
    ChargingStationCreate, ChargingStationResponse,
    ChargingSessionCreate, ChargingSessionResponse,
    ChargingRecommendationRequest, ChargingRecommendationResponse
)
from backend.app.schemas.maintenance import MaintenanceAlertCreate, MaintenanceAlertUpdate, MaintenanceAlertResponse
from backend.app.schemas.trip import TripRecordCreate, TripRecordResponse
from backend.app.schemas.analytics import AnalyticsSummaryResponse

__all__ = [
    "UserRegisterRequest", "UserLoginRequest", "TokenResponse", "UserResponse",
    "VehicleCreateRequest", "VehicleUpdateRequest", "VehicleResponse",
    "BatteryReadingCreate", "BatteryReadingResponse", "BatteryStatusOverview",
    "RangePredictionRequest", "RangePredictionResponse",
    "ChargingStationCreate", "ChargingStationResponse",
    "ChargingSessionCreate", "ChargingSessionResponse",
    "ChargingRecommendationRequest", "ChargingRecommendationResponse",
    "MaintenanceAlertCreate", "MaintenanceAlertUpdate", "MaintenanceAlertResponse",
    "TripRecordCreate", "TripRecordResponse",
    "AnalyticsSummaryResponse"
]
