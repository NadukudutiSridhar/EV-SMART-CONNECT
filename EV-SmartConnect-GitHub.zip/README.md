# EV SmartConnect ⚡
### AI-Powered Intelligent Electric Vehicle Management Web Application

[![FastAPI](https://img.shields.io/badge/Backend-FastAPI-009688?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/Frontend-React%2018%20%2B%20Vite-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![Scikit-Learn](https://img.shields.io/badge/ML-Scikit--Learn%20%7C%20Random%20Forest-F7931E?logo=scikit-learn&logoColor=white)](https://scikit-learn.org/)
[![Database](https://img.shields.io/badge/Database-MySQL%20%2F%20SQLAlchemy-4479A1?logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Cybersecurity](https://img.shields.io/badge/Security-Argon2%20%2B%20JWT%20%2B%20RBAC-10B981)](#8-cybersecurity--telemetry-defense)

**EV SmartConnect** is an industry-oriented, full-stack, AI-powered Electric Vehicle Management platform. It eliminates range anxiety, provides battery health diagnostics, detects electrochemical and thermal sensor anomalies using machine learning, recommends fast charging stops before energy depletion, and maps nearby charging infrastructure using interactive OpenStreetMap layers.

---

## 1. System Architecture

```
                               [ EV Telemetry Simulator ]
                         (simulate_ev.py / Virtual Edge Node)
                                          │
                            (WSS / REST + Ingest API)
                                          ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       FASTAPI BACKEND SERVICE (:8000)                       │
│  ┌────────────────────┬────────────────────┬─────────────────────────────┐  │
│  │   Auth & RBAC      │   Telemetry Ingest │   AI Inference Services     │  │
│  │   - Argon2id       │   - Physical Plaus.│   - Random Forest Regressor │  │
│  │   - JWT (HS256)    │   - Threshold Guard│   - Isolation Forest Anomaly│  │
│  │   - Rate Limiter   │   - Telemetry Anom.│   - Route Energy Advisor    │  │
│  └────────────────────┴────────────────────┴─────────────────────────────┘  │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                ┌──────────────────────┴──────────────────────┐
                ▼                                             ▼
┌───────────────────────────────┐             ┌───────────────────────────────┐
│     DATABASE PERSISTENCE      │             │     REACT 18 + VITE FRONTEND  │
│  - MySQL 8.0 / SQLite Dual    │             │  - Navy & Emerald UI Theme    │
│  - 8 Relational Tables        │             │  - Chart.js Live Telemetry    │
│  - Foreign Key Constraints    │             │  - Leaflet / OpenStreetMap    │
│  - Complete Audit Trail       │             │  - Role Guarded Dashboards    │
└───────────────────────────────┘             └───────────────────────────────┘
```

---

## 2. Technology Stack

* **Frontend**: React 18, Vite 5, Tailwind CSS, React Router v6, Axios, Lucide React, Chart.js, React-Chartjs-2, Leaflet, React-Leaflet, OpenStreetMap.
* **Backend**: Python 3.11+, FastAPI, Uvicorn, SQLAlchemy 2.0 ORM, Pydantic v2 Settings & Schemas, Starlette.
* **Security & Auth**: Argon2id password hashing, JSON Web Tokens (JWT), Role-Based Access Control (RBAC), sliding-window rate limiting, HTTP security headers (`nosniff`, `DENY`, `STS`).
* **Machine Learning**: Scikit-Learn (Random Forest Regressor, Linear Regression, Isolation Forest), Pandas, NumPy, Joblib.
* **Database**: MySQL 8.0+ / SQLite 3 dual support via SQLAlchemy connection engine.

---

## 3. Implemented Modules

| # | Module | Status | Description |
|---|---|:---:|---|
| **1** | **User Authentication** | ✅ Done | User registration, login, Argon2 password hashing, JWT bearer tokens, role-based authorization (User / Admin). |
| **2** | **EV Vehicle Management** | ✅ Done | Add, update, delete, view electric vehicles (VIN, battery capacity, model year, firmware version). Cross-user isolation enforced. |
| **3** | **EV Dashboard** | ✅ Done | Modern dark navy and emerald dashboard with live SOC, SOH, range, temperature, voltage, current, and Chart.js telemetry trends. |
| **4** | **Simulated EV Telemetry** | ✅ Done | `simulator/simulate_ev.py` generates physics-consistent driving, charging, idle, and anomaly streams. Exported 200 sample rows to CSV. |
| **5** | **AI Range Prediction** | ✅ Done | Random Forest Regressor predicting real driving range based on SOC, SOH, temperature, speed, load, consumption, and terrain. |
| **6** | **Battery Health Monitoring** | ✅ Done | Electrochemical tracking, cell degradation curves against 160,000 km manufacturer warranty, and safety threshold alerts. |
| **7** | **Smart Charging Locator** | ✅ Done | Interactive Leaflet map with OpenStreetMap tiles, connector filters (CCS2, Type 2, CHAdeMO), power filters, and distance calculation. |
| **8** | **Charging Recommendation** | ✅ Done | Intelligent trip advisor comparing current range with destination distance, calculates energy shortfall (kWh) and required charging time. |
| **9** | **Predictive Maintenance** | ✅ Done | Dual-engine anomaly detection (Engineering thresholds + Isolation Forest ML) with Low/Medium/High severity classification and resolution tracking. |
| **10** | **Trip History & Analytics** | ✅ Done | Comprehensive trip logs, distance, energy consumed, efficiency (kWh/100km), and battery delta records. |
| **11** | **Admin Dashboard** | ✅ Done | Super-admin console for viewing registered users, toggling activation, changing roles, monitoring system stats, and one-click demo data seeding. |

---

## 4. Machine Learning Models & Actual Evaluation Metrics

The machine learning pipeline (`ml/train_model.py`) trains and compares models on a 6,000-sample physics-grounded EV operating dataset.

### Evaluation Comparison:

| Model | Mean Absolute Error (MAE) | Root Mean Squared Error (RMSE) | R² Score | Result |
| :--- | :---: | :---: | :---: | :---: |
| **Linear Regression** | 20.27 km | 30.08 km | 0.9049 | Baseline |
| **Random Forest Regressor** | **7.70 km** | **11.45 km** | **0.9862** | **Selected Best Model** 🏆 |

* **Model File**: `ml/range_model.pkl` (Pipeline with `StandardScaler` and `OneHotEncoder`)
* **Anomaly Detection Model**: `ml/anomaly_model.pkl` (`IsolationForest(contamination=0.03)` for multi-dimensional telemetry outlier detection)
* **Live API**: Metrics are retrievable at `GET /api/ai/metrics`.

> **Prototype Disclaimer:** Predictions are calculated from physics-consistent simulated EV telemetry. These models serve as prototype estimates for operational monitoring and educational demonstration.

---

## 5. Database Schema & Tables

The schema is defined in `database/schema.sql` (MySQL 8.0 DDL) and mirrored via SQLAlchemy models:

1. `users`: ID, name, email (unique), password_hash, role (`user`/`admin`), phone, is_active, timestamps.
2. `vehicles`: ID, user_id (FK), model, make, registration_number (unique), vin, battery_capacity (kWh), vehicle_type, manufacturing_year, firmware_version.
3. `battery_readings`: ID, vehicle_id (FK), soc, soh, voltage, current, temperature, vehicle_speed, energy_consumption, distance_travelled, charging_status, is_simulated, is_anomaly, timestamp.
4. `range_predictions`: ID, vehicle_id (FK), predicted_range, battery_soc, battery_soh, battery_temp, avg_speed, vehicle_load, energy_consumption, terrain_condition, model_version, confidence_score.
5. `charging_stations`: ID, name, operator, address, latitude, longitude, connector_types, charging_speed (kW), total_ports, available_ports, price_per_kwh, is_simulated_availability.
6. `charging_sessions`: ID, vehicle_id (FK), station_id (FK), start_time, end_time, start_soc, end_soc, energy_consumed, total_cost, status.
7. `maintenance_alerts`: ID, vehicle_id (FK), alert_type, severity (`Low`, `Medium`, `High`), description, recommended_action, sensor_value, threshold_value, detection_method, is_resolved.
8. `trip_records`: ID, vehicle_id (FK), start_location, destination, distance, duration_minutes, average_speed, energy_consumed, efficiency, start_soc, end_soc, trip_date.

---

## 6. Cybersecurity & Telemetry Safeguards

1. **Argon2id Password Hashing**: Modern, memory-hard key derivation resistant to GPU brute-forcing.
2. **Resource Ownership & Cross-User Isolation**: Normal users cannot view, edit, or delete vehicles or telemetry belonging to other users. Enforced at the ORM layer.
3. **Telemetry Ingest Plausibility Validation**: Detects and rejects physically impossible or spoofed sensor packets (e.g., negative voltage, temperature > 120°C, SOC > 100%).
4. **Rate Limiting**: Sliding-window rate limiter on `/api/auth/login` and `/api/auth/register` prevents credential stuffing attacks.
5. **Security Headers**: Injects `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Strict-Transport-Security`, and `X-XSS-Protection`.
6. **Security Audit Logging**: Critical actions (logins, vehicle creation, alert resolution, role changes) are timestamped and logged with user IDs.

---

## 7. Local Setup Instructions

### Prerequisites:
- Python 3.10+ (tested on Python 3.11.9)
- Node.js 18+ & npm (tested on Node v24.2.3 & npm 11.19.1)

### Step 1: Clone & Setup Backend

```bash
cd EV-SmartConnect

# Create and activate virtual environment
python -m venv .venv
# On Windows:
.\.venv\Scripts\activate
# On Linux/macOS:
# source .venv/bin/activate

# Install dependencies
pip install -r backend/requirements.txt
```

### Step 2: Train Machine Learning Models

```bash
# Trains Random Forest & Isolation Forest, generates evaluation metrics and dataset.csv
python ml/train_model.py
```

### Step 3: Run Backend Service

```bash
# Starts FastAPI server on http://127.0.0.1:8000
python -m uvicorn backend.app.main:app --reload --port 8000
```

* Swagger API documentation is available at: `http://127.0.0.1:8000/docs`
* ReDoc interactive documentation: `http://127.0.0.1:8000/redoc`

### Step 4: Run Frontend Development Server

Open a new terminal:

```bash
cd EV-SmartConnect/frontend

# Install dependencies (if not already installed)
npm install

# Start Vite dev server
npm run dev
```

Visit `http://localhost:5173` in your browser.

---

## 8. Demo Credentials & Quick Test

You can automatically seed the database with demo users, vehicles, charging stations, and trip logs:

1. Click **"Seed Demo Data"** on the Login page or call `POST /api/admin/seed`.
2. Login with either account:

| Role | Email | Password | Access |
| :--- | :--- | :--- | :--- |
| **Fleet Administrator** | `admin@evsmartconnect.io` | `Admin@123456` | Full platform, user role toggling, all fleet vehicles |
| **EV Driver / Owner** | `driver@evsmartconnect.io` | `Driver@123456` | Personal vehicles, AI range simulator, trip logging |

---

## 9. Telemetry Simulator Execution

Run the standalone EV sensor simulator to generate sample CSVs or stream live telemetry into the dashboard:

```bash
# 1. Generate 200 simulated telemetry rows to CSV:
python simulator/simulate_ev.py --csv --samples 200

# 2. Stream live simulated driving telemetry directly to running backend:
python simulator/simulate_ev.py --stream --vehicle-id 1 --interval 2.5 --steps 20
```

You can also click **"Simulate Step"** or **"Inject Anomaly"** directly from the frontend dashboard!

---

## 10. Automated Test Suite

Run the full automated pytest suite covering Authentication, Vehicle Management, RBAC Isolation, AI Range Prediction, and Battery Anomaly Detection:

```bash
# Run tests
pytest -v tests/
```

**Test Results:**
```
tests/test_auth.py::test_register_first_user_becomes_admin PASSED        [ 11%]
tests/test_auth.py::test_register_duplicate_email_rejected PASSED        [ 22%]
tests/test_auth.py::test_login_success_and_failure PASSED                [ 33%]
tests/test_auth.py::test_get_current_user_profile PASSED                 [ 44%]
tests/test_predictions.py::test_ml_range_prediction_logic PASSED         [ 55%]
tests/test_predictions.py::test_ml_range_prediction_depleted_battery PASSED [ 66%]
tests/test_predictions.py::test_telemetry_anomaly_detection PASSED       [ 77%]
tests/test_predictions.py::test_prediction_api_endpoint PASSED           [ 88%]
tests/test_vehicles.py::test_vehicle_crud_and_cross_user_isolation PASSED [100%]
======================= 9 passed in 4.08s =======================
```

---

## 11. Deployment Guide

### A. Deploy Backend to Render

1. Create a new **Web Service** on [Render](https://render.com).
2. Connect your Git repository.
3. Configure settings:
   * **Runtime**: Python 3
   * **Build Command**: `pip install -r backend/requirements.txt && python ml/train_model.py`
   * **Start Command**: `python -m uvicorn backend.app.main:app --host 0.0.0.0 --port $PORT`
4. Set Environment Variables:
   * `APP_ENV`: `production`
   * `SECRET_KEY`: `<Generate a strong 64-char key>`
   * `DATABASE_URL`: `mysql+pymysql://<user>:<password>@<host>:3306/<dbname>` (or use managed PostgreSQL/MySQL)

### B. Deploy Frontend to Vercel

1. Create a new Project on [Vercel](https://vercel.com).
2. Set Root Directory to `frontend`.
3. Set Framework to **Vite**.
4. Set Environment Variable:
   * `VITE_API_URL`: `https://your-backend-service.onrender.com/api`
5. Click **Deploy**.

---

## 12. License & Integrity Statement

Developed as an industry-oriented electric vehicle software project. All telemetry readings generated during simulation are labeled as synthetic data in adherence to professional data integrity standards.
