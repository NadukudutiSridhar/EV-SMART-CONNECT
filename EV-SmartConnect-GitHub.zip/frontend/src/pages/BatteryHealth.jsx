import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { batteryAPI, maintenanceAPI } from '../services/api';
import {
  BatteryCharging,
  Thermometer,
  Zap,
  Activity,
  AlertTriangle,
  ShieldCheck,
  TrendingDown,
  RefreshCw,
  Clock
} from 'lucide-react';
import { Line } from 'react-chartjs-2';

const BatteryHealth = () => {
  const { vehicles, selectedVehicleId } = useAuth();
  const [status, setStatus] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const vehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  const fetchBatteryData = async () => {
    if (!vehicle) return;
    try {
      setLoading(true);
      const [statusRes, historyRes] = await Promise.all([
        batteryAPI.getStatus(vehicle.id),
        batteryAPI.getHistory(vehicle.id, 30)
      ]);
      setStatus(statusRes.data);
      setHistory(historyRes.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBatteryData();
  }, [vehicle?.id]);

  const reading = status?.latest_reading || {
    soc: 84.0,
    soh: 97.5,
    voltage: 394.0,
    current: -30.0,
    temperature: 28.0,
    charging_status: 'discharging',
    is_simulated: true,
    is_anomaly: false
  };

  // Degradation projection data: 100% down to 80% warranty line
  const degradationChartData = {
    labels: ['0k km', '20k km', '40k km', '60k km', '80k km', '100k km', '120k km', '160k km (Warranty)'],
    datasets: [
      {
        label: 'Actual / Projected SOH (%)',
        data: [100, 99.2, 98.4, 97.5, 96.2, 94.8, 93.1, 89.5],
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.3,
        fill: true
      },
      {
        label: 'Manufacturer Warranty Limit (75%)',
        data: [75, 75, 75, 75, 75, 75, 75, 75],
        borderColor: '#ef4444',
        borderDash: [6, 6],
        pointRadius: 0
      }
    ]
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Battery Health & Telemetry</h1>
          <p className="text-slate-500 text-xs mt-1">
            Real-time electrochemical condition, degradation trend, and thermal envelope monitoring
          </p>
        </div>
        <button
          onClick={fetchBatteryData}
          className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Telemetry</span>
        </button>
      </div>

      {/* Safety & Chemical Baseline Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase">Pack State of Health</span>
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">{reading.soh}%</div>
          <p className="text-xs text-slate-500 mt-1">Degradation: {status?.degradation_percentage || 2.5}%</p>
          <div className="mt-3 text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md inline-block">
            Within Nominal Warranty Bounds
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase">Operating Voltage</span>
            <Zap className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">{reading.voltage}V</div>
          <p className="text-xs text-slate-500 mt-1">Pack Nominal: ~390V (320V - 430V envelope)</p>
          <div className="mt-3 text-[11px] text-blue-700 font-semibold bg-blue-50 px-2.5 py-1 rounded-md inline-block">
            Balanced Cell Modules
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase">Pack Temperature</span>
            <Thermometer className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">{reading.temperature}°C</div>
          <p className="text-xs text-slate-500 mt-1">Thermal Safety Limit: 45.0°C</p>
          <div className={`mt-3 text-[11px] font-semibold px-2.5 py-1 rounded-md inline-block ${
            reading.temperature > 45 ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'
          }`}>
            {reading.temperature > 45 ? 'Thermal Alert Triggered' : 'Liquid Loop Operating'}
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase">Current Flow</span>
            <Activity className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">{reading.current}A</div>
          <p className="text-xs text-slate-500 mt-1">{reading.current < 0 ? 'Traction Discharge' : 'Regen / Charging Inflow'}</p>
          <div className="mt-3 text-[11px] text-purple-700 font-semibold bg-purple-50 px-2.5 py-1 rounded-md inline-block">
            Inverter Sync Normal
          </div>
        </div>
      </div>

      {/* Degradation Projections & Safety Limits */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-sm mb-1">Lithium-Ion Degradation Projection</h3>
          <p className="text-xs text-slate-400 mb-4">Capacity retention curve vs 160,000 km manufacturer warranty</p>
          <div className="h-64">
            <Line data={degradationChartData} options={{ responsive: true, maintainAspectRatio: false }} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-sm">BMS Configured Safety Envelope</h3>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Max Temp Threshold</span>
              <span className="font-bold text-slate-800">45.0 °C</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Min Temp Threshold</span>
              <span className="font-bold text-slate-800">-10.0 °C</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Max Voltage (Overvoltage)</span>
              <span className="font-bold text-slate-800">430.0 V</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Min Voltage (Severe Sag)</span>
              <span className="font-bold text-slate-800">320.0 V</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Max Current Drain</span>
              <span className="font-bold text-slate-800">260.0 A</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-500">Anomaly Detection</span>
              <span className="font-semibold text-emerald-600">Isolation Forest + Rules</span>
            </div>
          </div>
        </div>
      </div>

      {/* Historical Telemetry Stream Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Recent Telemetry Readings</h3>
            <p className="text-xs text-slate-400">Captured at vehicle sensor edge and ingested via REST APIs</p>
          </div>
          <span className="text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
            {history.length} records loaded
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-100">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">SOC (%)</th>
                <th className="px-4 py-3">SOH (%)</th>
                <th className="px-4 py-3">Voltage</th>
                <th className="px-4 py-3">Current</th>
                <th className="px-4 py-3">Temperature</th>
                <th className="px-4 py-3">Speed</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Integrity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-slate-700">
              {history.map((h) => (
                <tr key={h.id} className={h.is_anomaly ? 'bg-amber-50/50' : 'hover:bg-slate-50'}>
                  <td className="px-4 py-3 text-slate-500">
                    {new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </td>
                  <td className="px-4 py-3 font-semibold">{h.soc}%</td>
                  <td className="px-4 py-3">{h.soh}%</td>
                  <td className="px-4 py-3">{h.voltage} V</td>
                  <td className="px-4 py-3">{h.current} A</td>
                  <td className={`px-4 py-3 font-semibold ${h.temperature > 42 ? 'text-red-600' : 'text-slate-800'}`}>
                    {h.temperature} °C
                  </td>
                  <td className="px-4 py-3">{h.vehicle_speed} km/h</td>
                  <td className="px-4 py-3 capitalize font-sans">{h.charging_status}</td>
                  <td className="px-4 py-3 font-sans">
                    {h.is_anomaly ? (
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                        Anomaly Flagged
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        Verified Valid
                      </span>
                    )}
                  </td>
                </tr>
              ))}
              {history.length === 0 && (
                <tr>
                  <td colSpan="9" className="text-center py-8 text-slate-400 font-sans">
                    No telemetry history found. Click "Simulate Step" on the dashboard to generate readings.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BatteryHealth;
