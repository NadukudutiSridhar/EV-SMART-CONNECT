from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.schemas.analytics import AnalyticsSummaryResponse
from backend.app.security.auth import get_current_user
from backend.app.services.analytics_service import get_analytics_summary

router = APIRouter(prefix="/api", tags=["Analytics & Reports"])

@router.get("/analytics/summary", response_model=AnalyticsSummaryResponse)
def get_fleet_analytics_summary(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    is_admin = current_user.role == "admin"
    return get_analytics_summary(user_id=current_user.id, is_admin=is_admin, db=db)

@router.get("/reports")
def get_reports_data(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    summary = get_analytics_summary(user_id=current_user.id, is_admin=(current_user.role == "admin"), db=db)
    return {
        "report_generated_for": current_user.name,
        "role": current_user.role,
        "summary": summary
    }
