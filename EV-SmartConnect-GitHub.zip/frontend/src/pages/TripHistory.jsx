import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { tripsAPI } from '../services/api';
import { History, Plus, Navigation, Clock, Zap, Gauge, Calendar, X, AlertCircle } from 'lucide-react';

const TripHistory = () => {
  const { vehicles, selectedVehicleId } = useAuth();
  const currentVehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    start_location: '',
    destination: '',
    distance: 25.0,
    duration_minutes: 35,
    average_speed: 42.0,
    energy_consumed: 4.1,
    start_soc: 90.0,
    end_soc: 82.0
  });

  const fetchTrips = async () => {
    if (!currentVehicle) return;
    try {
      setLoading(true);
      const res = await tripsAPI.getTrips(currentVehicle.id);
      setTrips(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrips();
  }, [currentVehicle?.id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await tripsAPI.createTrip({
        vehicle_id: currentVehicle.id,
        ...formData
      });
      await fetchTrips();
      setIsModalOpen(false);
    } catch (err) {
      alert("Error recording trip: " + (err.response?.data?.detail || err.message));
    }
  };

  const totalKm = trips.reduce((acc, t) => acc + t.distance, 0).toFixed(1);
  const totalKwh = trips.reduce((acc, t) => acc + t.energy_consumed, 0).toFixed(1);
  const avgEfficiency = totalKm > 0 ? ((totalKwh / totalKm) * 100).toFixed(1) : 16.5;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Trip History & Energy Consumption</h1>
          <p className="text-slate-500 text-xs mt-1">
            Historical trip analytics, driving efficiency patterns, and battery discharge performance
          </p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Log New Trip</span>
        </button>
      </div>

      {/* Aggregate KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Total Logged Distance
          </span>
          <div className="text-3xl font-extrabold text-slate-900">
            {totalKm} <span className="text-base font-semibold text-slate-500">km</span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">{trips.length} completed trips</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Total Energy Drawn
          </span>
          <div className="text-3xl font-extrabold text-slate-900">
            {totalKwh} <span className="text-base font-semibold text-slate-500">kWh</span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">From battery pack</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Fleet Average Efficiency
          </span>
          <div className="text-3xl font-extrabold text-emerald-600">
            {avgEfficiency} <span className="text-base font-semibold text-slate-500">kWh/100km</span>
          </div>
          <span className="text-xs text-emerald-700 mt-1 block">Optimal EV driving performance</span>
        </div>
      </div>

      {/* Trips Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">Trip Log</h3>
          <span className="text-xs text-slate-400">{trips.length} records</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-100">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Route (Origin → Destination)</th>
                <th className="px-4 py-3">Distance</th>
                <th className="px-4 py-3">Duration</th>
                <th className="px-4 py-3">Avg Speed</th>
                <th className="px-4 py-3">Energy Used</th>
                <th className="px-4 py-3">Efficiency</th>
                <th className="px-4 py-3">SOC Delta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {trips.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50/70">
                  <td className="px-4 py-3 text-slate-500 font-mono">{t.trip_date}</td>
                  <td className="px-4 py-3 font-semibold text-slate-900">
                    {t.start_location} <span className="text-slate-400">→</span> {t.destination}
                  </td>
                  <td className="px-4 py-3 font-mono font-medium">{t.distance} km</td>
                  <td className="px-4 py-3 font-mono">{t.duration_minutes} mins</td>
                  <td className="px-4 py-3 font-mono">{t.average_speed} km/h</td>
                  <td className="px-4 py-3 font-mono font-semibold">{t.energy_consumed} kWh</td>
                  <td className="px-4 py-3 font-mono text-emerald-600 font-bold">{t.efficiency} kWh/100km</td>
                  <td className="px-4 py-3 font-mono text-slate-500">
                    {t.start_soc}% → {t.end_soc}% (-{Math.round(t.start_soc - t.end_soc)}%)
                  </td>
                </tr>
              ))}
              {trips.length === 0 && (
                <tr>
                  <td colSpan="8" className="text-center py-8 text-slate-400">
                    No trips recorded yet. Click "Log New Trip" to add one.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Trip Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-bold text-slate-900 text-base">Record Completed Trip</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Starting Location</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Indiranagar, Bengaluru"
                  value={formData.start_location}
                  onChange={(e) => setFormData({ ...formData, start_location: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Destination</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Kempegowda Airport"
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Distance (km)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={formData.distance}
                    onChange={(e) => setFormData({ ...formData, distance: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Duration (minutes)</label>
                  <input
                    type="number"
                    required
                    value={formData.duration_minutes}
                    onChange={(e) => setFormData({ ...formData, duration_minutes: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Average Speed (km/h)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={formData.average_speed}
                    onChange={(e) => setFormData({ ...formData, average_speed: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Energy Used (kWh)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={formData.energy_consumed}
                    onChange={(e) => setFormData({ ...formData, energy_consumed: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Start SOC (%)</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    required
                    value={formData.start_soc}
                    onChange={(e) => setFormData({ ...formData, start_soc: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">End SOC (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    required
                    value={formData.end_soc}
                    onChange={(e) => setFormData({ ...formData, end_soc: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-semibold"
                >
                  Save Trip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TripHistory;
