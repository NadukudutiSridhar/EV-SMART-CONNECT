from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Optional

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.charging import ChargingStation, ChargingSession
from backend.app.schemas.charging import (
    ChargingStationCreate, ChargingStationResponse,
    ChargingSessionCreate, ChargingSessionResponse,
    ChargingRecommendationRequest, ChargingRecommendationResponse
)
from backend.app.security.auth import get_current_user, require_admin, verify_vehicle_ownership
from backend.app.services.charging_service import get_stations_with_distance, generate_smart_charging_recommendation

router = APIRouter(prefix="/api", tags=["Charging Stations & Sessions"])

@router.get("/stations", response_model=List[ChargingStationResponse])
def get_charging_stations(
    lat: Optional[float] = Query(12.9716, description="Latitude"),
    lon: Optional[float] = Query(77.5946, description="Longitude"),
    connector: Optional[str] = Query(None, description="Connector filter (CCS2, Type 2, CHAdeMO)"),
    min_speed: Optional[float] = Query(None, description="Minimum kW power"),
    db: Session = Depends(get_db)
):
    """Retrieve charging stations sorted by proximity with optional connector and speed filters."""
    return get_stations_with_distance(lat, lon, db, connector, min_speed)

@router.post("/stations", response_model=ChargingStationResponse, status_code=status.HTTP_201_CREATED)
def create_charging_station(req: ChargingStationCreate, current_user: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Admin endpoint to register a new charging station."""
    station = ChargingStation(
        name=req.name.strip(),
        operator=req.operator.strip() if req.operator else "Independent",
        address=req.address.strip(),
        latitude=req.latitude,
        longitude=req.longitude,
        connector_types=req.connector_types,
        charging_speed=req.charging_speed,
        total_ports=req.total_ports,
        available_ports=req.available_ports,
        price_per_kwh=req.price_per_kwh,
        is_simulated_availability=req.is_simulated_availability,
        is_active=True
    )
    db.add(station)
    db.commit()
    db.refresh(station)
    return station

@router.get("/charging-sessions", response_model=List[ChargingSessionResponse])
def get_charging_sessions(vehicle_id: Optional[int] = None, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get charging sessions for user's vehicles."""
    query = db.query(ChargingSession)
    if vehicle_id:
        verify_vehicle_ownership(vehicle_id, current_user, db)
        query = query.filter(ChargingSession.vehicle_id == vehicle_id)
    elif current_user.role != "admin":
        user_vehicle_ids = [v.id for v in current_user.vehicles]
        query = query.filter(ChargingSession.vehicle_id.in_(user_vehicle_ids))

    sessions = query.order_by(ChargingSession.start_time.desc()).all()
    resp = []
    for s in sessions:
        r = ChargingSessionResponse.from_orm(s)
        if s.station:
            r.station_name = s.station.name
        resp.append(r)
    return resp

@router.post("/charging-sessions", response_model=ChargingSessionResponse, status_code=status.HTTP_201_CREATED)
def start_charging_session(req: ChargingSessionCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    verify_vehicle_ownership(req.vehicle_id, current_user, db)
    station = db.query(ChargingStation).filter(ChargingStation.id == req.station_id).first()
    if not station:
        raise HTTPException(status_code=404, detail="Charging station not found")

    session = ChargingSession(
        vehicle_id=req.vehicle_id,
        station_id=req.station_id,
        start_soc=req.start_soc,
        end_soc=req.end_soc,
        energy_consumed=req.energy_consumed or 0.0,
        total_cost=req.total_cost or 0.0,
        status="active"
    )
    db.add(session)
    # Decrement available ports if any
    if station.available_ports > 0:
        station.available_ports -= 1
    db.commit()
    db.refresh(session)
    
    resp = ChargingSessionResponse.from_orm(session)
    resp.station_name = station.name
    return resp

@router.post("/recommendations", response_model=ChargingRecommendationResponse)
def get_charging_recommendation(req: ChargingRecommendationRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Generate smart AI charging recommendation for trip planning."""
    verify_vehicle_ownership(req.vehicle_id, current_user, db)
    try:
        rec = generate_smart_charging_recommendation(req, db)
        return rec
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
