from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class BatteryReadingCreate(BaseModel):
    vehicle_id: int
    soc: float = Field(..., ge=0.0, le=100.0, description="State of Charge (%)")
    soh: float = Field(..., ge=30.0, le=100.0, description="State of Health (%)")
    voltage: float = Field(..., ge=200.0, le=900.0, description="Voltage in Volts")
    current: float = Field(..., ge=-600.0, le=600.0, description="Current in Amperes")
    temperature: float = Field(..., ge=-30.0, le=80.0, description="Battery temp in Celsius")
    vehicle_speed: Optional[float] = 0.0
    energy_consumption: Optional[float] = 16.0
    distance_travelled: Optional[float] = 0.0
    charging_status: Optional[str] = "idle"
    is_simulated: Optional[bool] = True

class BatteryReadingResponse(BaseModel):
    id: int
    vehicle_id: int
    soc: float
    soh: float
    voltage: float
    current: float
    temperature: float
    vehicle_speed: float
    energy_consumption: float
    distance_travelled: float
    charging_status: str
    is_simulated: bool
    is_anomaly: bool
    timestamp: datetime

    class Config:
        from_attributes = True

class BatteryStatusOverview(BaseModel):
    vehicle_id: int
    latest_reading: Optional[BatteryReadingResponse]
    safety_status: str # "Normal", "Warning", "Critical"
    active_warnings: list[str]
    predicted_range_km: float
    degradation_percentage: float
