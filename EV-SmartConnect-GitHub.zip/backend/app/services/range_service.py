from sqlalchemy.orm import Session
from backend.app.models.range_prediction import RangePrediction
from backend.app.models.vehicle import Vehicle
from backend.app.schemas.range_prediction import RangePredictionRequest
from ml.predict import predict_ev_range

def compute_and_save_prediction(req: RangePredictionRequest, db: Session) -> dict:
    """Invokes ML model and saves the prediction record to database if vehicle_id is provided."""
    battery_capacity = req.battery_capacity or 75.0
    if req.vehicle_id:
        vehicle = db.query(Vehicle).filter(Vehicle.id == req.vehicle_id).first()
        if vehicle:
            battery_capacity = vehicle.battery_capacity

    ml_result = predict_ev_range(
        battery_capacity=battery_capacity,
        soc=req.soc,
        soh=req.soh,
        temperature=req.temperature,
        avg_speed=req.avg_speed,
        vehicle_load=req.vehicle_load,
        energy_consumption=req.energy_consumption,
        terrain=req.terrain
    )

    pred_id = None
    if req.vehicle_id:
        db_pred = RangePrediction(
            vehicle_id=req.vehicle_id,
            predicted_range=ml_result["predicted_range_km"],
            battery_soc=req.soc,
            battery_soh=req.soh,
            battery_temp=req.temperature,
            avg_speed=req.avg_speed,
            vehicle_load=req.vehicle_load,
            energy_consumption=req.energy_consumption,
            terrain_condition=req.terrain,
            model_version="RandomForest-v1.0",
            confidence_score=ml_result["confidence_score"]
        )
        db.add(db_pred)
        db.commit()
        db.refresh(db_pred)
        pred_id = db_pred.id

    return {
        "id": pred_id,
        "vehicle_id": req.vehicle_id,
        "predicted_range_km": ml_result["predicted_range_km"],
        "confidence_score": ml_result["confidence_score"],
        "model_version": "RandomForest-v1.0",
        "features_used": ml_result["features_used"],
        "disclaimer": ml_result["disclaimer"]
    }
