from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.schemas.auth import UserRegisterRequest, UserLoginRequest, TokenResponse, UserResponse
from backend.app.security.auth import hash_password, verify_password, create_access_token, get_current_user
from backend.app.security.middleware import audit_log

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register_user(req: UserRegisterRequest, db: Session = Depends(get_db)):
    # Check if email is already taken
    existing_user = db.query(User).filter(User.email == req.email.lower()).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists"
        )

    # First user automatically becomes admin if no users exist
    is_first_user = db.query(User).count() == 0
    assigned_role = "admin" if is_first_user else (req.role if req.role in ["user", "admin"] else "user")

    user = User(
        name=req.name.strip(),
        email=req.email.lower().strip(),
        password_hash=hash_password(req.password),
        role=assigned_role,
        phone=req.phone,
        is_active=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    audit_log("USER_REGISTER", user.email, f"Role: {user.role}")
    token = create_access_token(data={"sub": user.email, "role": user.role, "uid": user.id})
    return TokenResponse(access_token=token, token_type="bearer", user=UserResponse.from_orm(user))

@router.post("/login", response_model=TokenResponse)
def login_user(req: UserLoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email.lower().strip()).first()
    if not user or not verify_password(req.password, user.password_hash):
        audit_log("LOGIN_FAILED", req.email, "Invalid credentials")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"}
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is deactivated. Please contact support."
        )

    audit_log("USER_LOGIN_SUCCESS", user.email, f"Role: {user.role}")
    token = create_access_token(data={"sub": user.email, "role": user.role, "uid": user.id})
    return TokenResponse(access_token=token, token_type="bearer", user=UserResponse.from_orm(user))

@router.get("/me", response_model=UserResponse)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    return UserResponse.from_orm(current_user)
