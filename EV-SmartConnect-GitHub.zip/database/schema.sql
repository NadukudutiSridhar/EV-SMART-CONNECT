-- =====================================================================
-- EV SmartConnect: Database Schema
-- Dialect: MySQL 8.0+ / Compatible with standard SQL
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ev_smartconnect;
USE ev_smartconnect;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user' NOT NULL,
    phone VARCHAR(30) NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Vehicles Table
CREATE TABLE IF NOT EXISTS vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    model VARCHAR(120) NOT NULL,
    make VARCHAR(80) NOT NULL,
    registration_number VARCHAR(50) NOT NULL UNIQUE,
    vin VARCHAR(50) NULL UNIQUE,
    battery_capacity FLOAT NOT NULL COMMENT 'Capacity in kWh (e.g. 75.0)',
    vehicle_type VARCHAR(50) DEFAULT 'Sedan' NOT NULL COMMENT 'Sedan, SUV, Hatchback, Truck, Commercial',
    manufacturing_year INT NOT NULL,
    firmware_version VARCHAR(50) DEFAULT 'v2.4.1',
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_vehicles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_vehicles_user (user_id),
    INDEX idx_vehicles_reg (registration_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Battery Readings Table (Simulated & Live Telemetry)
CREATE TABLE IF NOT EXISTS battery_readings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    soc FLOAT NOT NULL COMMENT 'State of Charge in % (0 - 100)',
    soh FLOAT NOT NULL COMMENT 'State of Health in % (0 - 100)',
    voltage FLOAT NOT NULL COMMENT 'Pack voltage in Volts (e.g. 380 - 420V)',
    current FLOAT NOT NULL COMMENT 'Current in Amperes (negative for discharge, positive for charging)',
    temperature FLOAT NOT NULL COMMENT 'Battery pack temperature in Celsius',
    vehicle_speed FLOAT DEFAULT 0.0 NOT NULL COMMENT 'Current speed in km/h',
    energy_consumption FLOAT DEFAULT 0.0 NOT NULL COMMENT 'Instantaneous/segment consumption in kWh/100km',
    distance_travelled FLOAT DEFAULT 0.0 NOT NULL COMMENT 'Odometer/distance in km',
    charging_status ENUM('discharging', 'charging', 'idle', 'fast_charging') DEFAULT 'idle' NOT NULL,
    is_simulated BOOLEAN DEFAULT TRUE NOT NULL,
    is_anomaly BOOLEAN DEFAULT FALSE NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_battery_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    INDEX idx_battery_vehicle_ts (vehicle_id, timestamp),
    INDEX idx_battery_anomaly (is_anomaly)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Range Predictions Table
CREATE TABLE IF NOT EXISTS range_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    predicted_range FLOAT NOT NULL COMMENT 'Predicted driving range in km',
    battery_soc FLOAT NOT NULL,
    battery_soh FLOAT NOT NULL,
    battery_temp FLOAT NOT NULL,
    avg_speed FLOAT NOT NULL,
    vehicle_load FLOAT DEFAULT 0.0 COMMENT 'Passenger/cargo load in kg',
    energy_consumption FLOAT NOT NULL,
    terrain_condition VARCHAR(50) DEFAULT 'flat' COMMENT 'flat, uphill, downhill, mixed',
    model_version VARCHAR(50) DEFAULT 'RandomForest-v1.0',
    confidence_score FLOAT DEFAULT 0.95,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_predictions_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    INDEX idx_pred_vehicle_ts (vehicle_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Charging Stations Table
CREATE TABLE IF NOT EXISTS charging_stations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    operator VARCHAR(120) DEFAULT 'Independent',
    address VARCHAR(255) NOT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    connector_types VARCHAR(120) NOT NULL COMMENT 'CCS2, Type 2, CHAdeMO, GB/T',
    charging_speed FLOAT NOT NULL COMMENT 'Max power output in kW (e.g. 22.0, 50.0, 150.0)',
    total_ports INT DEFAULT 4 NOT NULL,
    available_ports INT DEFAULT 2 NOT NULL,
    price_per_kwh FLOAT DEFAULT 15.0 NOT NULL,
    is_simulated_availability BOOLEAN DEFAULT TRUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_stations_lat_lng (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Charging Sessions Table
CREATE TABLE IF NOT EXISTS charging_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    station_id INT NOT NULL,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time TIMESTAMP NULL,
    start_soc FLOAT NOT NULL,
    end_soc FLOAT NULL,
    energy_consumed FLOAT DEFAULT 0.0 COMMENT 'Total energy in kWh',
    total_cost FLOAT DEFAULT 0.0,
    status ENUM('active', 'completed', 'interrupted') DEFAULT 'active' NOT NULL,
    CONSTRAINT fk_sessions_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    CONSTRAINT fk_sessions_station FOREIGN KEY (station_id) REFERENCES charging_stations(id) ON DELETE CASCADE,
    INDEX idx_sessions_vehicle (vehicle_id),
    INDEX idx_sessions_station (station_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Maintenance Alerts Table
CREATE TABLE IF NOT EXISTS maintenance_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    alert_type VARCHAR(100) NOT NULL COMMENT 'Temperature, Voltage, Current, SOH_Degradation, Consumption',
    severity ENUM('Low', 'Medium', 'High') DEFAULT 'Medium' NOT NULL,
    description TEXT NOT NULL,
    recommended_action TEXT NOT NULL,
    sensor_value FLOAT NULL,
    threshold_value FLOAT NULL,
    detection_method VARCHAR(50) DEFAULT 'Threshold' COMMENT 'Threshold, IsolationForest, Heuristic',
    is_resolved BOOLEAN DEFAULT FALSE NOT NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_alerts_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    INDEX idx_alerts_vehicle (vehicle_id),
    INDEX idx_alerts_severity (severity),
    INDEX idx_alerts_resolved (is_resolved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Trip Records Table
CREATE TABLE IF NOT EXISTS trip_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    start_location VARCHAR(160) NOT NULL,
    destination VARCHAR(160) NOT NULL,
    distance FLOAT NOT NULL COMMENT 'Distance in km',
    duration_minutes INT NOT NULL,
    average_speed FLOAT NOT NULL COMMENT 'Average speed in km/h',
    energy_consumed FLOAT NOT NULL COMMENT 'Total kWh consumed during trip',
    efficiency FLOAT NOT NULL COMMENT 'kWh per 100km',
    start_soc FLOAT NOT NULL,
    end_soc FLOAT NOT NULL,
    trip_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_trips_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    INDEX idx_trips_vehicle (vehicle_id),
    INDEX idx_trips_date (trip_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
