def test_register_first_user_becomes_admin(client):
    response = client.post("/api/auth/register", json={
        "name": "Super Admin",
        "email": "admin_suite@test.com",
        "password": "Password@123",
        "role": "admin"
    })
    assert response.status_code == 201
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == "admin_suite@test.com"

def test_register_duplicate_email_rejected(client):
    client.post("/api/auth/register", json={
        "name": "User One",
        "email": "user_suite@test.com",
        "password": "Password@123"
    })
    response = client.post("/api/auth/register", json={
        "name": "User Duplicate",
        "email": "user_suite@test.com",
        "password": "Password@123"
    })
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"]

def test_login_success_and_failure(client):
    client.post("/api/auth/register", json={
        "name": "Login User",
        "email": "login_suite@test.com",
        "password": "CorrectPassword@123"
    })

    login_resp = client.post("/api/auth/login", json={
        "email": "login_suite@test.com",
        "password": "CorrectPassword@123"
    })
    assert login_resp.status_code == 200
    token = login_resp.json()["access_token"]
    assert token is not None

    bad_login = client.post("/api/auth/login", json={
        "email": "login_suite@test.com",
        "password": "WrongPassword!"
    })
    assert bad_login.status_code == 401

def test_get_current_user_profile(client):
    reg = client.post("/api/auth/register", json={
        "name": "Profile User",
        "email": "profile_suite@test.com",
        "password": "Password@123"
    })
    token = reg.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    me_resp = client.get("/api/auth/me", headers=headers)
    assert me_resp.status_code == 200
    assert me_resp.json()["name"] == "Profile User"
