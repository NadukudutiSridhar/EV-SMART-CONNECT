import os
import json
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    APP_NAME: str = "EV SmartConnect"
    APP_ENV: str = "development"
    DEBUG: bool = True
    PORT: int = 8000

    # JWT Security
    SECRET_KEY: str = "supersecretkey_change_in_production_jwt_ev_smartconnect_2026_secure"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440 # 24 hours

    # Database
    DATABASE_URL: str = "sqlite:///./ev_smartconnect.db"

    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ]

    # ML Model Paths
    RANGE_MODEL_PATH: str = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../ml/range_model.pkl"))
    ANOMALY_MODEL_PATH: str = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../ml/anomaly_model.pkl"))

    # Battery Engineering Safety Limits
    BATTERY_MAX_TEMP: float = 45.0       # Celsius
    BATTERY_MIN_TEMP: float = -10.0      # Celsius
    BATTERY_MAX_VOLTAGE: float = 430.0   # Volts
    BATTERY_MIN_VOLTAGE: float = 320.0   # Volts
    BATTERY_MAX_CURRENT: float = 260.0   # Amperes
    BATTERY_MIN_SOH: float = 75.0        # % SOH minimum warranty baseline

    class Config:
        env_file = ".env"
        extra = "allow"

settings = Settings()
