import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { batteryAPI, maintenanceAPI, aiAPI } from '../services/api';
import {
  Battery,
  Zap,
  Gauge,
  Thermometer,
  Activity,
  AlertTriangle,
  Compass,
  ArrowUpRight,
  RefreshCw,
  Play,
  CheckCircle,
  Car
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const Dashboard = () => {
  const { vehicles, selectedVehicleId } = useAuth();
  const navigate = useNavigate();
  const [batteryStatus, setBatteryStatus] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simMessage, setSimMessage] = useState('');

  const currentVehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  const fetchDashboardData = async () => {
    if (!currentVehicle) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const [statusRes, historyRes] = await Promise.all([
        batteryAPI.getStatus(currentVehicle.id),
        batteryAPI.getHistory(currentVehicle.id, 25)
      ]);
      setBatteryStatus(statusRes.data);
      setHistory(historyRes.data);
    } catch (err) {
      console.error("Dashboard fetch failed", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [currentVehicle?.id]);

  // Simulate one live telemetry packet
  const handleSimulateStep = async (anomaly = false) => {
    if (!currentVehicle) return;
    setIsSimulating(true);
    setSimMessage('');
    try {
      const currentSoc = batteryStatus?.latest_reading?.soc || 80.0;
      const nextSoc = anomaly ? Math.max(5.0, currentSoc - 2.5) : Math.max(5.0, currentSoc - 0.4);
      const temp = anomaly ? 49.5 : (26.0 + Math.random() * 3.5);
      const volt = anomaly ? 305.0 : (388.0 + Math.random() * 8.0);
      const currentA = anomaly ? -120.0 : (-30.0 - Math.random() * 20.0);
      const speed = anomaly ? 95.0 : (45.0 + Math.random() * 40.0);

      await batteryAPI.submitReading({
        vehicle_id: currentVehicle.id,
        soc: parseFloat(nextSoc.toFixed(1)),
        soh: batteryStatus?.latest_reading?.soh || 97.0,
        voltage: parseFloat(volt.toFixed(1)),
        current: parseFloat(currentA.toFixed(1)),
        temperature: parseFloat(temp.toFixed(1)),
        vehicle_speed: parseFloat(speed.toFixed(1)),
        energy_consumption: anomaly ? 28.5 : 16.4,
        distance_travelled: (batteryStatus?.latest_reading?.distance_travelled || 1200) + 1.2,
        charging_status: "discharging",
        is_simulated: true
      });

      setSimMessage(anomaly ? '⚠️ Simulated Anomaly Injected & Detected!' : '⚡ Simulated Driving Telemetry Streamed!');
      await fetchDashboardData();
    } catch (err) {
      setSimMessage('Simulation error: ' + (err.response?.data?.detail || err.message));
    } finally {
      setIsSimulating(false);
      setTimeout(() => setSimMessage(''), 4000);
    }
  };

  if (!currentVehicle) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 max-w-xl mx-auto mt-10">
        <Car className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">No Electric Vehicle Registered</h2>
        <p className="text-slate-500 text-sm mb-6">
          Add your electric vehicle to begin telemetry monitoring, range prediction, and health alerts.
        </p>
        <button
          onClick={() => navigate('/vehicles')}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-sm transition-all"
        >
          Add Your First Vehicle
        </button>
      </div>
    );
  }

  const reading = batteryStatus?.latest_reading || {
    soc: 85.0,
    soh: 98.0,
    voltage: 392.4,
    current: -32.5,
    temperature: 28.4,
    vehicle_speed: 62.0,
    energy_consumption: 16.2,
    distance_travelled: 1250.0,
    charging_status: 'discharging'
  };

  const chartLabels = history.length > 0 
    ? history.map(h => new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }))
    : ['10:00', '10:05', '10:10', '10:15', '10:20', '10:25', '10:30'];

  const socHistoryData = history.length > 0 ? history.map(h => h.soc) : [88, 87.5, 87, 86.2, 85.8, 85.2, 85.0];
  const tempHistoryData = history.length > 0 ? history.map(h => h.temperature) : [25, 26, 26.5, 27, 27.8, 28.1, 28.4];

  const chartData = {
    labels: chartLabels,
    datasets: [
      {
        label: 'State of Charge (SOC %)',
        data: socHistoryData,
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.35,
        fill: true,
        yAxisID: 'y'
      },
      {
        label: 'Pack Temp (°C)',
        data: tempHistoryData,
        borderColor: '#f59e0b',
        backgroundColor: 'transparent',
        borderDash: [4, 4],
        tension: 0.35,
        yAxisID: 'y1'
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: { boxWidth: 12, font: { size: 11 } }
      },
      tooltip: { mode: 'index', intersect: false }
    },
    scales: {
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        min: 0,
        max: 100,
        grid: { color: '#f1f5f9' },
        ticks: { callback: v => `${v}%` }
      },
      y1: {
        type: 'linear',
        display: true,
        position: 'right',
        min: 15,
        max: 60,
        grid: { drawOnChartArea: false },
        ticks: { callback: v => `${v}°C` }
      },
      x: { grid: { display: false } }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Vehicle Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              {currentVehicle.make} {currentVehicle.model}
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-mono font-medium">
              {currentVehicle.registration_number}
            </span>
          </div>
          <p className="text-slate-500 text-xs mt-1">
            Battery Capacity: <span className="font-semibold text-slate-700">{currentVehicle.battery_capacity} kWh</span> • 
            Firmware: <span className="font-semibold text-slate-700">{currentVehicle.firmware_version}</span>
          </p>
        </div>

        {/* Action Controls & Simulation Bar */}
        <div className="flex flex-wrap items-center gap-2">
          {simMessage && (
            <span className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 animate-fade-in">
              {simMessage}
            </span>
          )}
          <button
            onClick={() => handleSimulateStep(false)}
            disabled={isSimulating}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition-all shadow-sm shadow-emerald-600/20"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>Simulate Step</span>
          </button>
          <button
            onClick={() => handleSimulateStep(true)}
            disabled={isSimulating}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-semibold transition-all"
            title="Inject simulated thermal or voltage anomaly"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Inject Anomaly</span>
          </button>
          <button
            onClick={fetchDashboardData}
            className="p-2 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-xl transition-colors"
            title="Refresh Telemetry"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Safety Alert Warning Banner if present */}
      {batteryStatus?.safety_status !== 'Normal' && batteryStatus?.active_warnings?.length > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-bold text-amber-900">
              Active Battery Safety Warnings ({batteryStatus.safety_status})
            </h4>
            <ul className="text-xs text-amber-800 mt-1 list-disc list-inside space-y-0.5">
              {batteryStatus.active_warnings.map((w, idx) => (
                <li key={idx}>{w}</li>
              ))}
            </ul>
          </div>
          <button
            onClick={() => navigate('/maintenance')}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold"
          >
            Inspect Alerts
          </button>
        </div>
      )}

      {/* Key Metric KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Card 1: State of Charge */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Battery SOC</span>
            <Battery className="w-4 h-4 text-emerald-500" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{reading.soc}%</div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-2">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  reading.soc > 30 ? 'bg-emerald-500' : (reading.soc > 15 ? 'bg-amber-500' : 'bg-red-500')
                }`}
                style={{ width: `${Math.min(100, reading.soc)}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Card 2: AI Predicted Range */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">AI Range</span>
            <Compass className="w-4 h-4 text-emerald-600" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">
              {batteryStatus?.predicted_range_km || Math.round((currentVehicle.battery_capacity * (reading.soc/100)) / 0.165)}
              <span className="text-xs font-semibold text-slate-500 ml-1">km</span>
            </div>
            <span className="text-[11px] text-emerald-600 font-medium">Random Forest Est.</span>
          </div>
        </div>

        {/* Card 3: Battery Health (SOH) */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Health (SOH)</span>
            <Activity className="w-4 h-4 text-teal-500" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{reading.soh}%</div>
            <span className="text-[11px] text-slate-500 font-medium">
              Degradation: {batteryStatus?.degradation_percentage || 2.0}%
            </span>
          </div>
        </div>

        {/* Card 4: Battery Temperature */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Pack Temp</span>
            <Thermometer className={`w-4 h-4 ${reading.temperature > 40 ? 'text-red-500' : 'text-amber-500'}`} />
          </div>
          <div>
            <div className={`text-2xl font-extrabold ${reading.temperature > 45 ? 'text-red-600' : 'text-slate-900'}`}>
              {reading.temperature}°C
            </div>
            <span className="text-[11px] text-slate-500 font-medium">
              {reading.temperature > 45 ? 'Critical Warning' : (reading.temperature > 35 ? 'Elevated' : 'Optimal (25-32°C)')}
            </span>
          </div>
        </div>

        {/* Card 5: Pack Voltage */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Voltage</span>
            <Zap className="w-4 h-4 text-blue-500" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{reading.voltage}V</div>
            <span className="text-[11px] text-slate-500 font-medium">Current: {reading.current}A</span>
          </div>
        </div>

        {/* Card 6: Efficiency */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Consumption</span>
            <Gauge className="w-4 h-4 text-purple-500" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{reading.energy_consumption}</div>
            <span className="text-[11px] text-slate-500 font-medium">kWh / 100km</span>
          </div>
        </div>
      </div>

      {/* Main Charts & Quick Action Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Live Telemetry Line Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Battery SOC & Temperature Telemetry</h3>
              <p className="text-xs text-slate-400">Chronological telemetry feed with anomaly boundary tracking</p>
            </div>
            <span className="text-xs px-2.5 py-1 bg-slate-100 rounded-lg text-slate-600 font-mono">
              Status: <span className="capitalize font-bold text-emerald-600">{reading.charging_status}</span>
            </span>
          </div>
          <div className="h-72 w-full">
            <Line data={chartData} options={chartOptions} />
          </div>
        </div>

        {/* Right Col: Quick Decision Center */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">Vehicle Operation Quick Actions</h3>
            <p className="text-xs text-slate-400 mb-4">AI assistance and route readiness</p>

            <div className="space-y-3">
              <button
                onClick={() => navigate('/range-prediction')}
                className="w-full p-3 rounded-xl border border-slate-200 hover:border-emerald-500/50 hover:bg-emerald-50/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                    What-If Range Calculator
                  </div>
                  <div className="text-[11px] text-slate-500">Test range under payload, speed & elevation</div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600" />
              </button>

              <button
                onClick={() => navigate('/smart-charging')}
                className="w-full p-3 rounded-xl border border-slate-200 hover:border-emerald-500/50 hover:bg-emerald-50/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                    Smart Charging Advisor
                  </div>
                  <div className="text-[11px] text-slate-500">Calculate destination shortfall & charge time</div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600" />
              </button>

              <button
                onClick={() => navigate('/stations')}
                className="w-full p-3 rounded-xl border border-slate-200 hover:border-emerald-500/50 hover:bg-emerald-50/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                    Nearby Charging Map
                  </div>
                  <div className="text-[11px] text-slate-500">View real-time fast chargers and ports</div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600" />
              </button>
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/60 text-xs text-slate-500 space-y-1">
            <div className="font-semibold text-slate-700 flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
              <span>Simulated Telemetry Safeguard</span>
            </div>
            <div>All generated sensor telemetry is labeled and validated against impossible voltage/temperature bounds.</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
