import os
import joblib
import pandas as pd
import numpy as np

MODEL_PATH = os.path.join(os.path.dirname(__file__), "range_model.pkl")
ANOMALY_MODEL_PATH = os.path.join(os.path.dirname(__file__), "anomaly_model.pkl")

# Cached model instances
_range_model = None
_anomaly_model = None

def get_range_model():
    global _range_model
    if _range_model is None:
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(f"Model file not found at {MODEL_PATH}. Run train_model.py first.")
        _range_model = joblib.load(MODEL_PATH)
    return _range_model

def get_anomaly_model():
    global _anomaly_model
    if _anomaly_model is None:
        if not os.path.exists(ANOMALY_MODEL_PATH):
            raise FileNotFoundError(f"Anomaly model file not found at {ANOMALY_MODEL_PATH}. Run train_model.py first.")
        _anomaly_model = joblib.load(ANOMALY_MODEL_PATH)
    return _anomaly_model

def predict_ev_range(
    battery_capacity: float,
    soc: float,
    soh: float,
    temperature: float,
    avg_speed: float,
    vehicle_load: float,
    energy_consumption: float,
    terrain: str = "flat"
) -> dict:
    """
    Predict remaining driving range in km using the trained machine learning model.
    """
    model = get_range_model()
    
    # Input validation & clamping
    soc = max(0.0, min(100.0, float(soc)))
    soh = max(50.0, min(100.0, float(soh)))
    temperature = max(-30.0, min(60.0, float(temperature)))
    avg_speed = max(0.0, min(200.0, float(avg_speed)))
    vehicle_load = max(0.0, min(1000.0, float(vehicle_load)))
    energy_consumption = max(5.0, min(50.0, float(energy_consumption)))
    terrain = terrain.lower() if terrain.lower() in ['flat', 'uphill', 'downhill', 'mixed'] else 'flat'

    # If battery is empty, range is 0
    if soc <= 0.5:
        return {
            "predicted_range_km": 0.0,
            "confidence_score": 0.99,
            "disclaimer": "Battery depleted."
        }

    input_df = pd.DataFrame([{
        'battery_capacity': battery_capacity,
        'soc': soc,
        'soh': soh,
        'temperature': temperature,
        'avg_speed': avg_speed,
        'vehicle_load': vehicle_load,
        'energy_consumption': energy_consumption,
        'terrain': terrain
    }])

    raw_prediction = model.predict(input_df)[0]
    predicted_km = round(max(0.0, float(raw_prediction)), 1)
    
    # Estimate confidence based on typical feature space boundary
    confidence = 0.95
    if temperature < 0 or temperature > 40 or avg_speed > 120:
        confidence = 0.88

    return {
        "predicted_range_km": predicted_km,
        "confidence_score": confidence,
        "features_used": {
            "battery_capacity": battery_capacity,
            "soc": soc,
            "soh": soh,
            "temperature": temperature,
            "avg_speed": avg_speed,
            "vehicle_load": vehicle_load,
            "energy_consumption": energy_consumption,
            "terrain": terrain
        },
        "disclaimer": "AI estimate based on operational telemetry and trained models."
    }

def detect_telemetry_anomaly(
    voltage: float,
    current: float,
    temperature: float,
    soc: float,
    energy_consumption: float
) -> dict:
    """
    Detect if battery telemetry readings are anomalous using Isolation Forest + rule thresholds.
    """
    rule_reasons = []
    
    # Heuristic Threshold checks (Engineering safety limits)
    if temperature > 45.0:
        rule_reasons.append(f"Critical battery temperature detected: {temperature}°C exceeds safe threshold (45°C).")
    elif temperature < -10.0:
        rule_reasons.append(f"Sub-zero battery temperature: {temperature}°C may cause lithium plating.")

    if voltage > 430.0:
        rule_reasons.append(f"Over-voltage condition: {voltage}V exceeds maximum cell pack limit (430V).")
    elif voltage < 320.0 and soc > 10.0:
        rule_reasons.append(f"Severe voltage sag: {voltage}V at {soc}% SOC indicates cell imbalance or internal resistance spike.")

    if abs(current) > 260.0:
        rule_reasons.append(f"Abnormal current draw: {abs(current)}A exceeds thermal safe operating envelope.")

    # Isolation Forest check
    iso_is_anomaly = False
    iso_score = 0.0
    try:
        iso_model = get_anomaly_model()
        X = np.array([[voltage, current, temperature, soc, energy_consumption]])
        pred = iso_model.predict(X)[0] # -1 is anomaly, 1 is normal
        score = iso_model.decision_function(X)[0]
        iso_is_anomaly = (pred == -1)
        iso_score = round(float(score), 4)
    except Exception as e:
        iso_is_anomaly = False

    is_anomaly = bool(len(rule_reasons) > 0 or iso_is_anomaly)
    
    severity = "Low"
    if any("Critical" in r or "Over-voltage" in r or "Severe" in r for r in rule_reasons) or (iso_is_anomaly and len(rule_reasons) > 0):
        severity = "High"
    elif len(rule_reasons) > 0 or iso_is_anomaly:
        severity = "Medium"

    return {
        "is_anomaly": is_anomaly,
        "severity": severity if is_anomaly else "Normal",
        "detection_method": "IsolationForest+Thresholds" if iso_is_anomaly and rule_reasons else ("Threshold" if rule_reasons else ("IsolationForest" if iso_is_anomaly else "None")),
        "reasons": rule_reasons if rule_reasons else (["Statistical anomaly identified by Isolation Forest model."] if iso_is_anomaly else ["All telemetry parameters within normal operational baseline."]),
        "anomaly_score": iso_score
    }

if __name__ == "__main__":
    import sys
    print("Testing ML Range Predictor & Anomaly Detector...")
    sample_pred = predict_ev_range(75.0, 80.0, 95.0, 24.0, 65.0, 75.0, 16.5, "flat")
    print("Range Prediction Sample:", sample_pred)
    sample_anomaly = detect_telemetry_anomaly(385.0, -35.0, 28.0, 80.0, 16.5)
    print("Normal Telemetry Test:", sample_anomaly)
    abnormal_anomaly = detect_telemetry_anomaly(435.0, -290.0, 48.0, 80.0, 29.0)
    print("Abnormal Telemetry Test:", abnormal_anomaly)
