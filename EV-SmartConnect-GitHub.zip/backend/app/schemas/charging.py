from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class ChargingStationCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=160)
    operator: Optional[str] = "Independent"
    address: str = Field(..., min_length=5)
    latitude: float
    longitude: float
    connector_types: str = Field(..., description="e.g. CCS2, Type 2, CHAdeMO")
    charging_speed: float = Field(..., gt=0.0, description="kW")
    total_ports: int = Field(default=4, ge=1)
    available_ports: int = Field(default=2, ge=0)
    price_per_kwh: float = Field(default=15.0, ge=0.0)
    is_simulated_availability: bool = True

class ChargingStationResponse(BaseModel):
    id: int
    name: str
    operator: str
    address: str
    latitude: float
    longitude: float
    connector_types: str
    charging_speed: float
    total_ports: int
    available_ports: int
    price_per_kwh: float
    is_simulated_availability: bool
    is_active: bool
    created_at: datetime
    distance_km: Optional[float] = None

    class Config:
        from_attributes = True

class ChargingSessionCreate(BaseModel):
    vehicle_id: int
    station_id: int
    start_soc: float
    end_soc: Optional[float] = None
    energy_consumed: Optional[float] = 0.0
    total_cost: Optional[float] = 0.0

class ChargingSessionResponse(BaseModel):
    id: int
    vehicle_id: int
    station_id: int
    start_time: datetime
    end_time: Optional[datetime]
    start_soc: float
    end_soc: Optional[float]
    energy_consumed: float
    total_cost: float
    status: str
    station_name: Optional[str] = None

    class Config:
        from_attributes = True

class ChargingRecommendationRequest(BaseModel):
    vehicle_id: int
    destination_name: str
    destination_distance_km: float
    preferred_speed_kw: Optional[float] = None

class ChargingRecommendationResponse(BaseModel):
    is_charging_needed: bool
    recommendation_text: str
    current_soc: float
    predicted_range_km: float
    destination_distance_km: float
    shortfall_km: float
    estimated_kwh_needed: float
    estimated_charge_minutes: int
    suggested_stations: list[ChargingStationResponse]
