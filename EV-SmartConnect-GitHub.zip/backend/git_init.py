import os
from dulwich import porcelain

REPO_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

def init_and_commit():
    git_dir = os.path.join(REPO_PATH, ".git")
    if not os.path.exists(git_dir):
        print(f"Initializing Git repository at {REPO_PATH}...")
        repo = porcelain.init(REPO_PATH)
    else:
        print(f"Git repository already exists at {REPO_PATH}.")
        repo = porcelain.open_repo(REPO_PATH)

    print("Staging all files...")
    porcelain.add(REPO_PATH)

    print("Creating initial commit...")
    try:
        commit_id = porcelain.commit(
            REPO_PATH,
            message="feat: AI-powered EV SmartConnect with India EV ecosystem catalog, ML range prediction, and telemetry safeguards",
            author="EV SmartConnect Engineer <engineer@evsmartconnect.io>",
            committer="EV SmartConnect Engineer <engineer@evsmartconnect.io>"
        )
        print(f"Committed successfully! Commit SHA: {commit_id.decode() if isinstance(commit_id, bytes) else commit_id}")
    except Exception as e:
        print(f"Commit note: {e}")

if __name__ == "__main__":
    init_and_commit()
