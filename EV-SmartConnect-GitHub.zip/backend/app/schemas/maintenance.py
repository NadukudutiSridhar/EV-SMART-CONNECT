from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class MaintenanceAlertCreate(BaseModel):
    vehicle_id: int
    alert_type: str = Field(..., description="Temperature, Voltage, Current, SOH_Degradation, Consumption")
    severity: str = Field(default="Medium", description="Low, Medium, High")
    description: str
    recommended_action: str
    sensor_value: Optional[float] = None
    threshold_value: Optional[float] = None
    detection_method: Optional[str] = "Threshold"

class MaintenanceAlertUpdate(BaseModel):
    is_resolved: bool
    recommended_action: Optional[str] = None

class MaintenanceAlertResponse(BaseModel):
    id: int
    vehicle_id: int
    alert_type: str
    severity: str
    description: str
    recommended_action: str
    sensor_value: Optional[float]
    threshold_value: Optional[float]
    detection_method: str
    is_resolved: bool
    resolved_at: Optional[datetime]
    created_at: datetime
    vehicle_name: Optional[str] = None

    class Config:
        from_attributes = True
