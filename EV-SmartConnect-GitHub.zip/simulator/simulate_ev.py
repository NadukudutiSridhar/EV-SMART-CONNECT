"""
EV SmartConnect - Simulated EV Sensor Data Generator (Module 4)
Generates realistic, physics-consistent EV sensor readings for normal driving,
charging, high-speed highway cruising, and anomalous safety conditions.
"""

import os
import sys
import time
import json
import random
import argparse
from datetime import datetime, timezone
import requests
import pandas as pd

API_ENDPOINT = "http://127.0.0.1:8000/api/battery/readings"
DEFAULT_CSV_PATH = os.path.join(os.path.dirname(__file__), "simulated_telemetry_sample.csv")

class EVSimulator:
    def __init__(
        self,
        vehicle_id: int = 1,
        battery_capacity_kwh: float = 75.0,
        initial_soc: float = 85.0,
        initial_soh: float = 98.0,
        mode: str = "driving" # 'driving', 'charging', 'fast_charging', 'idle', 'anomaly'
    ):
        self.vehicle_id = vehicle_id
        self.battery_capacity = battery_capacity_kwh
        self.soc = initial_soc
        self.soh = initial_soh
        self.mode = mode
        self.temperature = 26.5 # Celsius
        self.odometer = 1250.0 # km
        self.nominal_voltage = 390.0 # Volts

    def step(self, delta_seconds: float = 5.0) -> dict:
        """
        Calculates one telemetry step based on the current vehicle mode.
        """
        timestamp = datetime.now(timezone.utc).isoformat()

        if self.mode == "driving":
            # Realistic urban/highway mixed speed
            speed = random.uniform(35.0, 95.0)
            self.odometer += (speed * (delta_seconds / 3600.0))
            
            # Aerodynamic & load power draw
            # Current = negative during discharge (A)
            # Higher speed = higher current draw
            current = -1 * (15.0 + (speed / 100.0) ** 1.8 * 65.0 + random.uniform(-3, 3))
            
            # Voltage sags slightly under load: V = V_ocv - I * R_internal
            voltage = self.nominal_voltage * (0.85 + 0.15 * (self.soc / 100.0)) + (current * 0.05)
            
            # Temperature rises gradually with high current draw
            self.temperature += abs(current) * 0.0008 * (delta_seconds / 5.0)
            self.temperature = min(42.0, max(24.0, self.temperature))

            # Energy consumption in kWh/100km
            consumption = 14.5 + (speed / 100.0) ** 2 * 9.0 + random.uniform(-0.5, 0.5)

            # SOC decrement: delta_kWh = power(kW) * time(h)
            power_kw = (voltage * abs(current)) / 1000.0
            kwh_used = power_kw * (delta_seconds / 3600.0)
            self.soc = max(1.0, self.soc - (kwh_used / self.battery_capacity) * 100.0)

            status = "discharging"
            is_anomaly = False

        elif self.mode == "charging":
            speed = 0.0
            # AC Level 2 charging (~11 kW, ~28 A, positive current)
            current = random.uniform(26.0, 30.0)
            voltage = 395.0 + (self.soc / 100.0) * 15.0
            power_kw = (voltage * current) / 1000.0
            kwh_added = power_kw * (delta_seconds / 3600.0)
            self.soc = min(100.0, self.soc + (kwh_added / self.battery_capacity) * 100.0)
            self.temperature = max(25.0, min(33.0, self.temperature + 0.02))
            consumption = 0.0
            status = "charging"
            is_anomaly = False

        elif self.mode == "fast_charging":
            speed = 0.0
            # DC Fast Charging (~120 kW, ~280 A)
            current = random.uniform(180.0, 240.0)
            voltage = 405.0 + (self.soc / 100.0) * 15.0
            power_kw = (voltage * current) / 1000.0
            kwh_added = power_kw * (delta_seconds / 3600.0)
            self.soc = min(100.0, self.soc + (kwh_added / self.battery_capacity) * 100.0)
            self.temperature = min(44.0, self.temperature + 0.15)
            consumption = 0.0
            status = "fast_charging"
            is_anomaly = False

        elif self.mode == "anomaly":
            # Simulate critical temperature or severe cell voltage sag anomaly
            anomaly_type = random.choice(["overheating", "voltage_sag", "overvoltage"])
            speed = random.uniform(40.0, 80.0)
            self.odometer += (speed * (delta_seconds / 3600.0))
            
            if anomaly_type == "overheating":
                self.temperature = round(random.uniform(48.5, 54.0), 1) # Critical > 45 C
                current = -95.0
                voltage = 380.0
            elif anomaly_type == "voltage_sag":
                self.temperature = 34.0
                current = -80.0
                voltage = round(random.uniform(295.0, 310.0), 1) # Severe sag < 320V
            else: # overvoltage
                self.temperature = 31.0
                current = 45.0
                voltage = round(random.uniform(435.0, 448.0), 1) # Overvoltage > 430V

            consumption = 28.5
            self.soc = max(5.0, self.soc - 0.2)
            status = "discharging" if current < 0 else "charging"
            is_anomaly = True

        else: # idle
            speed = 0.0
            current = -0.5 # parasitic drain
            voltage = 388.0
            consumption = 0.0
            status = "idle"
            is_anomaly = False

        return {
            "vehicle_id": self.vehicle_id,
            "soc": round(self.soc, 2),
            "soh": round(self.soh, 2),
            "voltage": round(voltage, 2),
            "current": round(current, 2),
            "temperature": round(self.temperature, 2),
            "vehicle_speed": round(speed, 1),
            "energy_consumption": round(consumption, 2),
            "distance_travelled": round(self.odometer, 2),
            "charging_status": status,
            "is_simulated": True,
            "is_anomaly": is_anomaly,
            "timestamp": timestamp
        }

def generate_sample_csv(num_samples: int = 100, output_path: str = DEFAULT_CSV_PATH):
    """Generates a sample CSV file of simulated EV sensor telemetry."""
    print(f"Generating {num_samples} simulated EV telemetry samples to {output_path}...")
    sim = EVSimulator(vehicle_id=1, initial_soc=90.0, mode="driving")
    records = []

    for i in range(num_samples):
        # Switch modes to produce a realistic mix: 70% driving, 20% charging, 10% anomalies
        rand = random.random()
        if rand < 0.65:
            sim.mode = "driving"
        elif rand < 0.85:
            sim.mode = "charging"
        elif rand < 0.95:
            sim.mode = "idle"
        else:
            sim.mode = "anomaly"

        record = sim.step(delta_seconds=10.0)
        records.append(record)

    df = pd.DataFrame(records)
    df.to_csv(output_path, index=False)
    print(f"Sample telemetry CSV saved successfully ({len(df)} rows).")

def run_live_simulation(
    vehicle_id: int = 1,
    interval_seconds: float = 3.0,
    iterations: int = 20,
    api_url: str = API_ENDPOINT,
    inject_anomaly_every: int = 8
):
    """Streams simulated EV telemetry to the backend API at configurable intervals."""
    print(f"Starting EV Telemetry Simulation for Vehicle #{vehicle_id}...")
    print(f"Target API: {api_url} | Interval: {interval_seconds}s | Steps: {iterations}")
    
    sim = EVSimulator(vehicle_id=vehicle_id, initial_soc=88.0, mode="driving")

    for i in range(1, iterations + 1):
        if i % inject_anomaly_every == 0:
            sim.mode = "anomaly"
            print(f"\n[!] INJECTING SIMULATED SENSOR ANOMALY AT STEP #{i}...")
        else:
            sim.mode = "driving"

        telemetry = sim.step(delta_seconds=interval_seconds)

        try:
            resp = requests.post(api_url, json=telemetry, timeout=4)
            if resp.status_code in [200, 201]:
                print(f"[Step {i}/{iterations}] Sent -> SOC: {telemetry['soc']}% | "
                      f"Temp: {telemetry['temperature']}°C | Volt: {telemetry['voltage']}V | "
                      f"Status: {telemetry['charging_status']} | Anomaly: {telemetry['is_anomaly']} [SUCCESS]")
            else:
                print(f"[Step {i}] API returned status {resp.status_code}: {resp.text}")
        except requests.exceptions.RequestException as e:
            print(f"[Step {i}] Could not connect to API ({e}). Run backend first! Telemetry: {telemetry}")

        time.sleep(interval_seconds)

    print("\nSimulation completed.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="EV SmartConnect Sensor Telemetry Simulator")
    parser.add_argument("--csv", action="store_true", help="Generate sample CSV dataset")
    parser.add_argument("--samples", type=int, default=150, help="Number of CSV samples")
    parser.add_argument("--stream", action="store_true", help="Stream live telemetry to backend API")
    parser.add_argument("--vehicle-id", type=int, default=1, help="Target vehicle ID")
    parser.add_argument("--interval", type=float, default=2.5, help="Interval in seconds")
    parser.add_argument("--steps", type=int, default=15, help="Number of steps for live stream")
    args = parser.parse_args()

    if args.csv or len(sys.argv) == 1:
        generate_sample_csv(num_samples=args.samples)
    
    if args.stream:
        run_live_simulation(vehicle_id=args.vehicle_id, interval_seconds=args.interval, iterations=args.steps)
