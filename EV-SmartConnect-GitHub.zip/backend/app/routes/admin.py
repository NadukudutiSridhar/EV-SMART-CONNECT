from datetime import datetime, date, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.vehicle import Vehicle
from backend.app.models.battery import BatteryReading
from backend.app.models.charging import ChargingStation, ChargingSession
from backend.app.models.maintenance import MaintenanceAlert
from backend.app.models.trip import TripRecord
from backend.app.schemas.auth import UserResponse
from backend.app.security.auth import require_admin, hash_password
from backend.app.security.middleware import audit_log

router = APIRouter(prefix="/api/admin", tags=["Admin Dashboard"])

@router.get("/users", response_model=List[UserResponse])
def get_all_users(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return db.query(User).order_by(User.created_at.desc()).all()

@router.put("/users/{user_id}/status")
def toggle_user_status(user_id: int, is_active: bool, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.id == admin.id:
        raise HTTPException(status_code=400, detail="Cannot deactivate your own administrator account")
    user.is_active = is_active
    db.commit()
    audit_log("ADMIN_USER_STATUS_CHANGE", admin.email, f"Target: {user.email}, is_active: {is_active}")
    return {"message": f"User status updated to {'active' if is_active else 'deactivated'}"}

@router.put("/users/{user_id}/role")
def change_user_role(user_id: int, role: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    if role not in ["user", "admin"]:
        raise HTTPException(status_code=400, detail="Invalid role. Must be 'user' or 'admin'.")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = role
    db.commit()
    audit_log("ADMIN_ROLE_CHANGE", admin.email, f"Target: {user.email}, new role: {role}")
    return {"message": f"User role updated to {role}"}

@router.get("/stats")
def get_admin_system_stats(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return {
        "total_users": db.query(User).count(),
        "total_vehicles": db.query(Vehicle).count(),
        "total_battery_readings": db.query(BatteryReading).count(),
        "total_charging_stations": db.query(ChargingStation).count(),
        "total_charging_sessions": db.query(ChargingSession).count(),
        "unresolved_alerts": db.query(MaintenanceAlert).filter(MaintenanceAlert.is_resolved == False).count(),
        "total_trips": db.query(TripRecord).count()
    }

@router.post("/seed")
def seed_database_demo_data(db: Session = Depends(get_db)):
    """Seeds rich, realistic initial demonstration data for evaluation."""
    # Check if already seeded
    if db.query(User).count() > 0:
        return {"message": "Database already contains users. Skipping demo seed."}

    # 1. Create Admin & Demo Users
    admin_user = User(
        name="Admin Engineer",
        email="admin@evsmartconnect.io",
        password_hash=hash_password("Admin@123456"),
        role="admin",
        phone="+91 98765 43210",
        is_active=True
    )
    demo_user = User(
        name="Alex Driver",
        email="driver@evsmartconnect.io",
        password_hash=hash_password("Driver@123456"),
        role="user",
        phone="+91 98765 12345",
        is_active=True
    )
    db.add_all([admin_user, demo_user])
    db.commit()
    db.refresh(admin_user)
    db.refresh(demo_user)

    # 2. Create Indian EV Fleet Models
    v1 = Vehicle(
        user_id=demo_user.id,
        model="Curvv EV (Empowered+)",
        make="Tata",
        registration_number="KA-01-EV-2026",
        vin="MAT622026EXP00123",
        battery_capacity=55.0,
        vehicle_type="SUV Coupe",
        manufacturing_year=2025,
        firmware_version="v4.0.1"
    )
    v2 = Vehicle(
        user_id=demo_user.id,
        model="BE 6e",
        make="Mahindra",
        registration_number="MH-02-EV-6600",
        vin="MA16BE6E2025EXP089",
        battery_capacity=79.0,
        vehicle_type="SUV Coupe",
        manufacturing_year=2025,
        firmware_version="v1.0.4"
    )
    v3 = Vehicle(
        user_id=demo_user.id,
        model="Windsor EV (Essence)",
        make="MG",
        registration_number="DL-01-EV-3344",
        vin="MGWIND2024EXP00456",
        battery_capacity=38.0,
        vehicle_type="CUV",
        manufacturing_year=2024,
        firmware_version="v1.4.0"
    )
    v4 = Vehicle(
        user_id=demo_user.id,
        model="Nexon EV Long Range",
        make="Tata",
        registration_number="KA-05-EV-9988",
        vin="MAT582024EXP09988",
        battery_capacity=40.5,
        vehicle_type="SUV",
        manufacturing_year=2024,
        firmware_version="v3.1.2"
    )
    v5 = Vehicle(
        user_id=demo_user.id,
        model="Seal (Performance AWD)",
        make="BYD",
        registration_number="TS-07-EV-1122",
        vin="BYDSEAL2024EXP01122",
        battery_capacity=82.56,
        vehicle_type="Sedan",
        manufacturing_year=2024,
        firmware_version="v3.2.0"
    )
    db.add_all([v1, v2, v3, v4, v5])
    db.commit()
    db.refresh(v1)
    db.refresh(v2)
    db.refresh(v3)
    db.refresh(v4)
    db.refresh(v5)

    # 3. Create Sample Charging Stations
    stations = [
        ChargingStation(
            name="Tata Power EZ Charge - Indiranagar",
            operator="Tata Power",
            address="100 Feet Rd, HAL 2nd Stage, Indiranagar, Bengaluru, Karnataka 560038",
            latitude=12.9784,
            longitude=77.6408,
            connector_types="CCS2, Type 2",
            charging_speed=60.0,
            total_ports=6,
            available_ports=3,
            price_per_kwh=16.5,
            is_simulated_availability=True
        ),
        ChargingStation(
            name="Jio-bp pulse EV Fast Hub - Koramangala",
            operator="Jio-bp",
            address="80 Feet Rd, 4th Block, Koramangala, Bengaluru, Karnataka 560034",
            latitude=12.9345,
            longitude=77.6245,
            connector_types="CCS2, CHAdeMO, Type 2",
            charging_speed=120.0,
            total_ports=8,
            available_ports=4,
            price_per_kwh=18.0,
            is_simulated_availability=True
        ),
        ChargingStation(
            name="Ather Grid - MG Road Metro",
            operator="Ather Energy",
            address="MG Road Metro Station, Shivaji Nagar, Bengaluru, Karnataka 560001",
            latitude=12.9756,
            longitude=77.6066,
            connector_types="Type 2, Bharat AC-001",
            charging_speed=22.0,
            total_ports=4,
            available_ports=2,
            price_per_kwh=12.0,
            is_simulated_availability=True
        ),
        ChargingStation(
            name="Zeon Fast Charging Hub - Electronic City",
            operator="Zeon Electric",
            address="Hosur Rd, Phase 1, Electronic City, Bengaluru, Karnataka 560100",
            latitude=12.8399,
            longitude=77.6770,
            connector_types="CCS2, Type 2",
            charging_speed=150.0,
            total_ports=6,
            available_ports=5,
            price_per_kwh=19.5,
            is_simulated_availability=True
        ),
        ChargingStation(
            name="Static EV Supercharger - Whitefield",
            operator="Static Power",
            address="ITPL Main Rd, KIADB Export Promotion Industrial Area, Whitefield, Bengaluru 560066",
            latitude=12.9863,
            longitude=77.7338,
            connector_types="CCS2",
            charging_speed=120.0,
            total_ports=4,
            available_ports=1,
            price_per_kwh=17.5,
            is_simulated_availability=True
        )
    ]
    db.add_all(stations)
    db.commit()

    # 4. Create Recent Battery Readings for v2
    now = datetime.now()
    readings = []
    soc_vals = [85.0, 84.2, 83.1, 81.8, 80.5, 79.2, 78.0, 76.5, 75.0, 74.2, 72.8, 71.5]
    for i, s in enumerate(reversed(soc_vals)):
        readings.append(BatteryReading(
            vehicle_id=v2.id,
            soc=s,
            soh=96.5,
            voltage=392.0 - (85.0 - s) * 0.4,
            current=-32.5,
            temperature=27.4 + (i * 0.2),
            vehicle_speed=55.0 + (i % 4) * 5,
            energy_consumption=16.2 + (i % 3) * 0.4,
            distance_travelled=1240.0 + (i * 4.2),
            charging_status="discharging",
            is_simulated=True,
            is_anomaly=False,
            timestamp=now - timedelta(minutes=(12 - i) * 5)
        ))
    db.add_all(readings)

    # 5. Create Sample Maintenance Alert
    alert = MaintenanceAlert(
        vehicle_id=v2.id,
        alert_type="Temperature",
        severity="Medium",
        description="Battery pack temperature reached 38.8°C during high-speed uphill acceleration.",
        recommended_action="Inspect coolant pump circulation flow rate during next scheduled service.",
        sensor_value=38.8,
        threshold_value=45.0,
        detection_method="Threshold",
        is_resolved=False,
        created_at=now - timedelta(hours=3)
    )
    db.add(alert)

    # 6. Create Historical Trips
    today = date.today()
    sample_trips = [
        TripRecord(
            vehicle_id=v2.id,
            start_location="Koramangala, Bengaluru",
            destination="Whitefield Tech Park",
            distance=22.5,
            duration_minutes=42,
            average_speed=32.1,
            energy_consumed=3.7,
            efficiency=16.4,
            start_soc=90.0,
            end_soc=85.0,
            trip_date=today - timedelta(days=1)
        ),
        TripRecord(
            vehicle_id=v2.id,
            start_location="Indiranagar",
            destination="Kempegowda International Airport",
            distance=38.4,
            duration_minutes=50,
            average_speed=46.0,
            energy_consumed=6.4,
            efficiency=16.6,
            start_soc=95.0,
            end_soc=86.5,
            trip_date=today - timedelta(days=2)
        ),
        TripRecord(
            vehicle_id=v2.id,
            start_location="Whitefield",
            destination="Electronic City Phase 1",
            distance=31.2,
            duration_minutes=48,
            average_speed=39.0,
            energy_consumed=5.2,
            efficiency=16.6,
            start_soc=86.5,
            end_soc=79.5,
            trip_date=today - timedelta(days=3)
        )
    ]
    db.add_all(sample_trips)
    db.commit()

    return {
        "message": "Demo data successfully seeded!",
        "admin_credentials": {"email": "admin@evsmartconnect.io", "password": "Admin@123456"},
        "user_credentials": {"email": "driver@evsmartconnect.io", "password": "Driver@123456"}
    }
