import os
from backend.app.database import SessionLocal
from backend.app.models.charging import ChargingStation

db = SessionLocal()

INDIAN_CHARGING_STATIONS = [
    # BENGALURU
    {
        "name": "Tata Power EZ Charge - Indiranagar",
        "operator": "Tata Power",
        "address": "100 Feet Rd, HAL 2nd Stage, Indiranagar, Bengaluru, Karnataka 560038",
        "latitude": 12.9784,
        "longitude": 77.6408,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 6,
        "available_ports": 3,
        "price_per_kwh": 16.5,
    },
    {
        "name": "Jio-bp pulse EV Fast Hub - Koramangala",
        "operator": "Jio-bp",
        "address": "80 Feet Rd, 4th Block, Koramangala, Bengaluru, Karnataka 560034",
        "latitude": 12.9345,
        "longitude": 77.6245,
        "connector_types": "CCS2, CHAdeMO, Type 2",
        "charging_speed": 120.0,
        "total_ports": 8,
        "available_ports": 4,
        "price_per_kwh": 18.0,
    },
    {
        "name": "Statiq EV Supercharger - Whitefield",
        "operator": "Statiq",
        "address": "ITPL Main Rd, KIADB Export Promotion Area, Whitefield, Bengaluru 560066",
        "latitude": 12.9863,
        "longitude": 77.7338,
        "connector_types": "CCS2",
        "charging_speed": 150.0,
        "total_ports": 6,
        "available_ports": 2,
        "price_per_kwh": 17.5,
    },
    {
        "name": "Zeon Fast Charging - Electronic City Phase 1",
        "operator": "Zeon Electric",
        "address": "Hosur Rd, Electronic City, Bengaluru, Karnataka 560100",
        "latitude": 12.8399,
        "longitude": 77.6770,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 120.0,
        "total_ports": 6,
        "available_ports": 5,
        "price_per_kwh": 19.0,
    },

    # DELHI NCR
    {
        "name": "Tata Power EZ Charge - Connaught Place",
        "operator": "Tata Power",
        "address": "Outer Circle, Block C, Connaught Place, New Delhi, Delhi 110001",
        "latitude": 28.6315,
        "longitude": 77.2167,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 6,
        "available_ports": 4,
        "price_per_kwh": 17.0,
    },
    {
        "name": "Jio-bp pulse - Aerocity Delhi",
        "operator": "Jio-bp",
        "address": "Hospitality District, Asset 5B, Aerocity, New Delhi, Delhi 110037",
        "latitude": 28.5505,
        "longitude": 77.1218,
        "connector_types": "CCS2, CHAdeMO",
        "charging_speed": 150.0,
        "total_ports": 10,
        "available_ports": 6,
        "price_per_kwh": 18.5,
    },
    {
        "name": "Statiq EV Charging Hub - Cyber City Gurugram",
        "operator": "Statiq",
        "address": "DLF Cyber City, Building 10, Sector 24, Gurugram, Haryana 122002",
        "latitude": 28.4952,
        "longitude": 77.0891,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 120.0,
        "total_ports": 8,
        "available_ports": 5,
        "price_per_kwh": 18.0,
    },
    {
        "name": "ChargeZone Superfast Hub - Noida Sector 18",
        "operator": "ChargeZone",
        "address": "Atta Market, Sector 18, Noida, Uttar Pradesh 201301",
        "latitude": 28.5708,
        "longitude": 77.3261,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 6,
        "available_ports": 3,
        "price_per_kwh": 16.5,
    },

    # MUMBAI
    {
        "name": "Tata Power EZ Charge - Bandra Kurla Complex (BKC)",
        "operator": "Tata Power",
        "address": "G Block, Bandra Kurla Complex, Bandra East, Mumbai, Maharashtra 400051",
        "latitude": 19.0657,
        "longitude": 72.8687,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 8,
        "available_ports": 5,
        "price_per_kwh": 17.5,
    },
    {
        "name": "Jio-bp pulse Fast Hub - Andheri West",
        "operator": "Jio-bp",
        "address": "New Link Rd, Oshiwara, Andheri West, Mumbai, Maharashtra 400053",
        "latitude": 19.1432,
        "longitude": 72.8317,
        "connector_types": "CCS2, CHAdeMO",
        "charging_speed": 120.0,
        "total_ports": 6,
        "available_ports": 2,
        "price_per_kwh": 18.5,
    },
    {
        "name": "Shell Recharge - Navi Mumbai Palm Beach Rd",
        "operator": "Shell",
        "address": "Palm Beach Rd, Sector 19D, Vashi, Navi Mumbai, Maharashtra 400703",
        "latitude": 19.0760,
        "longitude": 73.0039,
        "connector_types": "CCS2",
        "charging_speed": 150.0,
        "total_ports": 4,
        "available_ports": 3,
        "price_per_kwh": 19.5,
    },

    # HYDERABAD
    {
        "name": "Tata Power EZ Charge - HITEC City",
        "operator": "Tata Power",
        "address": "Cyber Towers, Hitech City, Madhapur, Hyderabad, Telangana 500081",
        "latitude": 17.4504,
        "longitude": 78.3808,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 8,
        "available_ports": 6,
        "price_per_kwh": 16.0,
    },
    {
        "name": "Zeon Electric Fast Hub - Gachibowli",
        "operator": "Zeon Electric",
        "address": "Financial District, Nanakramguda, Gachibowli, Hyderabad, Telangana 500032",
        "latitude": 17.4239,
        "longitude": 78.3498,
        "connector_types": "CCS2",
        "charging_speed": 120.0,
        "total_ports": 6,
        "available_ports": 3,
        "price_per_kwh": 17.5,
    },

    # CHENNAI
    {
        "name": "Tata Power EZ Charge - T. Nagar",
        "operator": "Tata Power",
        "address": "Gopathi Narayanaswami Chetty Rd, T. Nagar, Chennai, Tamil Nadu 600017",
        "latitude": 13.0418,
        "longitude": 80.2341,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 6,
        "available_ports": 4,
        "price_per_kwh": 16.5,
    },
    {
        "name": "ChargeZone Fast Hub - OMR IT Corridor",
        "operator": "ChargeZone",
        "address": "Rajiv Gandhi Salai (OMR), Sholinganallur, Chennai, Tamil Nadu 600119",
        "latitude": 12.9010,
        "longitude": 80.2279,
        "connector_types": "CCS2",
        "charging_speed": 120.0,
        "total_ports": 6,
        "available_ports": 2,
        "price_per_kwh": 18.0,
    },

    # PUNE
    {
        "name": "Tata Power EZ Charge - Hinjawadi IT Park",
        "operator": "Tata Power",
        "address": "Phase 1, Hinjawadi Rajiv Gandhi Infotech Park, Pune, Maharashtra 411057",
        "latitude": 18.5913,
        "longitude": 73.7389,
        "connector_types": "CCS2, Type 2",
        "charging_speed": 60.0,
        "total_ports": 6,
        "available_ports": 3,
        "price_per_kwh": 16.5,
    },
    {
        "name": "Statiq Supercharger - Koregaon Park",
        "operator": "Statiq",
        "address": "North Main Rd, Koregaon Park, Pune, Maharashtra 411001",
        "latitude": 18.5362,
        "longitude": 73.8940,
        "connector_types": "CCS2, CHAdeMO",
        "charging_speed": 120.0,
        "total_ports": 4,
        "available_ports": 2,
        "price_per_kwh": 17.5,
    }
]

added_count = 0
for s in INDIAN_CHARGING_STATIONS:
    existing = db.query(ChargingStation).filter(ChargingStation.name == s["name"]).first()
    if not existing:
        station = ChargingStation(
            name=s["name"],
            operator=s["operator"],
            address=s["address"],
            latitude=s["latitude"],
            longitude=s["longitude"],
            connector_types=s["connector_types"],
            charging_speed=s["charging_speed"],
            total_ports=s["total_ports"],
            available_ports=s["available_ports"],
            price_per_kwh=s["price_per_kwh"],
            is_simulated_availability=True,
            is_active=True
        )
        db.add(station)
        added_count += 1

db.commit()
print(f"Added {added_count} new charging stations across India! Total in DB: {db.query(ChargingStation).count()}")
db.close()
