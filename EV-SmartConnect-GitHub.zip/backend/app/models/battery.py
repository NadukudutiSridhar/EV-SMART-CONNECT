from sqlalchemy import Column, Integer, BigInteger, Float, Boolean, String, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from backend.app.database import Base

class BatteryReading(Base):
    __tablename__ = "battery_readings"

    id = Column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True, index=True, autoincrement=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    soc = Column(Float, nullable=False) # % (0-100)
    soh = Column(Float, nullable=False) # % (0-100)
    voltage = Column(Float, nullable=False) # Volts
    current = Column(Float, nullable=False) # Amperes (- discharge, + charge)
    temperature = Column(Float, nullable=False) # Celsius
    vehicle_speed = Column(Float, default=0.0, nullable=False) # km/h
    energy_consumption = Column(Float, default=0.0, nullable=False) # kWh/100km
    distance_travelled = Column(Float, default=0.0, nullable=False) # km
    charging_status = Column(String(50), default="idle", nullable=False) # 'discharging', 'charging', 'idle', 'fast_charging'
    is_simulated = Column(Boolean, default=True, nullable=False)
    is_anomaly = Column(Boolean, default=False, nullable=False)
    timestamp = Column(DateTime, server_default=func.now(), nullable=False, index=True)

    vehicle = relationship("Vehicle", back_populates="battery_readings")
