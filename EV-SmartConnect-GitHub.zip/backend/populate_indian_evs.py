from backend.app.database import SessionLocal
from backend.app.models.user import User
from backend.app.models.vehicle import Vehicle

db = SessionLocal()
users = db.query(User).all()

indian_models = [
    {'make': 'Tata', 'model': 'Curvv EV (Empowered+)', 'reg': 'KA-01-EV-2026', 'cap': 55.0, 'type': 'SUV Coupe', 'year': 2025},
    {'make': 'Mahindra', 'model': 'BE 6e', 'reg': 'MH-02-EV-6600', 'cap': 79.0, 'type': 'SUV Coupe', 'year': 2025},
    {'make': 'MG', 'model': 'Windsor EV (Essence)', 'reg': 'DL-01-EV-3344', 'cap': 38.0, 'type': 'CUV', 'year': 2024},
    {'make': 'Tata', 'model': 'Punch EV (Long Range)', 'reg': 'TN-07-EV-1922', 'cap': 35.0, 'type': 'Compact SUV', 'year': 2024},
    {'make': 'BYD', 'model': 'Seal (Performance AWD)', 'reg': 'TS-07-EV-1122', 'cap': 82.56, 'type': 'Sedan', 'year': 2024},
    {'make': 'Hyundai', 'model': 'Ioniq 5', 'reg': 'GJ-01-EV-8080', 'cap': 72.6, 'type': 'Crossover', 'year': 2024},
    {'make': 'Kia', 'model': 'EV6 (GT-Line AWD)', 'reg': 'DL-03-EV-7788', 'cap': 77.4, 'type': 'Crossover', 'year': 2024},
    {'make': 'Citroën', 'model': 'ë-C3 (Shine)', 'reg': 'KL-07-EV-3011', 'cap': 29.2, 'type': 'Hatchback', 'year': 2024}
]

count = 0
for u in users:
    for idx, m in enumerate(indian_models):
        exists = db.query(Vehicle).filter(Vehicle.user_id == u.id, Vehicle.model == m['model']).first()
        if not exists:
            plate = f"{m['reg'].split('-')[0]}-{m['reg'].split('-')[1]}-EV-{u.id * 1000 + idx + 100}"
            v = Vehicle(
                user_id=u.id,
                make=m['make'],
                model=m['model'],
                registration_number=plate,
                vin=f"IN{m['make'][:3].upper()}{u.id}{idx}99234",
                battery_capacity=m['cap'],
                vehicle_type=m['type'],
                manufacturing_year=m['year'],
                firmware_version='v3.1.0'
            )
            db.add(v)
            count += 1

db.commit()
print(f"Successfully added {count} Indian EV models! Total vehicles in database: {db.query(Vehicle).count()}")
db.close()
