import math
from sqlalchemy.orm import Session
from sqlalchemy import desc

from backend.app.models.charging import ChargingStation, ChargingSession
from backend.app.models.vehicle import Vehicle
from backend.app.models.battery import BatteryReading
from backend.app.schemas.charging import ChargingRecommendationRequest, ChargingStationResponse
from ml.predict import predict_ev_range

def calculate_haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculates great-circle distance between two GPS coordinates in kilometres."""
    R = 6371.0 # Earth's radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)

def get_stations_with_distance(lat: float, lon: float, db: Session, connector: str = None, min_speed: float = None):
    """Retrieves charging stations sorted by distance from the user coordinate."""
    query = db.query(ChargingStation).filter(ChargingStation.is_active == True)
    stations = query.all()

    station_list = []
    for s in stations:
        if connector and connector.lower() not in s.connector_types.lower():
            continue
        if min_speed and s.charging_speed < min_speed:
            continue

        dist = calculate_haversine_distance(lat, lon, s.latitude, s.longitude)
        resp = ChargingStationResponse.from_orm(s)
        resp.distance_km = dist
        station_list.append(resp)

    station_list.sort(key=lambda x: x.distance_km or 999999)
    return station_list

def generate_smart_charging_recommendation(req: ChargingRecommendationRequest, db: Session) -> dict:
    """
    Intelligent recommendation engine:
    Evaluates current battery SOC, remaining ML-predicted range, destination distance,
    energy shortfall, and locates appropriate charging stations.
    """
    vehicle = db.query(Vehicle).filter(Vehicle.id == req.vehicle_id).first()
    if not vehicle:
        raise ValueError(f"Vehicle {req.vehicle_id} not found")

    latest_reading = db.query(BatteryReading).filter(
        BatteryReading.vehicle_id == req.vehicle_id
    ).order_by(desc(BatteryReading.timestamp)).first()

    current_soc = latest_reading.soc if latest_reading else 50.0
    current_soh = latest_reading.soh if latest_reading else 95.0
    current_temp = latest_reading.temperature if latest_reading else 25.0
    nominal_consumption = latest_reading.energy_consumption if latest_reading else 16.5

    # Predict range
    pred_result = predict_ev_range(
        battery_capacity=vehicle.battery_capacity,
        soc=current_soc,
        soh=current_soh,
        temperature=current_temp,
        avg_speed=65.0,
        vehicle_load=80.0,
        energy_consumption=nominal_consumption,
        terrain="flat"
    )
    predicted_range = pred_result["predicted_range_km"]
    dest_dist = req.destination_distance_km

    # Reserve buffer: 15% safety buffer on range
    safety_buffer_km = dest_dist * 0.15
    needed_range = dest_dist + safety_buffer_km
    shortfall_km = max(0.0, round(needed_range - predicted_range, 1))
    is_charging_needed = bool(shortfall_km > 0.0 or current_soc < 20.0)

    # Estimate kWh needed to reach destination with 20% arrival SOC
    # Required energy = (dest_dist * (nominal_consumption / 100)) + buffer
    target_kwh = (dest_dist * (nominal_consumption / 100.0)) * 1.25
    available_kwh = vehicle.battery_capacity * (current_soc / 100.0) * (current_soh / 100.0)
    kwh_deficit = max(0.0, round(target_kwh - available_kwh, 1))

    # Fast charger estimate: assume 60kW avg speed
    fast_charge_kw = req.preferred_speed_kw or 50.0
    estimated_minutes = int(math.ceil((kwh_deficit / fast_charge_kw) * 60)) if is_charging_needed else 0

    if is_charging_needed:
        recommendation_text = (
            f"Your estimated driving range is {predicted_range} km, but your destination '{req.destination_name}' "
            f"is {dest_dist} km away (including safety reserve of {round(safety_buffer_km, 1)} km). "
            f"You have a projected shortfall of {shortfall_km} km. Consider charging approximately {kwh_deficit} kWh "
            f"(~{estimated_minutes} mins on a {fast_charge_kw} kW charger) before or en route."
        )
    else:
        recommendation_text = (
            f"Your estimated driving range is {predicted_range} km, which comfortably covers your {dest_dist} km trip "
            f"to '{req.destination_name}'. Estimated battery remaining upon arrival: "
            f"~{max(5, round(current_soc - (dest_dist / max(1, predicted_range)) * current_soc))}%."
        )

    # Find available stations
    # Use default user location (e.g. Bangalore/Hyderabad/Delhi area or first station lat/lng)
    default_lat, default_lon = 12.9716, 77.5946 # Default city center
    available_stations = get_stations_with_distance(default_lat, default_lon, db)[:5]

    return {
        "is_charging_needed": is_charging_needed,
        "recommendation_text": recommendation_text,
        "current_soc": current_soc,
        "predicted_range_km": predicted_range,
        "destination_distance_km": dest_dist,
        "shortfall_km": shortfall_km,
        "estimated_kwh_needed": kwh_deficit,
        "estimated_charge_minutes": estimated_minutes,
        "suggested_stations": available_stations
    }
