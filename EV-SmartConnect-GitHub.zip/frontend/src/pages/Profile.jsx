import React from 'react';
import { useAuth } from '../context/AuthContext';
import { User, Shield, Key, Car, Calendar, CheckCircle } from 'lucide-react';

const Profile = () => {
  const { user, vehicles, isAdmin } = useAuth();

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">User Profile & Account Security</h1>
        <p className="text-slate-500 text-xs mt-1">Manage user identity, security credentials, and fleet ownership</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
          <div className="w-16 h-16 rounded-2xl bg-slate-900 text-emerald-400 font-extrabold text-2xl flex items-center justify-center border-2 border-emerald-500/30 shadow-md">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">{user?.name}</h2>
            <p className="text-xs text-slate-500">{user?.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                isAdmin ? 'bg-purple-100 text-purple-800' : 'bg-emerald-100 text-emerald-800'
              }`}>
                {user?.role} Account
              </span>
              <span className="text-xs text-slate-400">• Active</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/60">
            <span className="text-slate-400 block mb-1 font-semibold uppercase text-[10px]">Email Verification</span>
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>{user?.email}</span>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/60">
            <span className="text-slate-400 block mb-1 font-semibold uppercase text-[10px]">Phone Number</span>
            <div className="font-bold text-slate-800">{user?.phone || 'Not configured'}</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/60">
            <span className="text-slate-400 block mb-1 font-semibold uppercase text-[10px]">Managed Vehicles</span>
            <div className="font-bold text-slate-800">{vehicles.length} Electric Vehicles Registered</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/60">
            <span className="text-slate-400 block mb-1 font-semibold uppercase text-[10px]">Password Security</span>
            <div className="font-bold text-slate-800">Argon2id Hasher Active</div>
          </div>
        </div>

        <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2 text-xs">
          <div className="font-bold text-emerald-400 flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Cybersecurity Architecture</span>
          </div>
          <p className="text-slate-400 leading-relaxed text-[11px]">
            Your session is secured using JSON Web Tokens (JWT) signed via HMAC-SHA256. Cross-user access control is enforced at the ORM layer to ensure absolute vehicle data isolation.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Profile;
