import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Car,
  BatteryCharging,
  Compass,
  MapPin,
  Zap,
  Wrench,
  History,
  BarChart3,
  User,
  ShieldAlert,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Bell,
  Search
} from 'lucide-react';

const DashboardLayout = () => {
  const { user, isAdmin, logout, vehicles, selectedVehicleId, setSelectedVehicleId } = useAuth();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isVehicleDropdownOpen, setIsVehicleDropdownOpen] = useState(false);

  const selectedVehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { name: 'Overview', to: '/', icon: LayoutDashboard },
    { name: 'My Vehicles', to: '/vehicles', icon: Car },
    { name: 'Battery Health', to: '/battery', icon: BatteryCharging },
    { name: 'Range Prediction', to: '/range-prediction', icon: Compass },
    { name: 'Charging Stations', to: '/stations', icon: MapPin },
    { name: 'Smart Charging', to: '/smart-charging', icon: Zap },
    { name: 'Maintenance', to: '/maintenance', icon: Wrench },
    { name: 'Trip History', to: '/trips', icon: History },
    { name: 'Analytics & Reports', to: '/analytics', icon: BarChart3 },
    { name: 'Profile', to: '/profile', icon: User },
  ];

  if (isAdmin) {
    navItems.push({ name: 'Admin Dashboard', to: '/admin', icon: ShieldAlert });
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-slate-900 border-r border-slate-800 text-slate-300 select-none">
        {/* Brand */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-800/80">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <Zap className="w-6 h-6 fill-white" />
          </div>
          <div>
            <h1 className="font-bold text-white text-lg tracking-tight flex items-center gap-1.5">
              EV SmartConnect
            </h1>
            <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
              AI Powered 2.0
            </span>
          </div>
        </div>

        {/* Vehicle Switcher Bar */}
        {vehicles.length > 0 && (
          <div className="px-4 py-3 border-b border-slate-800/60 bg-slate-950/40">
            <label className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-1">
              Active Vehicle
            </label>
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsVehicleDropdownOpen(!isVehicleDropdownOpen)}
                className="w-full flex items-center justify-between text-left px-3 py-2 bg-slate-800 hover:bg-slate-700/80 rounded-lg text-sm font-medium text-white transition-colors border border-slate-700"
              >
                <div className="truncate">
                  <div className="text-xs text-emerald-400 font-semibold">{selectedVehicle?.make}</div>
                  <div className="truncate">{selectedVehicle?.model} ({selectedVehicle?.registration_number})</div>
                </div>
                <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0 ml-1" />
              </button>

              {isVehicleDropdownOpen && (
                <div className="absolute left-0 right-0 top-full mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1 overflow-hidden">
                  {vehicles.map((v) => (
                    <button
                      key={v.id}
                      onClick={() => {
                        setSelectedVehicleId(v.id);
                        setIsVehicleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs flex flex-col transition-colors ${
                        selectedVehicleId === v.id ? 'bg-emerald-600/20 text-emerald-300 font-semibold' : 'text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <span className="font-medium text-white">{v.make} {v.model}</span>
                      <span className="text-[11px] text-slate-400">{v.registration_number} • {v.battery_capacity} kWh</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`
              }
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>

        {/* User Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm border border-emerald-500/30">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="truncate">
              <div className="text-xs font-semibold text-white truncate">{user?.name}</div>
              <div className="text-[11px] text-emerald-400 capitalize">{user?.role}</div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            title="Sign Out"
            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Container */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Header Bar */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 md:px-8 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div className="relative hidden sm:block w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search telemetry, stations, alerts..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-100 hover:bg-slate-200/60 focus:bg-white rounded-lg border border-transparent focus:border-emerald-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Live Indicator */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-full text-xs font-semibold text-emerald-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Telemetry Online</span>
            </div>

            {/* Notification Bell */}
            <button
              onClick={() => navigate('/maintenance')}
              title="Maintenance Alerts"
              className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-amber-500 rounded-full"></span>
            </button>

            {/* User Profile Pill */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-emerald-400 flex items-center justify-center font-bold text-xs">
                {user?.name?.charAt(0) || 'U'}
              </div>
              <div className="hidden lg:block text-left text-xs">
                <div className="font-semibold text-slate-800">{user?.name}</div>
                <div className="text-[10px] text-slate-500">{user?.email}</div>
              </div>
            </div>
          </div>
        </header>

        {/* Mobile Sidebar Dropdown */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-slate-900 text-white px-4 py-4 space-y-1 border-b border-slate-800 z-50">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800"
              >
                <item.icon className="w-4 h-4" />
                <span>{item.name}</span>
              </NavLink>
            ))}
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:bg-slate-800 rounded-lg"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        )}

        {/* Page Content Body */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
