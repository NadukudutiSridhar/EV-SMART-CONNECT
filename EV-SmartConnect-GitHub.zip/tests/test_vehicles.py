def test_vehicle_crud_and_cross_user_isolation(client):
    # 1. Register User A
    user_a = client.post("/api/auth/register", json={
        "name": "User Alpha", "email": "alpha_suite@test.com", "password": "Password@123", "role": "user"
    }).json()
    token_a = user_a["access_token"]
    headers_a = {"Authorization": f"Bearer {token_a}"}

    # 2. Register User B
    user_b = client.post("/api/auth/register", json={
        "name": "User Beta", "email": "beta_suite@test.com", "password": "Password@123", "role": "user"
    }).json()
    token_b = user_b["access_token"]
    headers_b = {"Authorization": f"Bearer {token_b}"}

    # 3. User A adds vehicle
    veh_resp = client.post("/api/vehicles", headers=headers_a, json={
        "model": "EV6 GT",
        "make": "Kia",
        "registration_number": "KA-01-EV-9999",
        "battery_capacity": 77.4,
        "vehicle_type": "Crossover",
        "manufacturing_year": 2024
    })
    assert veh_resp.status_code == 201
    veh_id = veh_resp.json()["id"]

    # 4. User A can view vehicle
    get_a = client.get(f"/api/vehicles/{veh_id}", headers=headers_a)
    assert get_a.status_code == 200
    assert get_a.json()["model"] == "EV6 GT"

    # 5. User B CANNOT view or delete User A's vehicle (Cybersecurity Isolation)
    get_b = client.get(f"/api/vehicles/{veh_id}", headers=headers_b)
    assert get_b.status_code == 403

    del_b = client.delete(f"/api/vehicles/{veh_id}", headers=headers_b)
    assert del_b.status_code == 403

    # 6. User A updates vehicle
    upd_a = client.put(f"/api/vehicles/{veh_id}", headers=headers_a, json={
        "firmware_version": "v3.0.1"
    })
    assert upd_a.status_code == 200
    assert upd_a.json()["firmware_version"] == "v3.0.1"

    # 7. User A deletes vehicle
    del_a = client.delete(f"/api/vehicles/{veh_id}", headers=headers_a)
    assert del_a.status_code == 204
