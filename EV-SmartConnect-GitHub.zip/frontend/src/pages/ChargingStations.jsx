import React, { useState, useEffect } from 'react';
import { chargingAPI } from '../services/api';
import {
  MapPin,
  Zap,
  Navigation,
  Search,
  Filter,
  CheckCircle,
  Info,
  Crosshair,
  Compass,
  ArrowRight,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMap, Circle } from 'react-leaflet';
import L from 'leaflet';

// Fix Leaflet default marker icon paths
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom Green Leaflet Marker Icon for EV Stations
const evStationIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Custom Blue Pin for User Location
const userLocationIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Sub-component to smoothly pan & fly map when coordinates change
function MapRecenter({ center, zoom = 12 }) {
  const map = useMap();
  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.flyTo(center, zoom, { duration: 1.2 });
    }
  }, [center, zoom, map]);
  return null;
}

const INDIAN_CITIES = [
  { name: 'Bengaluru', coords: [12.9716, 77.5946] },
  { name: 'Delhi NCR', coords: [28.6139, 77.2090] },
  { name: 'Mumbai', coords: [19.0760, 72.8777] },
  { name: 'Hyderabad', coords: [17.3850, 78.4867] },
  { name: 'Chennai', coords: [13.0827, 80.2707] },
  { name: 'Pune', coords: [18.5204, 73.8567] }
];

const ChargingStations = () => {
  const [currentCoords, setCurrentCoords] = useState([12.9716, 77.5946]);
  const [selectedCity, setSelectedCity] = useState('Bengaluru');
  const [userGpsActive, setUserGpsActive] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [locationStatusText, setLocationStatusText] = useState('Default location: Bengaluru');

  const [stations, setStations] = useState([]);
  const [filteredStations, setFilteredStations] = useState([]);
  const [selectedStation, setSelectedStation] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [connectorFilter, setConnectorFilter] = useState('all');
  const [speedFilter, setSpeedFilter] = useState(0);
  const [loading, setLoading] = useState(true);

  // Fetch stations relative to current coordinates
  const fetchStationsForLocation = async (lat, lon) => {
    try {
      setLoading(true);
      const res = await chargingAPI.getStations({ lat, lon });
      setStations(res.data);
      setFilteredStations(res.data);
      if (res.data.length > 0) {
        setSelectedStation(res.data[0]);
      }
    } catch (err) {
      console.error("Failed to load charging stations", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStationsForLocation(currentCoords[0], currentCoords[1]);
  }, [currentCoords]);

  // Client-side text & connector filters
  useEffect(() => {
    let result = stations;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        s => s.name.toLowerCase().includes(q) ||
             s.address.toLowerCase().includes(q) ||
             s.operator.toLowerCase().includes(q)
      );
    }
    if (connectorFilter !== 'all') {
      result = result.filter(s => s.connector_types.toLowerCase().includes(connectorFilter.toLowerCase()));
    }
    if (speedFilter > 0) {
      result = result.filter(s => s.charging_speed >= speedFilter);
    }
    setFilteredStations(result);
  }, [searchQuery, connectorFilter, speedFilter, stations]);

  // GPS Browser Geolocation
  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser.");
      return;
    }
    setIsLocating(true);
    setLocationStatusText("Detecting your GPS location...");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setCurrentCoords([latitude, longitude]);
        setUserGpsActive(true);
        setSelectedCity('GPS Location');
        setIsLocating(false);
        setLocationStatusText(`Using your live GPS location (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`);
      },
      (error) => {
        console.warn("Geolocation error", error);
        setIsLocating(false);
        setUserGpsActive(false);
        setLocationStatusText("Location access denied or unavailable. Fallback to city selection.");
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // City Switcher
  const handleSelectCity = (cityName) => {
    const city = INDIAN_CITIES.find(c => c.name === cityName);
    if (city) {
      setSelectedCity(cityName);
      setUserGpsActive(false);
      setCurrentCoords(city.coords);
      setLocationStatusText(`Centered on ${cityName} EV Network`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Location Status */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Location-Based EV Charging Locator</h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              India EV Network
            </span>
          </div>
          <p className="text-slate-500 text-xs mt-1">
            Real-time proximity calculation, port availability, connector filtering, and GPS navigation
          </p>
        </div>

        {/* Live Geolocation Button */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={handleUseMyLocation}
            disabled={isLocating}
            className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-semibold shadow-sm transition-all border ${
              userGpsActive
                ? 'bg-blue-600 text-white border-blue-600 shadow-blue-500/20'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
            }`}
          >
            <Crosshair className={`w-4 h-4 ${isLocating ? 'animate-spin text-blue-500' : (userGpsActive ? 'text-white' : 'text-blue-600')}`} />
            <span>{isLocating ? 'Locating...' : (userGpsActive ? 'My GPS Location Active' : 'Locate Me (Use GPS)')}</span>
          </button>
        </div>
      </div>

      {/* City Switcher & Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        {/* City Quick-Jump Selector */}
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <span className="text-[11px] font-bold uppercase text-slate-400 flex items-center gap-1 tracking-wider">
            <Building2 className="w-3.5 h-3.5" />
            <span>Select Indian City:</span>
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-medium">
            {INDIAN_CITIES.map((c) => (
              <button
                key={c.name}
                onClick={() => handleSelectCity(c.name)}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
                  selectedCity === c.name && !userGpsActive
                    ? 'bg-slate-900 text-emerald-400 font-bold shadow-sm'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col md:flex-row gap-3 items-center">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by area, network (Tata Power, Jio-bp, Statiq, Zeon), or connector..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <select
              value={connectorFilter}
              onChange={(e) => setConnectorFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-500 font-medium"
            >
              <option value="all">All Connectors</option>
              <option value="CCS2">CCS2 (DC Fast)</option>
              <option value="Type 2">Type 2 (AC)</option>
              <option value="CHAdeMO">CHAdeMO</option>
            </select>

            <select
              value={speedFilter}
              onChange={(e) => setSpeedFilter(parseFloat(e.target.value))}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-500 font-medium"
            >
              <option value="0">All Speeds</option>
              <option value="60">Fast (≥ 60 kW)</option>
              <option value="120">Ultra-Fast (≥ 120 kW)</option>
            </select>
          </div>
        </div>

        {/* Location Status Feedback */}
        <div className="text-[11px] text-slate-500 flex items-center justify-between">
          <span>📍 <strong>Location Status:</strong> {locationStatusText}</span>
          <span className="font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            {filteredStations.length} chargers within radius
          </span>
        </div>
      </div>

      {/* Map & Proximity List Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[580px]">
        {/* Left: Nearest Stations List */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <span className="text-xs font-bold text-slate-800">
              Nearest Charging Hubs
            </span>
            <span className="text-[11px] text-slate-400">Sorted by proximity</span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-2 space-y-1">
            {filteredStations.map((s, idx) => {
              const isSelected = selectedStation?.id === s.id;
              return (
                <div
                  key={s.id}
                  onClick={() => setSelectedStation(s)}
                  className={`p-3.5 rounded-xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-emerald-50/80 border border-emerald-500/40 shadow-sm'
                      : 'hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs">{s.name}</h4>
                      <span className="text-[10px] text-slate-400 font-medium">{s.operator}</span>
                    </div>
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex-shrink-0">
                      {s.charging_speed} kW
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-500 mb-2 truncate">{s.address}</div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-600">
                      Ports: <strong>{s.available_ports}</strong> / {s.total_ports} free
                    </span>
                    <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                      {s.distance_km !== null ? `${s.distance_km} km away` : 'Nearby'}
                    </span>
                  </div>
                </div>
              );
            })}

            {filteredStations.length === 0 && (
              <div className="p-8 text-center text-slate-400 text-xs">
                No charging stations match your current filters. Try selecting a different city or clearing speed filters.
              </div>
            )}
          </div>
        </div>

        {/* Right: Leaflet Interactive OpenStreetMap */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden relative">
          <MapContainer
            center={currentCoords}
            zoom={12}
            scrollWheelZoom={true}
            className="w-full h-full"
          >
            {/* Auto Recenter Helper */}
            <MapRecenter center={currentCoords} zoom={userGpsActive ? 13 : 12} />

            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {/* User GPS Pin (if active) */}
            {userGpsActive && (
              <>
                <Marker position={currentCoords} icon={userLocationIcon}>
                  <Popup>
                    <div className="text-xs font-bold text-blue-700">You Are Here (Live Location)</div>
                  </Popup>
                </Marker>
                <Circle center={currentCoords} radius={1500} pathOptions={{ color: '#3b82f6', fillColor: '#3b82f6', fillOpacity: 0.1 }} />
              </>
            )}

            {/* EV Charging Station Pins */}
            {filteredStations.map((s) => (
              <Marker
                key={s.id}
                position={[s.latitude, s.longitude]}
                icon={evStationIcon}
                eventHandlers={{
                  click: () => setSelectedStation(s)
                }}
              >
                <Popup>
                  <div className="p-1 space-y-1 text-xs">
                    <div className="font-bold text-slate-900">{s.name}</div>
                    <div className="text-[11px] text-slate-500">{s.address}</div>
                    <div className="text-emerald-700 font-semibold">{s.charging_speed} kW • {s.connector_types}</div>
                    <div className="text-slate-700">{s.available_ports} of {s.total_ports} ports available</div>
                    {s.distance_km !== null && (
                      <div className="font-mono text-emerald-600 font-bold">{s.distance_km} km from current point</div>
                    )}
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${s.latitude},${s.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-center mt-2 px-3 py-1 bg-emerald-600 text-white rounded font-semibold text-[11px]"
                    >
                      Start Navigation in Google Maps
                    </a>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>

          {/* Floating Selected Station Banner */}
          {selectedStation && (
            <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md rounded-2xl p-4 border border-slate-200 shadow-xl z-[400] flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-fade-in">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-slate-900 text-sm">{selectedStation.name}</h4>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                    {selectedStation.charging_speed} kW DC
                  </span>
                  {selectedStation.distance_km !== null && (
                    <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      {selectedStation.distance_km} km away
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{selectedStation.address}</p>
                <div className="flex items-center gap-3 text-xs text-slate-600 mt-1">
                  <span>Connectors: <strong>{selectedStation.connector_types}</strong></span>
                  <span>Price: <strong>₹{selectedStation.price_per_kwh}/kWh</strong></span>
                  <span>Available: <strong className="text-emerald-700">{selectedStation.available_ports} ports</strong></span>
                </div>
              </div>

              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${selectedStation.latitude},${selectedStation.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-600/20 transition-all flex-shrink-0"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Start Navigation</span>
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChargingStations;
