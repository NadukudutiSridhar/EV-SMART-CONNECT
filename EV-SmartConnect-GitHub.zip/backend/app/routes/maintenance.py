from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Optional

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.vehicle import Vehicle
from backend.app.models.maintenance import MaintenanceAlert
from backend.app.schemas.maintenance import MaintenanceAlertCreate, MaintenanceAlertUpdate, MaintenanceAlertResponse
from backend.app.security.auth import get_current_user, verify_vehicle_ownership
from backend.app.security.middleware import audit_log

router = APIRouter(prefix="/api/maintenance", tags=["Predictive Maintenance"])

@router.get("", response_model=List[MaintenanceAlertResponse])
def list_maintenance_alerts(
    vehicle_id: Optional[int] = None,
    unresolved_only: bool = True,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(MaintenanceAlert)
    if vehicle_id:
        verify_vehicle_ownership(vehicle_id, current_user, db)
        query = query.filter(MaintenanceAlert.vehicle_id == vehicle_id)
    elif current_user.role != "admin":
        user_vehicle_ids = [v.id for v in current_user.vehicles]
        query = query.filter(MaintenanceAlert.vehicle_id.in_(user_vehicle_ids))

    if unresolved_only:
        query = query.filter(MaintenanceAlert.is_resolved == False)

    alerts = query.order_by(MaintenanceAlert.created_at.desc()).all()
    resp = []
    for a in alerts:
        r = MaintenanceAlertResponse.from_orm(a)
        if a.vehicle:
            r.vehicle_name = f"{a.vehicle.make} {a.vehicle.model} ({a.vehicle.registration_number})"
        resp.append(r)
    return resp

@router.post("", response_model=MaintenanceAlertResponse, status_code=status.HTTP_201_CREATED)
def create_maintenance_alert(req: MaintenanceAlertCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    verify_vehicle_ownership(req.vehicle_id, current_user, db)
    alert = MaintenanceAlert(
        vehicle_id=req.vehicle_id,
        alert_type=req.alert_type,
        severity=req.severity,
        description=req.description,
        recommended_action=req.recommended_action,
        sensor_value=req.sensor_value,
        threshold_value=req.threshold_value,
        detection_method=req.detection_method or "Threshold",
        is_resolved=False
    )
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert

@router.put("/{alert_id}", response_model=MaintenanceAlertResponse)
def update_maintenance_alert(alert_id: int, req: MaintenanceAlertUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    alert = db.query(MaintenanceAlert).filter(MaintenanceAlert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Maintenance alert not found")

    verify_vehicle_ownership(alert.vehicle_id, current_user, db)

    alert.is_resolved = req.is_resolved
    if req.is_resolved:
        alert.resolved_at = datetime.now()
    if req.recommended_action:
        alert.recommended_action = req.recommended_action

    db.commit()
    db.refresh(alert)
    audit_log("MAINTENANCE_ALERT_RESOLVED", current_user.email, f"Alert ID: {alert_id}")
    return alert
