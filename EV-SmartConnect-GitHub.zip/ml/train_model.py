import os
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import joblib

DATASET_PATH = os.path.join(os.path.dirname(__file__), "dataset.csv")
MODEL_PATH = os.path.join(os.path.dirname(__file__), "range_model.pkl")
ANOMALY_MODEL_PATH = os.path.join(os.path.dirname(__file__), "anomaly_model.pkl")
METRICS_PATH = os.path.join(os.path.dirname(__file__), "model_metrics.json")

def generate_ev_dataset(n_samples=5000, random_state=42):
    """
    Generate physics-consistent synthetic EV operational dataset.
    Features:
      - soc: State of Charge (10% to 100%)
      - soh: State of Health (75% to 100%)
      - temperature: Ambient/Battery pack temp in Celsius (-10 to 45 C)
      - avg_speed: Average vehicle speed in km/h (20 to 130 km/h)
      - vehicle_load: Additional payload in kg (0 to 400 kg)
      - energy_consumption: Nominal consumption in kWh/100km (12 to 26)
      - terrain: 'flat', 'uphill', 'downhill', 'mixed'
      - battery_capacity: nominal kWh (default ~75 kWh)
    Target:
      - remaining_range_km: Calculated based on remaining usable energy adjusted for
        aerodynamics, temperature efficiency loss, terrain resistance, and weight.
    """
    np.random.seed(random_state)
    
    soc = np.random.uniform(5, 100, n_samples)
    soh = np.random.uniform(75, 100, n_samples)
    temperature = np.random.uniform(-10, 48, n_samples)
    avg_speed = np.random.uniform(20, 130, n_samples)
    vehicle_load = np.random.uniform(0, 450, n_samples)
    nominal_consumption = np.random.uniform(13.0, 24.0, n_samples)
    terrain_choices = ['flat', 'uphill', 'downhill', 'mixed']
    terrain = np.random.choice(terrain_choices, size=n_samples, p=[0.45, 0.20, 0.15, 0.20])
    battery_capacity = np.random.choice([50.0, 60.0, 75.0, 85.0, 100.0], size=n_samples, p=[0.15, 0.25, 0.35, 0.15, 0.10])

    # Physical modifiers
    # 1. Temperature factor: Optimal is 20-25C. Cold (<10C) degrades chemical reaction; hot (>35C) requires heavy AC.
    temp_penalty = np.where(temperature < 20, 1.0 + 0.012 * (20 - temperature),
                   np.where(temperature > 30, 1.0 + 0.008 * (temperature - 30), 1.0))

    # 2. Speed factor: Aerodynamic drag increases quadratically with speed above 60 km/h
    speed_factor = 1.0 + np.maximum(0, (avg_speed - 60) / 100) ** 1.8 * 0.45

    # 3. Load factor: ~1.5% consumption increase per 100 kg
    load_factor = 1.0 + (vehicle_load / 100.0) * 0.015

    # 4. Terrain factor
    terrain_map = {'flat': 1.0, 'downhill': 0.85, 'uphill': 1.28, 'mixed': 1.08}
    terrain_factor = np.array([terrain_map[t] for t in terrain])

    # Dynamic effective consumption in kWh/100km
    effective_consumption = nominal_consumption * temp_penalty * speed_factor * load_factor * terrain_factor

    # Usable energy in kWh = capacity * (soc/100) * (soh/100)
    usable_energy = battery_capacity * (soc / 100.0) * (soh / 100.0)

    # Remaining Range (km) = (usable_energy / effective_consumption) * 100 + noise
    noise = np.random.normal(0, 3.5, n_samples)
    remaining_range = np.maximum(1.0, (usable_energy / effective_consumption) * 100.0 + noise)

    df = pd.DataFrame({
        'battery_capacity': np.round(battery_capacity, 1),
        'soc': np.round(soc, 1),
        'soh': np.round(soh, 1),
        'temperature': np.round(temperature, 1),
        'avg_speed': np.round(avg_speed, 1),
        'vehicle_load': np.round(vehicle_load, 1),
        'energy_consumption': np.round(effective_consumption, 2),
        'terrain': terrain,
        'remaining_range_km': np.round(remaining_range, 1)
    })

    return df

def train_and_evaluate():
    print("Generating simulated EV training dataset...")
    df = generate_ev_dataset(n_samples=6000, random_state=42)
    df.to_csv(DATASET_PATH, index=False)
    print(f"Dataset saved to {DATASET_PATH} with {len(df)} records.")

    numeric_features = ['battery_capacity', 'soc', 'soh', 'temperature', 'avg_speed', 'vehicle_load', 'energy_consumption']
    categorical_features = ['terrain']
    target = 'remaining_range_km'

    X = df[numeric_features + categorical_features]
    y = df[target]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numeric_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ]
    )

    # 1. Linear Regression
    lr_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', LinearRegression())
    ])
    lr_pipeline.fit(X_train, y_train)
    y_pred_lr = lr_pipeline.predict(X_test)

    lr_mae = float(mean_absolute_error(y_test, y_pred_lr))
    lr_rmse = float(np.sqrt(mean_squared_error(y_test, y_pred_lr)))
    lr_r2 = float(r2_score(y_test, y_pred_lr))

    print(f"Linear Regression -> MAE: {lr_mae:.2f} km | RMSE: {lr_rmse:.2f} km | R²: {lr_r2:.4f}")

    # 2. Random Forest Regressor
    rf_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', RandomForestRegressor(n_estimators=100, max_depth=16, random_state=42, n_jobs=-1))
    ])
    rf_pipeline.fit(X_train, y_train)
    y_pred_rf = rf_pipeline.predict(X_test)

    rf_mae = float(mean_absolute_error(y_test, y_pred_rf))
    rf_rmse = float(np.sqrt(mean_squared_error(y_test, y_pred_rf)))
    rf_r2 = float(r2_score(y_test, y_pred_rf))

    print(f"Random Forest     -> MAE: {rf_mae:.2f} km | RMSE: {rf_rmse:.2f} km | R²: {rf_r2:.4f}")

    # Select best model based on R2
    best_model_name = "RandomForest" if rf_r2 >= lr_r2 else "LinearRegression"
    best_pipeline = rf_pipeline if best_model_name == "RandomForest" else lr_pipeline

    joblib.dump(best_pipeline, MODEL_PATH)
    print(f"Selected {best_model_name} as the best model. Saved to {MODEL_PATH}")

    # 3. Train Isolation Forest for Battery Anomaly Detection (Module 9)
    # Features for anomaly detection: voltage, current, temperature, soc, energy_consumption
    print("Training Isolation Forest for Battery Telemetry Anomaly Detection...")
    anomaly_samples = 4000
    norm_voltage = np.random.normal(385.0, 15.0, anomaly_samples)
    norm_current = np.random.normal(-35.0, 20.0, anomaly_samples)
    norm_temp = np.random.normal(28.0, 5.0, anomaly_samples)
    norm_soc = np.random.uniform(15, 95, anomaly_samples)
    norm_consumption = np.random.normal(17.5, 3.0, anomaly_samples)

    X_anomaly = np.column_stack([norm_voltage, norm_current, norm_temp, norm_soc, norm_consumption])
    iso_forest = IsolationForest(contamination=0.03, random_state=42)
    iso_forest.fit(X_anomaly)
    joblib.dump(iso_forest, ANOMALY_MODEL_PATH)
    print(f"Isolation Forest model saved to {ANOMALY_MODEL_PATH}")

    metrics = {
        "dataset_samples": len(df),
        "models_evaluated": {
            "LinearRegression": {
                "mae": round(lr_mae, 3),
                "rmse": round(lr_rmse, 3),
                "r2_score": round(lr_r2, 4)
            },
            "RandomForest": {
                "mae": round(rf_mae, 3),
                "rmse": round(rf_rmse, 3),
                "r2_score": round(rf_r2, 4)
            }
        },
        "selected_model": best_model_name,
        "selected_metrics": {
            "mae": round(rf_mae if best_model_name == "RandomForest" else lr_mae, 3),
            "rmse": round(rf_rmse if best_model_name == "RandomForest" else lr_rmse, 3),
            "r2_score": round(rf_r2 if best_model_name == "RandomForest" else lr_r2, 4)
        },
        "disclaimer": "Models trained on physics-grounded simulated EV telemetry. Prototype estimates for educational and operational monitoring."
    }

    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"Metrics written to {METRICS_PATH}")

if __name__ == "__main__":
    train_and_evaluate()
