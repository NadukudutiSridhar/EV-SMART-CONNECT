from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from backend.app.database import Base

class Vehicle(Base):
    __tablename__ = "vehicles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    model = Column(String(120), nullable=False)
    make = Column(String(80), nullable=False)
    registration_number = Column(String(50), unique=True, index=True, nullable=False)
    vin = Column(String(50), unique=True, nullable=True)
    battery_capacity = Column(Float, nullable=False) # in kWh
    vehicle_type = Column(String(50), default="Sedan", nullable=False)
    manufacturing_year = Column(Integer, nullable=False)
    firmware_version = Column(String(50), default="v2.4.1", nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    owner = relationship("User", back_populates="vehicles")
    battery_readings = relationship("BatteryReading", back_populates="vehicle", cascade="all, delete-orphan")
    range_predictions = relationship("RangePrediction", back_populates="vehicle", cascade="all, delete-orphan")
    charging_sessions = relationship("ChargingSession", back_populates="vehicle", cascade="all, delete-orphan")
    maintenance_alerts = relationship("MaintenanceAlert", back_populates="vehicle", cascade="all, delete-orphan")
    trip_records = relationship("TripRecord", back_populates="vehicle", cascade="all, delete-orphan")
