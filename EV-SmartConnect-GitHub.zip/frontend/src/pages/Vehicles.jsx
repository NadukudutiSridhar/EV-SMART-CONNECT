import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { vehiclesAPI } from '../services/api';
import { INDIAN_EV_MODELS, generateIndianPlate } from '../data/indianEvModels';
import {
  Car,
  Plus,
  Trash2,
  Edit2,
  Zap,
  Check,
  X,
  AlertCircle,
  Sparkles,
  Search,
  Filter,
  CheckCircle,
  BatteryCharging,
  Gauge
} from 'lucide-react';

const Vehicles = () => {
  const { vehicles, refreshVehicles, selectedVehicleId, setSelectedVehicleId } = useAuth();
  const [activeTab, setActiveTab] = useState('garage'); // 'garage' or 'catalog'
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [selectedBrandFilter, setSelectedBrandFilter] = useState('All');
  const [catalogSearch, setCatalogSearch] = useState('');
  const [toastMessage, setToastMessage] = useState('');

  const [formData, setFormData] = useState({
    model: '',
    make: '',
    registration_number: '',
    vin: '',
    battery_capacity: 40.5,
    vehicle_type: 'SUV',
    manufacturing_year: 2024,
    firmware_version: 'v2.4.1'
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const brands = ['All', 'Tata', 'Mahindra', 'MG', 'Hyundai', 'Kia', 'BYD', 'Citroën', 'BMW', 'Mercedes-Benz', 'Volvo', 'Audi'];

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 4000);
  };

  const openCreateModal = () => {
    setEditingVehicle(null);
    setFormData({
      model: '',
      make: '',
      registration_number: generateIndianPlate('Tata'),
      vin: '',
      battery_capacity: 40.5,
      vehicle_type: 'SUV',
      manufacturing_year: 2024,
      firmware_version: 'v2.4.1'
    });
    setError('');
    setIsModalOpen(true);
  };

  const openEditModal = (v) => {
    setEditingVehicle(v);
    setFormData({
      model: v.model,
      make: v.make,
      registration_number: v.registration_number,
      vin: v.vin || '',
      battery_capacity: v.battery_capacity,
      vehicle_type: v.vehicle_type,
      manufacturing_year: v.manufacturing_year,
      firmware_version: v.firmware_version || 'v2.4.1'
    });
    setError('');
    setIsModalOpen(true);
  };

  const handleSelectPreset = (modelObj) => {
    setFormData({
      model: modelObj.model,
      make: modelObj.make,
      registration_number: generateIndianPlate(modelObj.make),
      vin: `IN${modelObj.make.substring(0, 3).toUpperCase()}${Date.now().toString().slice(-8)}`,
      battery_capacity: modelObj.battery_capacity,
      vehicle_type: modelObj.vehicle_type.split(' ')[0],
      manufacturing_year: modelObj.manufacturing_year,
      firmware_version: modelObj.firmware_version
    });
  };

  const handleAddDirectFromCatalog = async (ev) => {
    setLoading(true);
    try {
      const regPlate = generateIndianPlate(ev.make);
      await vehiclesAPI.create({
        make: ev.make,
        model: ev.model,
        registration_number: regPlate,
        vin: `IN${ev.make.substring(0, 3).toUpperCase()}${Date.now().toString().slice(-8)}`,
        battery_capacity: ev.battery_capacity,
        vehicle_type: ev.vehicle_type.split(' ')[0],
        manufacturing_year: ev.manufacturing_year,
        firmware_version: ev.firmware_version
      });
      await refreshVehicles();
      showToast(`Added ${ev.make} ${ev.model} (${regPlate}) to your Garage!`);
      setActiveTab('garage');
    } catch (err) {
      alert(err.response?.data?.detail || 'Failed to add vehicle');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (editingVehicle) {
        await vehiclesAPI.update(editingVehicle.id, formData);
        showToast(`Updated ${formData.make} ${formData.model}!`);
      } else {
        await vehiclesAPI.create(formData);
        showToast(`Added ${formData.make} ${formData.model} to your Garage!`);
      }
      await refreshVehicles();
      setIsModalOpen(false);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to save vehicle details');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to remove this vehicle from your account?")) return;
    try {
      await vehiclesAPI.delete(id);
      await refreshVehicles();
      showToast("Vehicle removed.");
    } catch (err) {
      alert(err.response?.data?.detail || 'Failed to delete vehicle');
    }
  };

  // Filter Catalog
  const filteredCatalog = INDIAN_EV_MODELS.filter((ev) => {
    const matchesBrand = selectedBrandFilter === 'All' || ev.make.toLowerCase() === selectedBrandFilter.toLowerCase();
    const q = catalogSearch.toLowerCase();
    const matchesSearch = !q || ev.make.toLowerCase().includes(q) || ev.model.toLowerCase().includes(q) || ev.vehicle_type.toLowerCase().includes(q);
    return matchesBrand && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 border border-emerald-500/40 animate-fade-in text-xs font-semibold">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">EV Vehicle Management</h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              India EV Ecosystem
            </span>
          </div>
          <p className="text-slate-500 text-xs mt-1">
            Browse all Indian EV models (Tata, Mahindra, MG, Hyundai, BYD, Kia) and manage your garage
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab(activeTab === 'garage' ? 'catalog' : 'garage')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all border border-slate-200"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{activeTab === 'garage' ? 'Explore India EV Catalog' : 'View My Garage'}</span>
          </button>
          <button
            onClick={openCreateModal}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Vehicle</span>
          </button>
        </div>
      </div>

      {/* Segment Tabs */}
      <div className="flex items-center gap-2 p-1 bg-slate-200/70 rounded-2xl w-fit text-xs font-semibold">
        <button
          onClick={() => setActiveTab('garage')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'garage' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          My Registered Garage ({vehicles.length})
        </button>
        <button
          onClick={() => setActiveTab('catalog')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
            activeTab === 'catalog' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>India All EV Catalog</span>
          <span className="text-[10px] bg-white/20 px-1.5 py-0.2 rounded-full">
            {INDIAN_EV_MODELS.length} Models
          </span>
        </button>
      </div>

      {/* TAB 1: MY REGISTERED GARAGE */}
      {activeTab === 'garage' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vehicles.map((v) => {
              const isSelected = v.id === selectedVehicleId;
              return (
                <div
                  key={v.id}
                  className={`bg-white rounded-2xl border transition-all duration-200 p-6 flex flex-col justify-between shadow-sm relative overflow-hidden ${
                    isSelected ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-0 right-0 bg-emerald-600 text-white text-[10px] uppercase font-bold tracking-wider px-3 py-1 rounded-bl-xl flex items-center gap-1 shadow-sm">
                      <Check className="w-3 h-3" />
                      <span>Active Dashboard</span>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700">
                        <Car className="w-6 h-6 text-emerald-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900 text-base">{v.make} {v.model}</h3>
                        <div className="text-xs font-mono font-medium text-slate-500">{v.registration_number}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 py-3 border-y border-slate-100 my-4 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Battery Pack</span>
                        <span className="font-bold text-slate-800">{v.battery_capacity} kWh</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Vehicle Type</span>
                        <span className="font-semibold text-slate-800">{v.vehicle_type}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Model Year</span>
                        <span className="font-semibold text-slate-800">{v.manufacturing_year}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Firmware</span>
                        <span className="font-mono text-slate-700">{v.firmware_version || 'v2.4.1'}</span>
                      </div>
                    </div>

                    {v.vin && (
                      <div className="text-[11px] text-slate-400 mb-4 font-mono truncate">
                        VIN: <span className="text-slate-600">{v.vin}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 gap-2">
                    <button
                      onClick={() => setSelectedVehicleId(v.id)}
                      disabled={isSelected}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-emerald-50 text-emerald-700 cursor-default'
                          : 'bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-700'
                      }`}
                    >
                      {isSelected ? 'Currently Monitored' : 'Select Vehicle'}
                    </button>
                    <button
                      onClick={() => openEditModal(v)}
                      className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200"
                      title="Edit details"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(v.id)}
                      className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors border border-slate-200"
                      title="Remove vehicle"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {vehicles.length === 0 && (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
              <Car className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base mb-1">Your Garage is Empty</h3>
              <p className="text-slate-500 text-xs max-w-sm mx-auto mb-4">
                Explore the India EV catalog to add popular models like Tata Curvv EV, Mahindra BE 6e, or MG Windsor in one click!
              </p>
              <button
                onClick={() => setActiveTab('catalog')}
                className="px-4 py-2 bg-emerald-600 text-white font-semibold text-xs rounded-xl"
              >
                Browse Indian EV Models
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: EXPLORE ALL INDIAN EV MODELS CATALOG */}
      {activeTab === 'catalog' && (
        <div className="space-y-5">
          {/* Brand Filter Pills & Search */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search Indian EV models (e.g. Curvv, Nexon, Windsor, BE 6e, Creta, Seal, Ioniq 5)..."
                value={catalogSearch}
                onChange={(e) => setCatalogSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {brands.map((b) => (
                <button
                  key={b}
                  onClick={() => setSelectedBrandFilter(b)}
                  className={`px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap transition-all ${
                    selectedBrandFilter === b
                      ? 'bg-slate-900 text-emerald-400'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Model Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredCatalog.map((ev, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200/90 hover:border-emerald-500/50 hover:shadow-md transition-all p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                        {ev.make}
                      </span>
                      <h3 className="font-extrabold text-slate-900 text-base mt-1">{ev.model}</h3>
                    </div>
                    <span className="text-xs font-extrabold text-slate-800 bg-slate-100 px-2.5 py-1 rounded-xl">
                      {ev.battery_capacity} kWh
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 italic mb-3 min-h-[32px]">{ev.tagline}</p>

                  <div className="grid grid-cols-2 gap-2 text-xs py-3 border-y border-slate-100 mb-4 bg-slate-50/50 p-2.5 rounded-xl">
                    <div>
                      <span className="text-slate-400 text-[10px] block">Claimed Range</span>
                      <span className="font-bold text-slate-800">{ev.claimed_range_km} km (ARAI)</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block">Real-World Range</span>
                      <span className="font-bold text-emerald-700">{ev.real_world_range_km} km</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block">Fast Charge (DC)</span>
                      <span className="font-semibold text-slate-800">{ev.charging_speed_kw} kW</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block">Ex-Showroom Price</span>
                      <span className="font-semibold text-slate-800">{ev.price_inr}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 mb-2">
                    <span>Ports: <strong>{ev.connector}</strong></span>
                    <span>Segment: <strong>{ev.vehicle_type}</strong></span>
                  </div>
                </div>

                <button
                  onClick={() => handleAddDirectFromCatalog(ev)}
                  disabled={loading}
                  className="w-full mt-3 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add to My Garage</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Manual / Preset Registration Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 animate-scale-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
              <h3 className="font-bold text-slate-900 text-lg">
                {editingVehicle ? 'Edit Electric Vehicle' : 'Register Electric Vehicle'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Auto-Fill Dropdown */}
            {!editingVehicle && (
              <div className="mb-4 p-3 bg-emerald-50/80 border border-emerald-200 rounded-xl text-xs">
                <label className="block font-bold text-emerald-900 mb-1 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Select from Indian EV Catalog (Auto-Fills Specs):</span>
                </label>
                <select
                  onChange={(e) => {
                    const found = INDIAN_EV_MODELS.find(m => `${m.make} ${m.model}` === e.target.value);
                    if (found) handleSelectPreset(found);
                  }}
                  className="w-full px-2.5 py-1.5 bg-white border border-emerald-300 rounded-lg text-xs outline-none focus:border-emerald-600"
                >
                  <option value="">-- Choose Indian EV Model to Auto-Fill --</option>
                  {INDIAN_EV_MODELS.map((m, i) => (
                    <option key={i} value={`${m.make} ${m.model}`}>
                      {m.make} {m.model} ({m.battery_capacity} kWh • {m.real_world_range_km} km)
                    </option>
                  ))}
                </select>
              </div>
            )}

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Make / Manufacturer</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tata, Mahindra, MG, BYD"
                    value={formData.make}
                    onChange={(e) => setFormData({ ...formData, make: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Model Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Curvv EV, BE 6e, Windsor EV"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Registration (RTO Number)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. KA-01-EV-2026"
                    value={formData.registration_number}
                    onChange={(e) => setFormData({ ...formData, registration_number: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500 uppercase font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Battery Capacity (kWh)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="10"
                    max="200"
                    required
                    value={formData.battery_capacity}
                    onChange={(e) => setFormData({ ...formData, battery_capacity: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Vehicle Type</label>
                  <select
                    value={formData.vehicle_type}
                    onChange={(e) => setFormData({ ...formData, vehicle_type: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  >
                    <option value="SUV">SUV</option>
                    <option value="SUV Coupe">SUV Coupe</option>
                    <option value="Sedan">Sedan</option>
                    <option value="Hatchback">Hatchback</option>
                    <option value="Crossover">Crossover</option>
                    <option value="CUV">CUV</option>
                    <option value="MPV">MPV</option>
                    <option value="Commercial">Commercial</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Manufacturing Year</label>
                  <input
                    type="number"
                    min="2012"
                    max="2027"
                    required
                    value={formData.manufacturing_year}
                    onChange={(e) => setFormData({ ...formData, manufacturing_year: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Firmware Version</label>
                  <input
                    type="text"
                    value={formData.firmware_version}
                    onChange={(e) => setFormData({ ...formData, firmware_version: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">VIN Number</label>
                  <input
                    type="text"
                    placeholder="17-character VIN"
                    value={formData.vin}
                    onChange={(e) => setFormData({ ...formData, vin: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500 font-mono uppercase"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-md shadow-emerald-600/20"
                >
                  {loading ? 'Saving...' : (editingVehicle ? 'Update Vehicle' : 'Register Vehicle')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Vehicles;
