import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { maintenanceAPI } from '../services/api';
import {
  Wrench,
  AlertTriangle,
  CheckCircle,
  Clock,
  ShieldAlert,
  Cpu,
  RefreshCw,
  Info
} from 'lucide-react';

const Maintenance = () => {
  const { vehicles, selectedVehicleId } = useAuth();
  const currentVehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  const [alerts, setAlerts] = useState([]);
  const [showUnresolvedOnly, setShowUnresolvedOnly] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    if (!currentVehicle) return;
    try {
      setLoading(true);
      const res = await maintenanceAPI.getAlerts({
        vehicle_id: currentVehicle.id,
        unresolved_only: showUnresolvedOnly
      });
      setAlerts(res.data);
    } catch (err) {
      console.error("Failed to load alerts", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, [currentVehicle?.id, showUnresolvedOnly]);

  const handleResolve = async (alertId) => {
    try {
      await maintenanceAPI.resolveAlert(alertId, { is_resolved: true });
      await fetchAlerts();
    } catch (err) {
      alert("Failed to resolve alert: " + (err.response?.data?.detail || err.message));
    }
  };

  const getSeverityBadge = (severity) => {
    switch (severity?.toLowerCase()) {
      case 'high':
        return <span className="px-2.5 py-1 rounded-full bg-red-100 text-red-800 text-[10px] font-bold uppercase tracking-wider">High Severity</span>;
      case 'medium':
        return <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider">Medium Severity</span>;
      default:
        return <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold uppercase tracking-wider">Low Severity</span>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Predictive Maintenance & Alert Center</h1>
          <p className="text-slate-500 text-xs mt-1">
            Hybrid threshold and machine-learning anomaly detection for early component degradation warning
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showUnresolvedOnly}
              onChange={(e) => setShowUnresolvedOnly(e.target.checked)}
              className="rounded accent-emerald-600"
            />
            <span>Unresolved Alerts Only</span>
          </label>
          <button
            onClick={fetchAlerts}
            className="p-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Engineering Diagnostic Disclaimer Banner */}
      <div className="p-4 bg-slate-100 border border-slate-200 rounded-2xl flex items-start gap-3 text-xs text-slate-600">
        <Info className="w-4 h-4 text-slate-500 mt-0.5 flex-shrink-0" />
        <div>
          <strong className="text-slate-800">Operational Notice:</strong> Anomaly detection flags statistical and engineering threshold outliers to prompt preventive evaluation. An alert does not conclusively diagnose an unrecoverable hardware fault.
        </div>
      </div>

      {/* Alerts Grid / List */}
      <div className="space-y-4">
        {alerts.map((a) => (
          <div
            key={a.id}
            className={`bg-white rounded-2xl p-5 border shadow-sm transition-all ${
              a.is_resolved
                ? 'border-slate-200 opacity-60'
                : (a.severity === 'High' ? 'border-red-300 ring-1 ring-red-300/40' : 'border-amber-200')
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  {getSeverityBadge(a.severity)}
                  <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-mono font-medium">
                    {a.alert_type}
                  </span>
                  <span className="flex items-center gap-1 text-[11px] text-slate-500 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                    <Cpu className="w-3 h-3 text-emerald-600" />
                    <span>{a.detection_method}</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {new Date(a.created_at).toLocaleString()}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm">{a.description}</h3>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs">
                  <span className="font-semibold text-slate-700 block mb-0.5">Recommended Action:</span>
                  <p className="text-slate-600">{a.recommended_action}</p>
                </div>

                {a.sensor_value && a.threshold_value && (
                  <div className="text-[11px] text-slate-500 font-mono">
                    Observed Sensor Value: <strong>{a.sensor_value}</strong> | Threshold Limit: <strong>{a.threshold_value}</strong>
                  </div>
                )}
              </div>

              {/* Action Button */}
              <div className="flex md:flex-col items-center justify-end gap-2 flex-shrink-0">
                {a.is_resolved ? (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold px-3 py-1.5 bg-emerald-50 rounded-xl">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Resolved</span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleResolve(a.id)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
                  >
                    Mark as Resolved
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {alerts.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
            <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
            <h3 className="font-bold text-slate-800 text-base mb-1">All Systems Operating Normally</h3>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              No active anomalies or maintenance warnings logged for this vehicle.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Maintenance;
