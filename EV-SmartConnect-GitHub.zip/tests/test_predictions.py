from ml.predict import predict_ev_range, detect_telemetry_anomaly

def test_ml_range_prediction_logic():
    result = predict_ev_range(
        battery_capacity=75.0,
        soc=80.0,
        soh=98.0,
        temperature=25.0,
        avg_speed=60.0,
        vehicle_load=75.0,
        energy_consumption=16.5,
        terrain="flat"
    )
    assert "predicted_range_km" in result
    assert result["predicted_range_km"] > 100.0
    assert result["confidence_score"] > 0.8

def test_ml_range_prediction_depleted_battery():
    result = predict_ev_range(
        battery_capacity=75.0,
        soc=0.0,
        soh=95.0,
        temperature=25.0,
        avg_speed=50.0,
        vehicle_load=50.0,
        energy_consumption=16.0
    )
    assert result["predicted_range_km"] == 0.0

def test_telemetry_anomaly_detection():
    normal = detect_telemetry_anomaly(
        voltage=395.0,
        current=-35.0,
        temperature=28.0,
        soc=75.0,
        energy_consumption=16.0
    )
    assert normal["is_anomaly"] is False

    hot = detect_telemetry_anomaly(
        voltage=395.0,
        current=-40.0,
        temperature=52.0,
        soc=75.0,
        energy_consumption=16.0
    )
    assert hot["is_anomaly"] is True
    assert hot["severity"] == "High"

    sag = detect_telemetry_anomaly(
        voltage=290.0,
        current=-60.0,
        temperature=30.0,
        soc=60.0,
        energy_consumption=18.0
    )
    assert sag["is_anomaly"] is True
    assert "voltage" in sag["reasons"][0].lower()

def test_prediction_api_endpoint(client):
    resp = client.post("/api/predict-range", json={
        "battery_capacity": 60.0,
        "soc": 90.0,
        "soh": 99.0,
        "temperature": 22.0,
        "avg_speed": 55.0,
        "vehicle_load": 80.0,
        "energy_consumption": 15.5,
        "terrain": "flat"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["predicted_range_km"] > 0
    assert data["model_version"] == "RandomForest-v1.0"
