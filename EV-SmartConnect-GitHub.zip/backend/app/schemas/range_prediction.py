from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class RangePredictionRequest(BaseModel):
    vehicle_id: Optional[int] = None
    battery_capacity: Optional[float] = Field(default=75.0, gt=0.0)
    soc: float = Field(..., ge=0.0, le=100.0)
    soh: float = Field(..., ge=50.0, le=100.0)
    temperature: float = Field(default=25.0)
    avg_speed: float = Field(default=60.0, ge=0.0)
    vehicle_load: float = Field(default=75.0, ge=0.0)
    energy_consumption: float = Field(default=16.5, gt=0.0)
    terrain: str = Field(default="flat")

class RangePredictionResponse(BaseModel):
    id: Optional[int] = None
    vehicle_id: Optional[int] = None
    predicted_range_km: float
    confidence_score: float
    model_version: str
    features_used: dict
    disclaimer: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
