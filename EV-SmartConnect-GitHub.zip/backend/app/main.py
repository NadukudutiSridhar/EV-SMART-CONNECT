import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.app.config import settings
from backend.app.database import engine, Base
from backend.app.security.middleware import RateLimitMiddleware
from backend.app.routes.auth import router as auth_router
from backend.app.routes.vehicles import router as vehicles_router
from backend.app.routes.battery import router as battery_router
from backend.app.routes.ai import router as ai_router
from backend.app.routes.charging import router as charging_router
from backend.app.routes.maintenance import router as maintenance_router
from backend.app.routes.trips import router as trips_router
from backend.app.routes.analytics import router as analytics_router
from backend.app.routes.admin import router as admin_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Ensure database tables are created
    Base.metadata.create_all(bind=engine)
    print(f"[{settings.APP_NAME}] Database tables verified / initialized.")
    yield
    # Shutdown
    print(f"[{settings.APP_NAME}] Shutting down gracefully.")

app = FastAPI(
    title="EV SmartConnect API",
    description="Intelligent Electric Vehicle Management & Telemetry Defense Backend API",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS if settings.CORS_ORIGINS else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Custom Rate Limit and Security Headers Middleware
app.add_middleware(RateLimitMiddleware)

# Include Routers
app.include_router(auth_router)
app.include_router(vehicles_router)
app.include_router(battery_router)
app.include_router(ai_router)
app.include_router(charging_router)
app.include_router(maintenance_router)
app.include_router(trips_router)
app.include_router(analytics_router)
app.include_router(admin_router)

@app.get("/", tags=["Health Check"])
def root():
    return {
        "app": settings.APP_NAME,
        "version": "1.0.0",
        "status": "online",
        "docs": "/docs",
        "environment": settings.APP_ENV,
        "message": "Welcome to EV SmartConnect Intelligent Management Platform"
    }

@app.get("/api/health", tags=["Health Check"])
def health_check():
    return {"status": "healthy", "database": "connected"}
