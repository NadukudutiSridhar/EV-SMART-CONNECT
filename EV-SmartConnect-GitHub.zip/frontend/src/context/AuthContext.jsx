import React, { createContext, useContext, useState, useEffect } from 'react';
import { authAPI, vehiclesAPI } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('ev_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('ev_token'));
  const [loading, setLoading] = useState(true);
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);

  useEffect(() => {
    const initAuth = async () => {
      if (token) {
        try {
          const res = await authAPI.getMe();
          setUser(res.data);
          localStorage.setItem('ev_user', JSON.stringify(res.data));
          // Load vehicles
          await loadVehicles();
        } catch (err) {
          console.error("Auth verification failed", err);
          logout();
        }
      }
      setLoading(false);
    };
    initAuth();
  }, [token]);

  const loadVehicles = async () => {
    try {
      const res = await vehiclesAPI.list();
      setVehicles(res.data);
      if (res.data.length > 0 && !selectedVehicleId) {
        setSelectedVehicleId(res.data[0].id);
      }
    } catch (err) {
      console.error("Failed to load user vehicles", err);
    }
  };

  const login = async (email, password) => {
    const res = await authAPI.login({ email, password });
    const { access_token, user: userData } = res.data;
    setToken(access_token);
    setUser(userData);
    localStorage.setItem('ev_token', access_token);
    localStorage.setItem('ev_user', JSON.stringify(userData));
    await loadVehicles();
    return userData;
  };

  const register = async (name, email, password, role = 'user', phone = '') => {
    const res = await authAPI.register({ name, email, password, role, phone });
    const { access_token, user: userData } = res.data;
    setToken(access_token);
    setUser(userData);
    localStorage.setItem('ev_token', access_token);
    localStorage.setItem('ev_user', JSON.stringify(userData));
    await loadVehicles();
    return userData;
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    setVehicles([]);
    setSelectedVehicleId(null);
    localStorage.removeItem('ev_token');
    localStorage.removeItem('ev_user');
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      isAdmin,
      login,
      register,
      logout,
      vehicles,
      selectedVehicleId,
      setSelectedVehicleId,
      refreshVehicles: loadVehicles
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
