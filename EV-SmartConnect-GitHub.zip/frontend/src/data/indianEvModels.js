// Comprehensive Database of All Electric Vehicles Sold in India (2024-2026)
export const INDIAN_EV_MODELS = [
  // --- TATA MOTORS ---
  {
    make: "Tata",
    model: "Nexon EV Long Range",
    battery_capacity: 40.5,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v3.1.2",
    claimed_range_km: 465,
    real_world_range_km: 330,
    charging_speed_kw: 50.0,
    price_inr: "₹14.49 - 19.49 Lakh",
    connector: "CCS2, Type 2",
    tagline: "India's #1 Best-Selling Electric SUV"
  },
  {
    make: "Tata",
    model: "Curvv EV (Empowered+)",
    battery_capacity: 55.0,
    vehicle_type: "SUV Coupe",
    manufacturing_year: 2025,
    firmware_version: "v4.0.1",
    claimed_range_km: 585,
    real_world_range_km: 420,
    charging_speed_kw: 70.0,
    price_inr: "₹17.49 - 21.99 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Stylish SUV Coupe with 55 kWh Pack & V2L / V2V"
  },
  {
    make: "Tata",
    model: "Punch EV (Long Range)",
    battery_capacity: 35.0,
    vehicle_type: "Compact SUV",
    manufacturing_year: 2024,
    firmware_version: "v2.8.0",
    claimed_range_km: 421,
    real_world_range_km: 290,
    charging_speed_kw: 50.0,
    price_inr: "₹10.99 - 15.49 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Built on Gen-2 acti.ev Pure EV Architecture"
  },
  {
    make: "Tata",
    model: "Tiago EV (Long Range)",
    battery_capacity: 24.0,
    vehicle_type: "Hatchback",
    manufacturing_year: 2024,
    firmware_version: "v2.4.1",
    claimed_range_km: 315,
    real_world_range_km: 220,
    charging_speed_kw: 25.0,
    price_inr: "₹7.99 - 11.89 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Most Affordable Everyday Electric City Car"
  },
  {
    make: "Tata",
    model: "Tigor EV",
    battery_capacity: 26.0,
    vehicle_type: "Sedan",
    manufacturing_year: 2024,
    firmware_version: "v2.5.0",
    claimed_range_km: 315,
    real_world_range_km: 215,
    charging_speed_kw: 25.0,
    price_inr: "₹12.49 - 13.75 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Compact Electric Sedan with 4-Star GNCAP Rating"
  },
  {
    make: "Tata",
    model: "Harrier EV AWD",
    battery_capacity: 65.0,
    vehicle_type: "SUV",
    manufacturing_year: 2025,
    firmware_version: "v4.2.0",
    claimed_range_km: 520,
    real_world_range_km: 440,
    charging_speed_kw: 100.0,
    price_inr: "₹24.00 - 28.00 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Dual-Motor All-Wheel-Drive Electric Flagship"
  },

  // --- MAHINDRA ---
  {
    make: "Mahindra",
    model: "BE 6e",
    battery_capacity: 79.0,
    vehicle_type: "SUV Coupe",
    manufacturing_year: 2025,
    firmware_version: "v1.0.4",
    claimed_range_km: 682,
    real_world_range_km: 510,
    charging_speed_kw: 175.0,
    price_inr: "₹18.90 - 26.90 Lakh",
    connector: "CCS2",
    tagline: "INGLO Architecture with 175 kW Ultra-Fast Charging"
  },
  {
    make: "Mahindra",
    model: "XEV 9e",
    battery_capacity: 79.0,
    vehicle_type: "Luxury SUV",
    manufacturing_year: 2025,
    firmware_version: "v1.0.4",
    claimed_range_km: 656,
    real_world_range_km: 490,
    charging_speed_kw: 175.0,
    price_inr: "₹21.90 - 30.50 Lakh",
    connector: "CCS2",
    tagline: "Triple-Screen Cockpit with INGLO High-Voltage Battery"
  },
  {
    make: "Mahindra",
    model: "XUV400 Pro (EL Pro)",
    battery_capacity: 39.4,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v2.2.0",
    claimed_range_km: 456,
    real_world_range_km: 310,
    charging_speed_kw: 50.0,
    price_inr: "₹15.49 - 19.39 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Spacious C-Segment Electric SUV with 310 Nm Torque"
  },

  // --- MG MOTOR INDIA ---
  {
    make: "MG",
    model: "Windsor EV (Essence)",
    battery_capacity: 38.0,
    vehicle_type: "CUV",
    manufacturing_year: 2024,
    firmware_version: "v1.4.0",
    claimed_range_km: 331,
    real_world_range_km: 265,
    charging_speed_kw: 50.0,
    price_inr: "₹13.50 - 15.50 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Aero Lounge Reclining Seats with BaaS Option"
  },
  {
    make: "MG",
    model: "ZS EV (Exclusive Plus)",
    battery_capacity: 50.3,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v3.0.1",
    claimed_range_km: 461,
    real_world_range_km: 340,
    charging_speed_kw: 50.0,
    price_inr: "₹18.98 - 25.44 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Proven Global EV with Level 2 ADAS Suite"
  },
  {
    make: "MG",
    model: "Comet EV",
    battery_capacity: 17.3,
    vehicle_type: "Hatchback",
    manufacturing_year: 2024,
    firmware_version: "v1.2.0",
    claimed_range_km: 230,
    real_world_range_km: 165,
    charging_speed_kw: 7.4,
    price_inr: "₹6.99 - 9.65 Lakh",
    connector: "Type 2",
    tagline: "Compact 2-Door Urban Smart EV"
  },

  // --- HYUNDAI INDIA ---
  {
    make: "Hyundai",
    model: "Creta Electric",
    battery_capacity: 45.0,
    vehicle_type: "SUV",
    manufacturing_year: 2025,
    firmware_version: "v1.1.0",
    claimed_range_km: 475,
    real_world_range_km: 350,
    charging_speed_kw: 60.0,
    price_inr: "₹17.00 - 22.00 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Electric Avatar of India's Favorite Mid-Size SUV"
  },
  {
    make: "Hyundai",
    model: "Ioniq 5 (Long Range RWD)",
    battery_capacity: 72.6,
    vehicle_type: "Crossover",
    manufacturing_year: 2024,
    firmware_version: "v5.1.0",
    claimed_range_km: 631,
    real_world_range_km: 490,
    charging_speed_kw: 350.0,
    price_inr: "₹46.05 Lakh",
    connector: "CCS2",
    tagline: "800V E-GMP Architecture with 10-80% in 18 Minutes"
  },
  {
    make: "Hyundai",
    model: "Kona Electric",
    battery_capacity: 39.2,
    vehicle_type: "SUV",
    manufacturing_year: 2023,
    firmware_version: "v2.0.0",
    claimed_range_km: 452,
    real_world_range_km: 300,
    charging_speed_kw: 50.0,
    price_inr: "₹23.84 Lakh",
    connector: "CCS2, Type 2",
    tagline: "India's Pioneer High-Efficiency Long Range SUV"
  },

  // --- KIA INDIA ---
  {
    make: "Kia",
    model: "EV6 (GT-Line AWD)",
    battery_capacity: 77.4,
    vehicle_type: "Crossover",
    manufacturing_year: 2024,
    firmware_version: "v4.4.2",
    claimed_range_km: 708,
    real_world_range_km: 520,
    charging_speed_kw: 350.0,
    price_inr: "₹60.95 - 65.95 Lakh",
    connector: "CCS2",
    tagline: "800V Multi-Charging System with 325 PS & 605 Nm"
  },
  {
    make: "Kia",
    model: "EV9 (GT-Line AWD)",
    battery_capacity: 99.8,
    vehicle_type: "Luxury SUV",
    manufacturing_year: 2025,
    firmware_version: "v1.2.0",
    claimed_range_km: 561,
    real_world_range_km: 480,
    charging_speed_kw: 350.0,
    price_inr: "₹1.30 Crore",
    connector: "CCS2",
    tagline: "Three-Row Ultra-Luxury All-Electric Flagship"
  },

  // --- BYD INDIA ---
  {
    make: "BYD",
    model: "Seal (Performance AWD)",
    battery_capacity: 82.56,
    vehicle_type: "Sedan",
    manufacturing_year: 2024,
    firmware_version: "v3.2.0",
    claimed_range_km: 650,
    real_world_range_km: 510,
    charging_speed_kw: 150.0,
    price_inr: "₹41.00 - 53.00 Lakh",
    connector: "CCS2",
    tagline: "0-100 km/h in 3.8s with CTB (Cell-to-Body) Blade Battery"
  },
  {
    make: "BYD",
    model: "Atto 3 (Extended Range)",
    battery_capacity: 60.48,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v2.6.1",
    claimed_range_km: 521,
    real_world_range_km: 410,
    charging_speed_kw: 80.0,
    price_inr: "₹24.99 - 33.99 Lakh",
    connector: "CCS2",
    tagline: "Blade Battery Technology with e-Platform 3.0"
  },
  {
    make: "BYD",
    model: "eMax 7 (Superior 7-Seater)",
    battery_capacity: 71.8,
    vehicle_type: "MPV",
    manufacturing_year: 2024,
    firmware_version: "v1.1.0",
    claimed_range_km: 530,
    real_world_range_km: 420,
    charging_speed_kw: 115.0,
    price_inr: "₹26.90 - 29.90 Lakh",
    connector: "CCS2",
    tagline: "Spacious 6/7-Seater Electric Family Tourer"
  },

  // --- CITROËN INDIA ---
  {
    make: "Citroën",
    model: "ë-C3 (Shine)",
    battery_capacity: 29.2,
    vehicle_type: "Hatchback",
    manufacturing_year: 2024,
    firmware_version: "v1.3.0",
    claimed_range_km: 320,
    real_world_range_km: 230,
    charging_speed_kw: 30.0,
    price_inr: "₹11.61 - 13.50 Lakh",
    connector: "CCS2, Type 2",
    tagline: "Flying Carpet Comfort Suspension with LFP Chemistry"
  },
  {
    make: "Citroën",
    model: "Basalt EV",
    battery_capacity: 35.0,
    vehicle_type: "SUV Coupe",
    manufacturing_year: 2025,
    firmware_version: "v1.0.0",
    claimed_range_km: 380,
    real_world_range_km: 280,
    charging_speed_kw: 50.0,
    price_inr: "₹13.99 - 17.50 Lakh",
    connector: "CCS2, Type 2",
    tagline: "All-Electric Coupe SUV with Premium French Styling"
  },

  // --- LUXURY ELECTRIC VEHICLES IN INDIA ---
  {
    make: "BMW",
    model: "i4 eDrive40",
    battery_capacity: 83.9,
    vehicle_type: "Sedan",
    manufacturing_year: 2024,
    firmware_version: "v8.5.2",
    claimed_range_km: 590,
    real_world_range_km: 470,
    charging_speed_kw: 205.0,
    price_inr: "₹72.50 - 77.50 Lakh",
    connector: "CCS2",
    tagline: "Luxury Electric Gran Coupé with 340 hp Rear-Drive"
  },
  {
    make: "BMW",
    model: "iX1 xDrive30",
    battery_capacity: 66.4,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v9.0.1",
    claimed_range_km: 440,
    real_world_range_km: 350,
    charging_speed_kw: 130.0,
    price_inr: "₹66.90 Lakh",
    connector: "CCS2",
    tagline: "Dual-Motor Electric SAV with 313 hp Boost Mode"
  },
  {
    make: "Mercedes-Benz",
    model: "EQB 350 4MATIC",
    battery_capacity: 70.5,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v3.8.0",
    claimed_range_km: 423,
    real_world_range_km: 335,
    charging_speed_kw: 100.0,
    price_inr: "₹77.50 Lakh",
    connector: "CCS2",
    tagline: "7-Seater Luxury Family Electric SUV"
  },
  {
    make: "Mercedes-Benz",
    model: "EQE 500 4MATIC SUV",
    battery_capacity: 90.6,
    vehicle_type: "Luxury SUV",
    manufacturing_year: 2024,
    firmware_version: "v4.0.0",
    claimed_range_km: 550,
    real_world_range_km: 460,
    charging_speed_kw: 170.0,
    price_inr: "₹1.39 Crore",
    connector: "CCS2",
    tagline: "Hyperscreen Dashboard with 408 hp & 858 Nm Torque"
  },
  {
    make: "Volvo",
    model: "EX40 / C40 Recharge (Twin AWD)",
    battery_capacity: 78.0,
    vehicle_type: "SUV",
    manufacturing_year: 2024,
    firmware_version: "v3.0.3",
    claimed_range_km: 530,
    real_world_range_km: 430,
    charging_speed_kw: 150.0,
    price_inr: "₹56.90 - 62.95 Lakh",
    connector: "CCS2",
    tagline: "Scandinavian Minimalist Design with 408 hp Twin Motors"
  },
  {
    make: "Audi",
    model: "Q8 e-tron 55",
    battery_capacity: 114.0,
    vehicle_type: "Luxury SUV",
    manufacturing_year: 2024,
    firmware_version: "v3.4.1",
    claimed_range_km: 600,
    real_world_range_km: 480,
    charging_speed_kw: 170.0,
    price_inr: "₹1.15 - 1.27 Crore",
    connector: "CCS2",
    tagline: "Quattro Electric AWD with 114 kWh Massive Battery"
  }
];

// Helper to generate a random authentic Indian EV registration number
export const generateIndianPlate = (make = 'Tata') => {
  const rtoCodes = ['KA-01', 'KA-05', 'MH-01', 'MH-02', 'DL-03', 'TS-07', 'TN-07', 'GJ-01', 'KL-07', 'HR-26'];
  const rto = rtoCodes[Math.floor(Math.random() * rtoCodes.length)];
  const num = Math.floor(1000 + Math.random() * 9000);
  return `${rto}-EV-${num}`;
};
