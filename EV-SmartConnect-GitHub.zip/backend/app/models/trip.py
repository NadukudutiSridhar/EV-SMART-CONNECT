from sqlalchemy import Column, Integer, Float, String, Date, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from backend.app.database import Base

class TripRecord(Base):
    __tablename__ = "trip_records"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    start_location = Column(String(160), nullable=False)
    destination = Column(String(160), nullable=False)
    distance = Column(Float, nullable=False) # km
    duration_minutes = Column(Integer, nullable=False) # minutes
    average_speed = Column(Float, nullable=False) # km/h
    energy_consumed = Column(Float, nullable=False) # kWh
    efficiency = Column(Float, nullable=False) # kWh per 100km
    start_soc = Column(Float, nullable=False) # %
    end_soc = Column(Float, nullable=False) # %
    trip_date = Column(Date, nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    vehicle = relationship("Vehicle", back_populates="trip_records")
