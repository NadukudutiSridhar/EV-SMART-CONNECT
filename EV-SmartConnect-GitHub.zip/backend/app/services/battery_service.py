import math
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy import desc

from backend.app.config import settings
from backend.app.models.battery import BatteryReading
from backend.app.models.maintenance import MaintenanceAlert
from backend.app.models.vehicle import Vehicle
from backend.app.schemas.battery import BatteryReadingCreate
from ml.predict import detect_telemetry_anomaly, predict_ev_range

def process_battery_reading(reading_data: BatteryReadingCreate, db: Session) -> BatteryReading:
    """
    Ingests an EV telemetry reading, runs threshold & ML anomaly detection,
    persists the reading, and raises maintenance alerts if anomalous conditions are met.
    """
    # 1. Run Anomaly Detection (Threshold + Isolation Forest)
    anomaly_result = detect_telemetry_anomaly(
        voltage=reading_data.voltage,
        current=reading_data.current,
        temperature=reading_data.temperature,
        soc=reading_data.soc,
        energy_consumption=reading_data.energy_consumption or 16.5
    )

    is_anomaly = anomaly_result["is_anomaly"]

    # 2. Persist Reading
    db_reading = BatteryReading(
        vehicle_id=reading_data.vehicle_id,
        soc=reading_data.soc,
        soh=reading_data.soh,
        voltage=reading_data.voltage,
        current=reading_data.current,
        temperature=reading_data.temperature,
        vehicle_speed=reading_data.vehicle_speed or 0.0,
        energy_consumption=reading_data.energy_consumption or 16.0,
        distance_travelled=reading_data.distance_travelled or 0.0,
        charging_status=reading_data.charging_status or "idle",
        is_simulated=reading_data.is_simulated if reading_data.is_simulated is not None else True,
        is_anomaly=is_anomaly
    )
    db.add(db_reading)
    db.commit()
    db.refresh(db_reading)

    # 3. If Anomaly, create or update Maintenance Alert
    if is_anomaly:
        reasons_text = "; ".join(anomaly_result["reasons"])
        severity = anomaly_result["severity"]
        
        # Determine recommended action
        recommended_action = "Schedule workshop inspection for cell module check."
        if "temperature" in reasons_text.lower():
            recommended_action = "Inspect liquid cooling loop pump and coolant levels immediately. Reduce vehicle load."
        elif "voltage" in reasons_text.lower():
            recommended_action = "Perform battery balancing cycle and inspect BMS cell voltage monitor harness."
        elif "current" in reasons_text.lower():
            recommended_action = "Check traction inverter and main contactors for thermal degradation or abnormal load."

        # Avoid duplicate unresolved alerts of the exact same type within last 1 hour
        recent_alert = db.query(MaintenanceAlert).filter(
            MaintenanceAlert.vehicle_id == reading_data.vehicle_id,
            MaintenanceAlert.is_resolved == False,
            MaintenanceAlert.alert_type == ("Temperature" if "temperature" in reasons_text.lower() else "Voltage/Current")
        ).first()

        if not recent_alert:
            alert = MaintenanceAlert(
                vehicle_id=reading_data.vehicle_id,
                alert_type="Temperature" if "temperature" in reasons_text.lower() else "Electrical Telemetry",
                severity=severity,
                description=reasons_text,
                recommended_action=recommended_action,
                sensor_value=reading_data.temperature if "temperature" in reasons_text.lower() else reading_data.voltage,
                threshold_value=settings.BATTERY_MAX_TEMP if "temperature" in reasons_text.lower() else settings.BATTERY_MAX_VOLTAGE,
                detection_method=anomaly_result["detection_method"],
                is_resolved=False
            )
            db.add(alert)
            db.commit()

    # 4. Check for Battery SOH Degradation Alert
    if reading_data.soh < settings.BATTERY_MIN_SOH:
        soh_alert = db.query(MaintenanceAlert).filter(
            MaintenanceAlert.vehicle_id == reading_data.vehicle_id,
            MaintenanceAlert.alert_type == "SOH_Degradation",
            MaintenanceAlert.is_resolved == False
        ).first()
        if not soh_alert:
            db.add(MaintenanceAlert(
                vehicle_id=reading_data.vehicle_id,
                alert_type="SOH_Degradation",
                severity="High",
                description=f"Battery State of Health degraded to {reading_data.soh}%, falling below the manufacturer minimum baseline ({settings.BATTERY_MIN_SOH}%).",
                recommended_action="Contact certified service center for battery pack module degradation diagnostic and warranty evaluation.",
                sensor_value=reading_data.soh,
                threshold_value=settings.BATTERY_MIN_SOH,
                detection_method="Threshold",
                is_resolved=False
            ))
            db.commit()

    return db_reading

def get_battery_overview(vehicle_id: int, db: Session) -> dict:
    """Computes comprehensive battery health overview for dashboard."""
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    latest_reading = db.query(BatteryReading).filter(
        BatteryReading.vehicle_id == vehicle_id
    ).order_by(desc(BatteryReading.timestamp)).first()

    active_alerts = db.query(MaintenanceAlert).filter(
        MaintenanceAlert.vehicle_id == vehicle_id,
        MaintenanceAlert.is_resolved == False
    ).all()

    warnings = [f"[{a.severity}] {a.description}" for a in active_alerts]
    safety_status = "Normal"
    if any(a.severity == "High" for a in active_alerts):
        safety_status = "Critical"
    elif len(active_alerts) > 0:
        safety_status = "Warning"

    # Predicted range
    predicted_km = 0.0
    degradation_pct = 0.0
    if latest_reading and vehicle:
        degradation_pct = round(100.0 - latest_reading.soh, 1)
        try:
            pred = predict_ev_range(
                battery_capacity=vehicle.battery_capacity,
                soc=latest_reading.soc,
                soh=latest_reading.soh,
                temperature=latest_reading.temperature,
                avg_speed=max(30.0, latest_reading.vehicle_speed),
                vehicle_load=75.0,
                energy_consumption=latest_reading.energy_consumption or 16.5,
                terrain="flat"
            )
            predicted_km = pred["predicted_range_km"]
        except Exception:
            predicted_km = round((vehicle.battery_capacity * (latest_reading.soc / 100.0)) / 0.165, 1)

    return {
        "vehicle_id": vehicle_id,
        "latest_reading": latest_reading,
        "safety_status": safety_status,
        "active_warnings": warnings,
        "predicted_range_km": predicted_km,
        "degradation_percentage": degradation_pct
    }
