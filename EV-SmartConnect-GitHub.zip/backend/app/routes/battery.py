from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.models.battery import BatteryReading
from backend.app.schemas.battery import BatteryReadingCreate, BatteryReadingResponse, BatteryStatusOverview
from backend.app.security.auth import get_current_user, verify_vehicle_ownership
from backend.app.security.middleware import validate_telemetry_payload
from backend.app.services.battery_service import process_battery_reading, get_battery_overview

router = APIRouter(prefix="/api/battery", tags=["Battery Health & Telemetry"])

@router.get("/{vehicle_id}", response_model=BatteryStatusOverview)
def get_vehicle_battery_status(vehicle_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    verify_vehicle_ownership(vehicle_id, current_user, db)
    overview = get_battery_overview(vehicle_id, db)
    return overview

@router.post("/readings", response_model=BatteryReadingResponse, status_code=status.HTTP_201_CREATED)
def submit_battery_reading(reading_data: BatteryReadingCreate, db: Session = Depends(get_db)):
    """
    Ingest EV telemetry reading.
    Validates physical plausibility against spoofing/tampering attacks.
    Note: Can be called by simulated EV edge devices or authenticated users.
    """
    is_valid, reason = validate_telemetry_payload(reading_data.dict())
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Telemetry payload validation rejected: {reason}"
        )

    reading = process_battery_reading(reading_data, db)
    return reading

@router.get("/history/{vehicle_id}", response_model=List[BatteryReadingResponse])
def get_battery_reading_history(vehicle_id: int, limit: int = 50, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    verify_vehicle_ownership(vehicle_id, current_user, db)
    readings = db.query(BatteryReading).filter(
        BatteryReading.vehicle_id == vehicle_id
    ).order_by(desc(BatteryReading.timestamp)).limit(limit).all()
    # Return in chronological order
    readings.reverse()
    return readings
