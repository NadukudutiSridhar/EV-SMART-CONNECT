import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor: Attach JWT Token if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('ev_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor: Handle 401 Unauthorized
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Clear token if expired or invalid
      if (window.location.pathname !== '/login' && window.location.pathname !== '/register') {
        localStorage.removeItem('ev_token');
        localStorage.removeItem('ev_user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  getMe: () => api.get('/auth/me'),
};

export const vehiclesAPI = {
  list: () => api.get('/vehicles'),
  get: (id) => api.get(`/vehicles/${id}`),
  create: (data) => api.post('/vehicles', data),
  update: (id, data) => api.put(`/vehicles/${id}`, data),
  delete: (id) => api.delete(`/vehicles/${id}`),
};

export const batteryAPI = {
  getStatus: (vehicleId) => api.get(`/battery/${vehicleId}`),
  submitReading: (data) => api.post('/battery/readings', data),
  getHistory: (vehicleId, limit = 40) => api.get(`/battery/history/${vehicleId}?limit=${limit}`),
};

export const aiAPI = {
  predictRange: (data) => api.post('/predict-range', data),
  getPredictions: (vehicleId) => api.get(`/predictions/${vehicleId}`),
  getMetrics: () => api.get('/ai/metrics'),
};

export const chargingAPI = {
  getStations: (params) => api.get('/stations', { params }),
  createStation: (data) => api.post('/stations', data),
  getSessions: (vehicleId) => api.get('/charging-sessions', { params: { vehicle_id: vehicleId } }),
  startSession: (data) => api.post('/charging-sessions', data),
  getRecommendation: (data) => api.post('/recommendations', data),
};

export const maintenanceAPI = {
  getAlerts: (params) => api.get('/maintenance', { params }),
  resolveAlert: (alertId, data = { is_resolved: true }) => api.put(`/maintenance/${alertId}`, data),
};

export const tripsAPI = {
  getTrips: (vehicleId) => api.get('/trips', { params: { vehicle_id: vehicleId } }),
  createTrip: (data) => api.post('/trips', data),
};

export const analyticsAPI = {
  getSummary: () => api.get('/analytics/summary'),
  getReports: () => api.get('/reports'),
};

export const adminAPI = {
  getUsers: () => api.get('/admin/users'),
  toggleStatus: (userId, isActive) => api.put(`/admin/users/${userId}/status?is_active=${isActive}`),
  changeRole: (userId, role) => api.put(`/admin/users/${userId}/role?role=${role}`),
  getStats: () => api.get('/admin/stats'),
  seedDemoData: () => api.post('/admin/seed'),
};

export default api;
