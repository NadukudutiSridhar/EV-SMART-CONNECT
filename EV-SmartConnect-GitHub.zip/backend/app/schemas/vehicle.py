from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class VehicleCreateRequest(BaseModel):
    model: str = Field(..., min_length=1, max_length=120)
    make: str = Field(..., min_length=1, max_length=80)
    registration_number: str = Field(..., min_length=3, max_length=50)
    vin: Optional[str] = None
    battery_capacity: float = Field(..., gt=5.0, le=250.0, description="Battery capacity in kWh")
    vehicle_type: str = Field(default="Sedan")
    manufacturing_year: int = Field(..., ge=2010, le=2030)
    firmware_version: Optional[str] = "v2.4.1"

class VehicleUpdateRequest(BaseModel):
    model: Optional[str] = None
    make: Optional[str] = None
    registration_number: Optional[str] = None
    battery_capacity: Optional[float] = None
    vehicle_type: Optional[str] = None
    firmware_version: Optional[str] = None
    is_active: Optional[bool] = None

class VehicleResponse(BaseModel):
    id: int
    user_id: int
    model: str
    make: str
    registration_number: str
    vin: Optional[str] = None
    battery_capacity: float
    vehicle_type: str
    manufacturing_year: int
    firmware_version: Optional[str]
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
