import time
import logging
from collections import defaultdict
from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ev_security")

# Simple in-memory sliding window rate limiter
RATE_LIMIT_WINDOW = 60 # seconds
MAX_AUTH_ATTEMPTS = 15 # max attempts per window per IP
_ip_request_timestamps = defaultdict(list)

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Apply strict rate limits to authentication endpoints
        path = request.url.path
        if path.startswith("/api/auth/login") or path.startswith("/api/auth/register"):
            client_ip = request.client.host if request.client else "unknown"
            now = time.time()
            
            # Prune old timestamps
            timestamps = [ts for ts in _ip_request_timestamps[client_ip] if now - ts < RATE_LIMIT_WINDOW]
            _ip_request_timestamps[client_ip] = timestamps

            if len(timestamps) >= MAX_AUTH_ATTEMPTS:
                logger.warning(f"Rate limit exceeded for IP {client_ip} on {path}")
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="Too many authentication requests. Please try again after 1 minute."
                )
            _ip_request_timestamps[client_ip].append(now)

        response = await call_next(request)
        
        # Add Security Headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response

def validate_telemetry_payload(data: dict) -> tuple[bool, str]:
    """
    Validates physical plausibility of incoming EV sensor telemetry.
    Rejects spoofed or impossible sensor values.
    """
    soc = data.get("soc")
    soh = data.get("soh")
    voltage = data.get("voltage")
    temperature = data.get("temperature")
    current = data.get("current")

    if soc is not None and (soc < 0 or soc > 100):
        return False, f"Impossible SOC: {soc}%. Must be between 0 and 100."
    if soh is not None and (soh < 30 or soh > 100):
        return False, f"Impossible SOH: {soh}%. Must be between 30 and 100."
    if voltage is not None and (voltage < 0 or voltage > 1000):
        return False, f"Impossible Voltage: {voltage}V. EV nominal limits exceeded."
    if temperature is not None and (temperature < -50 or temperature > 120):
        return False, f"Impossible Temperature: {temperature}°C. Exceeds physical sensor bounds."
    if current is not None and abs(current) > 1000:
        return False, f"Impossible Current: {current}A. Exceeds safe hardware measurement limits."

    return True, "Valid telemetry"

def audit_log(action: str, user_email: str, details: str = ""):
    """Security audit trail logger."""
    logger.info(f"AUDIT | Action: {action} | User: {user_email} | Details: {details}")
